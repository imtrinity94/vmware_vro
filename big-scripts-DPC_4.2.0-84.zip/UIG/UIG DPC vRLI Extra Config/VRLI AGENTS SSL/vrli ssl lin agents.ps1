####Automated configuration of ssl on linux vrli angents. Modify replacement parameters if there is something you want to change in the script.
####Version: 0.1
####Date: 05.02.2018
####Author:Andrei Savu 

#I. Ask for parameter
function giveParam($name){
    Write-host "Enter $name"
    $result = Read-host 
    return $result
}

#II. Additional

function writeServer{
    write-host "========================"
    write-host "Working on: "$server; 
}

# Import server information from CSV
$servers = Get-Content .\linlist.csv

#provide ca-certificate file name (same folder as scripts)
$certificate = giveParam -name "vRLI RCA Certificate name (file have to be in same directory as script):"

#replacement parameters
$ssl = 'ssl=no' #what is replaced // change here if needed
$sslnew = 'ssl=yes \nssl_accept_any=yes' # with what is replaced

#command for installation vRLI agent
$commandvrli = "(sed -i -e 's/${ssl}/${sslnew}/g' /var/lib/loginsight-agent/liagent.ini && /etc/init.d/liagentd restart)"	

function writeServer{
    write-host "========================"
    write-host "Working on: "$server; 
}


#III. CONFIGURATION PART
foreach($server in $servers) {
	writeServer
	$UserName = giveParam -name "Provide user for ${server}:"
	$password = giveParam -name "Provide password on ${server} for ${UserName}:"
	Start-Process -wait '.\pscp.exe' -ArgumentList ("-scp -pw "+$password+" "+$certificate+" "+$UserName+"@"+$server+":/etc/ssl/certs/") 
    cmd.exe /C .\plink.exe -ssh $server -l $UserName -pw $password $commandvrli
}