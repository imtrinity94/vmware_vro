﻿#####Script is being used for automated reconfiguration of vRLI agents remotly on Windows and Linux VMs. 
#####These particular scripts will just reconfigure liagent.ini files in each server in order to send data over SLL.
#1.	Prerequsites
To achieve full functionality you need those files to be present in SINGLE directory:
•	vrli ssl lin agents.ps1 – linux script itself
•	vrli ssl win agents.ps1 – windows script itself
•	winlist.csv – CSV file with all windows servers that have agents installed and require reconfiguration ; the list provided is a sample. Please update it accordingly.
•	linlist.csv – CSV file with all linux servers that have agents installed and require reconfiguration; the list provided is a sample. Please update it accordingly.
•	plink.exe – executable used for remote commands on linux
•	pscp.exe – executable used for file transfer to linux
•	ca-certificates.crt root CA certificate in .crt format (used by linux agents for SSL communication)


#2.	CSV preparation:
CSV file contains multiple 

Sample CSV file 
Testserver1.devdpc.local
Testserver2.devdpc.local
Testserver3.devdpc.local

#3.	Run script
BEFORE launching the script change directory to one on which you have script itself and all mentioned files in point 1. 

Script is being run without parameters, but on base of CSV content it will ask for additional information like:
•	Domain credentials – you will be asked for this only once while executing the windows scrip.
•	Local linux credential - before executing this on linux servers you will be prompted for credentials.
•	ca-certificates.crt - for linux script you will have to point the name of the certificate. Certificate must be located in the same fodler as the script.