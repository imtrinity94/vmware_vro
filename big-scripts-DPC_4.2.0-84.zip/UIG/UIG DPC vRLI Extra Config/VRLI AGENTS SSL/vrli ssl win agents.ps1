####Automated configuration of ssl on windows vrli angents. Modify replacement parameters if there is something you want to change in the script.
####Version: 0.1
####Date: 05.02.2018
####Author:Andrei Savu 


#II. Additional


# Import server information from CSV
$servers = Get-Content .\winlist.csv

#vRLI agent configuration file
$liagent = 'C:\ProgramData\VMware\Log Insight Agent\liagent.ini'

#replacement parameters
$ssl = 'ssl=no' #what is replaced // change here if needed
$sslnew = 'ssl_accept_any=yes' # with what is replaced

#III. CONFIGURATION PART
$credentials = Get-Credential
foreach($server in $servers){
	write-host "Working on: "$server;     
		Get-Service -ComputerName $server -Name LogInsightAgentService| Stop-Service -Verbose;
        Invoke-Command -ComputerName $server -ScriptBlock { (Get-Content $args[0]).replace($args[1],$args[2]) | Set-Content $args[0]} -credential $credentials -ArgumentList $liagent,$ssl,$sslnew;
		Get-Service -ComputerName $server -Name LogInsightAgentService| Start-Service -Verbose;
    }