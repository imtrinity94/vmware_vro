# Script Parameters
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$True,Position=1)]
   [string]$vCServer,

   [Parameter(Mandatory=$True,Position=1)]
   [string]$HostName,
  
  [Parameter(Mandatory=$True,Position=1)]
   [string]$SourceSwitch


)

#Functions
Function Exit{
    Pause
    Break
}

# Confirm Script is being run in PowerCLI
Try{
$Null = Get-PowerCLIVersion
}
Catch {
	Write-Host "You do not appear to be running this script from a PowerCLI console. The script has terminated, please run the script from PowerCLI."-ForegroundColor Red
exit
}

# Supress Connect-VIServer warnings
Write-Host "Setting PowerCLI session configuration..." -foregroundColor Green
$Null = Set-PowerCLIConfiguration -Scope Session -DefaultVIServerMode Single -DisplayDeprecationWarnings $False -InvalidCertificateAction Ignore -Confirm:$False

# Get credentials for vCenter
$vCCReds = Get-Credential -Message "Please enter credentials for the vCenter"

# Try to connect to vCenter
Write-Host "Attempting to connect to $vCServer..." -ForegroundColor Yellow
Try {
	Connect-VIServer -Server $vCServer -Credential $vCCReds -ErrorAction Stop
}
Catch {
	Write-Host $_
    Write-Host "Connection to the vCenter $vcServer failed. Please resolve and re-run script." -ForegroundColor Red
    exit
    }
Write-Host "Connected to vCenter..." -ForegroundColor Green

#Set Log Variable
$Log = @()

# Get all templates
$VMTemplates = Get-VMHost -Name $HostName | Get-Template

# Exit if no VMs found
If (($VMTemplates).count -eq 0){
	Write-Host "No templates found that need to be migrated" -ForegroundColor Yellow
	exit
}
Else{
	Write-Host "Found" ($VMTemplates).Count "templates to be migrated" -ForegroundColor Yellow
}

Write-Host "Attempting to migrate template Port Groups..." -ForegroundColor Yellow


# Convert Template to VM so the NIC(s) can be changed over
Foreach ($VMTemplate in $VMTemplates){
	
	# Convert Template to VM so the NIC(s) can be changed over
	Try{
		$Null = $VMTemplate | Set-Template -ToVM -ErrorAction Stop
		$Log += "SUCCESS:" + $VMTemplate.Name + " converted to a Virtual Machine"
	}	
	Catch{
		$Log += "FAILED:" + $VMTemplate.Name + "not converted to a Virtual Machine"
	}
	
	# Get-VM NICs
	$VMNICs = Get-VM -Name $VMTemplate.Name -DistributedSwitch $SourceSwitch | Get-NetworkAdapter 
	
	Foreach ($VMNIC in $VMNICs){
		If ($VMNIC.NetworkName -like "dv_*"){
			$Log += "INFO:" + $VMTemplate.Name + " " + $VMNIC.name + " is already connected to " + $VMNIC.NetworkName
		}
		ElseIf($VMNIC.NetworkName -eq "vmservice-vshield-pg"){
			$Log += "INFO:" + $VM.Name + " " + $VMNIC.name +  " is connected to vmservice-vshield-pg and has not been migrated"
		}
		Else{
			Try{
				$NewPG = "dv_" + $VMNIC.NetworkName
				$Null = $VMNIC | Set-NetworkAdapter -PortGroup $NewPG -Confirm:$False -ErrorAction Stop
				$Log += "SUCCESS:" + $VMTemplate.Name + " " + $VMNIC.name + " moved from " + $VMNIC.NetworkName + " to " + $NewPG	
				Clear-Variable NewPG
			}	
			Catch{
				$Log += "FAILED:" + $VMTemplate.Name + " " + $VMNIC.name + " moved from " + $VMNIC.NetworkName + " to " + $NewPG
			}
			Clear-Variable VMNICs
		}
	}
	
	# Convert VMs back to template
	Try{
		$Null = Set-VM $VMTemplate.Name -ToTemplate -Confirm:$False -ErrorAction Stop
		$Log += "SUCCESS:" + $VMTemplate.Name + " converted back to template"
	}	
	Catch{
		$Log += "FAILED:" + $VMTemplate.Name + " not converted back to template"
	}
}	

# Display log information
Foreach ($line in $Log) {
    If ($line.substring(0,4) -eq "FAIL"){
    Write-Host $line -ForegroundColor Red
    }
}

$Mydate =(Get-Date -Format ddMMyy-HHmmss).ToString()
$LogPath = "$env:UserProfile\Desktop\TemplateMigrations$Mydate.txt"
Try{
	$Log | Out-File $LogPath
	Write-Host "`nFull log file: $LogPath" -ForegroundColor White
	}
Catch{
	Write-Host "`nLog file: $LogPath could not be written" -ForegroundColor Red
}


# Confirm script has completed
Write-Host "`nThe script has now completed..." -ForegroundColor Yellow
