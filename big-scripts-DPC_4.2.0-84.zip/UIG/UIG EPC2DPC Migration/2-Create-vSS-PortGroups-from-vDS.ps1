
<#
.SYNOPSIS
    Recreate vDS portgroups on vSS for EPC2DPC migration purpose.
.DESCRIPTION
    Script is cerateing dv_ portgoups on vSS for DPC migration purpose from EPC 3.5.2
.PARAMETER vCenter
    Prompts you for vCenter server FQDN or IP address to connect, vc parameter is an alias, This value can be taken from pipline by property name.
.PARAMETER Cluster
    Make sure you type a valid ClusterName within the provided vCenter server. New vSwitch name 'SDPCMigration' is created on all esxi hosts withing this cluster, and existing DvSwitch PortGroups cloned to newly vSwitch created.
.PARAMETER DVSwitch
    This ask for existing distributed virtual switch (dvswitch). All the portgroups from this distributed vswitch is copied to vSwitch 
.NOTES
Author: Jarek Gajewski
Version: 1.0
.EXAMPLE
    PS C:\>.\Copy-DvsPortGroupToSSwitch.ps1 -vCenter vcsa65.zen.lab -Cluster Cluster01 -DVSwitch DVSwitch-1

#>

Param (
    [parameter(Position=0, Mandatory=$true, ValueFromPipelineByPropertyName=$true, HelpMessage='Type vCenter server IP or FQDN you want to connect')]
    [alias('vc')]
    [String]$vCenter,
    [parameter(Position=1, Mandatory=$true, ValueFromPipelineByPropertyName=$true, ValueFromPipeline=$true, HelpMessage='Type valid Cluster Name within vCenter server')]
    [alias('c')]
    [String]$Cluster,
    [parameter(Position=2, Mandatory=$true, ValueFromPipelineByPropertyName=$true, HelpMessage='Type valid distributed virtual switch (dvswitch) name')]
    [alias('dvs')]
    [String]$DVSwitch
)

Process {
    if ($global:DefaultVIServers.Name -notcontains $vCenter) {
        try {
            Connect-VIServer $vCenter -ErrorAction Stop
        }
        catch {
            Write-Host $($Error[0].Exception) -ForegroundColor Red
            break
        }
    }
    try {
        $ClusterInfo = Get-Cluster $cluster -ErrorAction Stop
        $DvSwitchInfo = Get-VDSwitch -Name $DVSwitch -ErrorAction Stop
    }
    catch {
        Write-Host $($Error[0].Exception) -ForegroundColor Red
        break
    }
    
    $AllEsxis = $ClusterInfo | Get-VMhost | Where-Object {$_.ConnectionState -eq 'Connected' -or $_.ConnectionState -eq 'Maintenance'}
    $DvPortGroupInfo = $DvSwitchInfo | Get-VDPortgroup | Where-Object {$_.IsUplink -eq $false}

    foreach ($esxi in $ALLEsxis) {
        $ExistingSwitchs = $esxi | Get-VirtualSwitch
        $esxiName = $esxi.name
        if ($ExistingSwitchs.Name -notcontains 'DPCMigration') {
            $DPCMigration = $esxi | New-VirtualSwitch -Name DPCMigration -Mtu $DvSwitchInfo.Mtu
            $NvSwitchName = $DPCMigration.Name
            Write-Host "$([char]8734) " -ForegroundColor Magenta -NoNewline
            Write-Host "Created $NvSwitchName on $esxiName" -BackgroundColor Magenta 
            Foreach ($DvPortGroup in $DvPortGroupInfo) {
                $vPortGroupName = "dv_" + $DvPortGroup.Name
                $vLanID = $DvPortGroup.ExtensionData.Config.DefaultPortConfig.Vlan.VlanId
                $NewPortGroup = $DPCMigration | New-VirtualPortGroup -Name $vPortGroupName -VLanId $vLanID
                Write-Host "`t $([char]8730) " -ForegroundColor Green -NoNewline
                Write-Host "Created New PortGroup $vPortGroupName With vLanID $vLanID" -BackgroundColor DarkGreen
            }
        }
        else {
            Write-Host "$([char]215) " -ForegroundColor Red -NoNewline
            Write-Host "DPCMigration already present on $esxiName skipping..." -BackgroundColor DarkRed 
            Continue
        }
    }
}
End {
    Disconnect-VIServer $vCenter -Confirm:$false
}