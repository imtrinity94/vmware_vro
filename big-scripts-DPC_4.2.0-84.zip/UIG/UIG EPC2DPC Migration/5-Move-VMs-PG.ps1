# Script Parameters
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$True,Position=1)]
   [string]$vCServer,

   [Parameter(Mandatory=$True,Position=1)]
   [string]$HostName,
  
  [Parameter(Mandatory=$True,Position=1)]
   [string]$SourceSwitch
)

#Functions
Function Exit{
    Pause
    Break
}

# Confirm Script is being run in PowerCLI
Try{
	$Null = Get-PowerCLIVersion
}
Catch {
	Write-Host "You do not appear to be running this script from a PowerCLI console. The script has terminated, please run the script from PowerCLI."-ForegroundColor Red
exit
}

# Supress Connect-VIServer warnings
Write-Host "Setting PowerCLI session configuration..." -foregroundColor Green
$Null = Set-PowerCLIConfiguration -Scope Session -DefaultVIServerMode Single -DisplayDeprecationWarnings $False -InvalidCertificateAction Ignore -Confirm:$False

# Get credentials for vCenter
$vCCReds = Get-Credential -Message "Please enter credentials for the vCenter"

# Try to connect to vCenter
Write-Host "Attempting to connect to $vCServer..." -ForegroundColor Yellow
Try {
	Connect-VIServer -Server $vCServer -Credential $vCCReds -ErrorAction Stop
}
Catch {
	Write-Host $_
    Write-Host "Connection to the vCenter $vcServer failed. Please resolve and re-run script." -ForegroundColor Red
    exit
}
Write-Host "Connected to vCenter..." -ForegroundColor Green

#Set Log Variable
$Log = @()


# Get all VMs on the source switch
Try {
	$VMs = Get-VM -DistributedSwitch $SourceSwitch | Where-Object {$_.Host.Name -eq $HostName} -ErrorAction Stop
}
Catch{
	Write-Host "Unable to find any VMs on the $HostName host and $SourceSwitch switch , please check the switch name and re-run the script."-ForegroundColor Red
	exit
}

# Exit if no VMs found
If (($VMs).count -eq 0){
	Write-Host "No virtual machines found that need to be migrated" -ForegroundColor Yellow
	exit
}
Else{
	Write-Host "Found" ($VMs).Count "VMs to be migrated" -ForegroundColor Yellow
}

Write-Host "Attempting to migrate virtual machine Port Groups..." -ForegroundColor Yellow

# Migrate the VM NICs
Foreach ($VM in $VMs){
	# Get-VM NICs
	$VMNICs = Get-VM -Name $VM.Name | Get-NetworkAdapter 
	
	Foreach ($VMNIC in $VMNICs){
		If ($VMNIC.NetworkName -like "dv_*"){
			$Log += "INFO:" + $VM.Name + " " + $VMNIC.name +  " is already connected to " + $VMNIC.NetworkName
		}
		ElseIf($VMNIC.NetworkName -eq "vmservice-vshield-pg"){
			$Log += "INFO:" + $VM.Name + " " + $VMNIC.name +  " is connected to vmservice-vshield-pg and has not been migrated"
		}
		Else{
			Try{
				$NewPG = "dv_" + $VMNIC.NetworkName
				$Null = $VMNIC | Set-NetworkAdapter -NetworkName $NewPG -Confirm:$False -ErrorAction Stop
				$Log += "SUCCESS:" + $VM.Name + " " + $VMNIC.name + " moved from " + $VMNIC.NetworkName + " to " + $NewPG	
				Clear-Variable NewPG
			}	
			Catch{
				$Log += "FAILED:" + $VM.Name + " " + $VMNIC.name + " moved from " + $VMNIC.NetworkName + " to " + $NewPG
			}
		Clear-Variable VMNICs
		}
	}
}	

# Display log information
Foreach ($line in $Log) {
    If ($line.substring(0,4) -eq "FAIL"){
		Write-Host $line -ForegroundColor Red
    }
}

$Mydate =(Get-Date -Format ddMMyy-HHmmss).ToString()
$LogPath = "$env:UserProfile\Desktop\VMMigrations$Mydate.txt"
Try{
	$Log | Out-File $LogPath
	Write-Host "`nFull log file: $LogPath" -ForegroundColor White
	}
Catch{
	Write-Host "`nLog file: $LogPath could not be written to" -ForegroundColor Red
}


# Confirm script has completed
Write-Host "`nThe script has now completed..." -ForegroundColor Yellow
