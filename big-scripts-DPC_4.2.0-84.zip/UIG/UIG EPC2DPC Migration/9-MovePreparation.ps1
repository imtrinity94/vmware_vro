﻿# Script Parameters
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$True,Position=1)]
   [string]$vCServer,
  
   [Parameter(Mandatory=$True)]
   [string]$WaveCSV,

   [Parameter(Mandatory=$True)]
   [string]$DHost
)

#Functions
Function Exit{
    Pause
    Break
}

# Confirm Script is being run in PowerCLI
Try{
$Null = Get-PowerCLIVersion
}
Catch {
Write-Host "You do not appear to be running this script from a PowerCLI console. The script has terminated, please run the script from PowerCLI."-ForegroundColor Red
exit
}

#Confirm if CSV exists (assumes file is on current users desktop, user only supplies file name)
$CSVPath= $env:USERPROFILE + "\Desktop\$WaveCSV"
$PathTest = Test-Path $CSVPath -Pathtype Leaf
If ($PathTest -eq $False){
 Write-Host "File $CSVPath not found, please re-run script and provide a file name (including extension) for the Port Group CSV file" -foregroundColor Red
 exit
    }
Else {
    Write-Host "CSV file found..." -foregroundColor Green
    }

# Import CSV file to a variable
$VMFolderList = Import-CSV $CSVPath

# Supress Connect-VIServer warnings
Write-Host "Setting PowerCLI session configuration..." -foregroundColor Green
$Null = Set-PowerCLIConfiguration -Scope Session -DefaultVIServerMode Single -DisplayDeprecationWarnings $False -InvalidCertificateAction Ignore -Confirm:$False

# Get credentials for vCenter
$vCCReds = Get-Credential -Message "Please enter credentials for the vCenter"

# Try to connect to vCenter
Write-Host "Attempting to connect to $vCServer..." -ForegroundColor Yellow
Try {
Connect-VIServer -Server $vCServer -Credential $vCCReds -ErrorAction Stop
}
Catch {
	Write-Host $_
    Write-Host "Connection to the vCenter $vcServer failed. Please resolve and re-run script." -ForegroundColor Red
    exit
    }
Write-Host "Connected to vCenter..." -ForegroundColor Green

#Move VMs based on CSV file
Write-Host ""
Write-Host "The script will now attempt to folders defined in the CSV file..." -ForegroundColor Yellow


    ForEach ($VMsFolder in $VMFolderList){
           Try {
                $VMName = $VMsFolder.vmName
                $Null = Move-VM -VM $VMName -Destination $DHost -ErrorAction Stop
                Write-Host "VM:" $VMName "successfully moved to " $DHost -ForegroundColor Green
                }
            Catch {
                Write-Host "Move failed for" $VMName -ForegroundColor Red
                  }
        }
 

# Confirm script has completed
Write-Host "The script has now completed..." -ForegroundColor Yellow
