# Script Parameters
[CmdletBinding()]
Param(
  [Parameter(Mandatory=$True,Position=1)]
   [string]$vCServer,

   [Parameter(Mandatory=$True)]
   [string]$NexusName,

   [Parameter(Mandatory=$True)]
   [string]$NexusUplink,
	
   [Parameter(Mandatory=$True)]
   [string]$vSSName,

   [Parameter(Mandatory=$True)]
   [string]$HostName
)

#Functions
Function Exit{
    Pause
    Break
}

# Confirm Script is being run in PowerCLI
Try{
$Null = Get-PowerCLIVersion
}
Catch {
Write-Host "You do not appear to be running this script from a PowerCLI console. The script has terminated, please run the script from PowerCLI."-ForegroundColor Red
exit
}

# Supress Connect-VIServer warnings
Write-Host "Setting PowerCLI session configuration..." -foregroundColor Green
$Null = Set-PowerCLIConfiguration -Scope Session -DefaultVIServerMode Single -DisplayDeprecationWarnings $False -InvalidCertificateAction Ignore -Confirm:$False

# Get credentials for vCenter
$vCCReds = Get-Credential -Message "Please enter credentials for the vCenter"

# Try to connect to vCenter
Write-Host "Attempting to connect to $vCServer..." -ForegroundColor Yellow
Try {
Connect-VIServer -Server $vCServer -Credential $vCCReds -ErrorAction Stop
}
Catch {
	Write-Host $_
    Write-Host "Connection to the vCenter $vcServer failed. Please resolve and re-run script." -ForegroundColor Red
    exit
    }
Write-Host "Connected to vCenter..." -ForegroundColor Green

# Remove Uplink from host

Write-Host ""
Write-Host "The script will now attempt to remove the uplink" $NexusUplink  "from"  $HostName  "..." -ForegroundColor Yellow
$PUplinkCount = (Get-VMHostNetworkAdapter -VMHost $HostName -Physical).Count
$UplinkStatus = (Get-VMHost -Name $HostName | Get-VDSwitch -Name $NexusName | Get-VDPort -Uplink -ConnectedOnly | Where-Object ProxyHost -like $HostName).Count

if ($UplinkStatus -eq "2") {
Write-Host ""
Write-Host "Amount of Uplinks on host is "  $UplinkStatus  ". Removal will proceed ..." -ForegroundColor Green
Try {
     $Null = Get-VMhost -Name $HostName | Get-VMHostNetworkAdapter -Physical -Name $NexusUplink |  Remove-VDSwitchPhysicalNetworkAdapter -ErrorAction Stop
                Write-Host "Uplink:" $NexusUplink "successfully removed from"  $HostName -ForegroundColor Green
                }
            Catch {
                Write-Host "Uplink Removal failed for host "  $HostName -ForegroundColor Red
                  }
    } Else {
            Write-Host ""
            Write-Host "Amount of uplinks is $UplinkStatus that is less than minimum 2." -ForegroundColor Red
            $message = "Do you want to proceed?"
            $skip = New-Object System.Management.Automation.Host.ChoiceDescription "&Skip","Script will continue to the next step and skip removal of $NexusUplink "
            $yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes","Script will continue to the next step and force removal of $NexusUplink "
            $no = New-Object System.Management.Automation.Host.ChoiceDescription "&No","The Script will terminate."
            $options = [System.Management.Automation.Host.ChoiceDescription[]]($skip, $yes, $no)
            $choice = $host.ui.PromptForChoice("",$message, $options, 2) 
        switch ($choice){
        0 {
             Write-Host "Removal of $NexusUplink from $Hostname was skipped" -ForegroundColor DarkYellow
        }
        1 {
            Write-Host "Removal is progressing.." -ForegroundColor Cyan
            Try {
                $Null = Get-VMhost -Name $HostName | Get-VMHostNetworkAdapter -Physical -Name $NexusUplink |  Remove-VDSwitchPhysicalNetworkAdapter -ErrorAction Stop
                Write-Host "Uplink:" $NexusUplink "successfully removed from"  $HostName -ForegroundColor Green
                }
            Catch {
                Write-Host "Uplink Removal failed for host "  $HostName -ForegroundColor Red
                Exit
                }
        
        }
       2 {
            Write-Host "You have chosen not to continue, the script has terminated" -ForegroundColor Red;Exit}
           }
          }
      


# Add VNIC to Standard switch

Write-Host ""
Write-Host "Adding new uplink to $vSSName on Host $HostName ..." -ForegroundColor yellow
Try {
     $exec = Get-VMhost -Name $HostName | Get-VMHostNetworkAdapter -Physical -Name $NexusUplink
     $Null = Get-VirtualSwitch -VMHost $HostName -Name $vSSName | Add-VirtualSwitchPhysicalNetworkAdapter -VMHostPhysicalNic $exec -ErrorAction Stop
     Write-Host "Uplink: $NexusUplink successfully added to $vSSName" -ForegroundColor Green
     } Catch {
                Write-Host "Uplink Add Action failed for host "  $HostName -ForegroundColor Red
                Exit
             }





# Confirm script has completed
Write-Host "The script has now completed..." -ForegroundColor Yellow
