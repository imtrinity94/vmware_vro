import threading
import logging
import pyVmomi
import httplib
from pyVmomi import VmomiSupport
import time

class ProfilerInstance:
   def __init__(self, profiler, name):
      self.profiler = profiler
      self.name = name
      self.start = None
   
   def __enter__(self):
      assert(self.start == None)
      self.start = time.time()
   
   def __exit__(self, type, value, traceback):
      t = time.time() - self.start
      self.profiler.addProfileResult(self.name, t)
      self.start = None

class Profiler:
   def __init__(self):
      self.times = {}
      self.lock = threading.Lock()

   def run(self, name):
      return ProfilerInstance(self, name)
   
   def reset(self):
      with self.lock:
         self.times = {}
   
   def addProfileResult(self, name, t):
      with self.lock:
         self.times.setdefault(name, [])
         self.times[name].append(t)

   def log(self):
      with self.lock:
         logging.warning("Profiler: ")
         for name in sorted(self.times):
            times = [("%.2fs" % t) for t in self.times[name]]
            logging.warning("  %s: %s" % (name, ", ".join(times)))

class ProfiledSoapStubAdapter:
   def __init__(self, stub, profiler):
      self._stub = stub
      self.profiler = profiler
      self.version = self._stub.version
      self.host = stub.host
   
   def InvokeMethod(self, mo, info, args, outerStub=None):
      logging.warning("Invoke: mo=%s, info=%s" % (str(mo._moId), str(info.name)))
      with self.profiler.run('invoke-method:%s:%s' % (mo._moId, info.name)):
         out = self._InvokeMethod(mo, info, args)
         return out

   def _InvokeMethod(self, mo, info, args):
      req = self._stub.SerializeRequest(mo, info, args)
      conn = self._stub.GetConnection()
      conn.request('POST', self._stub.path, req, {'Cookie' : self._stub.cookie,
                                                  'SOAPAction' : self._stub.versionId})
      resp = conn.getresponse()
      cookie = resp.getheader('set-cookie')
      status = resp.status
      if cookie:
         self._stub.cookie = cookie
      if status == 200 or status == 500:
         try:
            ds = pyVmomi.SoapAdapter.SoapResponseDeserializer(self)
            #obj = ds.Deserialize(resp, info.result)
            respStr = resp.read()
            logging.warning("Invoke-GotResult: mo=%s, info=%s, res=: %s" %
                            (str(mo._moId), str(info.name), respStr))
            obj = ds.Deserialize(respStr, info.result)

         finally:
            resp.read()
            self._stub.ReturnConnection(conn)
         if status == 200:
            return obj
         else:
            logging.critical("Call to '%s' failed.", info.name)
            raise obj
      else:
         conn.close()
         raise httplib.HTTPException("%d %s" % (resp.status, resp.reason))

   def SerializeRequest(self, mo, info, args):
      return self._stub.SerializeRequest(mo, info, args)
   
   def ComputeVersionInfo(self, version):
      return self._stub.ComputeVersionInfo(version)
   
   def InvokeAccessor(self, mo, info):
      logging.warning("Invoke: mo=%s, info=%s" % (str(mo._moId), str(info.name)))
      with self.profiler.run('invoke-accessor:%s:%s' % (mo._moId, info.name)):
         out = self._InvokeAccessor(mo, info)
         return out

   def _InvokeAccessor(self, mo, info):
      prop = info.name
      param = VmomiSupport.Object(name="prop", type=str, version=VmomiSupport.BASE_VERSION, flags=0)
      info = VmomiSupport.Object(name=info.name, type=VmomiSupport.ManagedObject, wsdlName="Fetch",
                    version=info.version, params=(param,), result=info.type)
      return self._InvokeMethod(mo, info, (prop,))

