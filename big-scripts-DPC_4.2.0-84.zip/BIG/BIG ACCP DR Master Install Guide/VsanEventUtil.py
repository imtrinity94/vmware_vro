"""
Copyright 2015 VMware, Inc.  All rights reserved.
-- VMware Confidential

"""
__author__ = "VMware, Inc"

import os
import re
import time
import logging
import threading
from pyVmomi import Vim, vim, vmodl
from VsanConfigUtil import VsanHealthConfig
from L10N.textHandler import TextProvider
from L10N.errorHandler import DEFAULT_LOCALE
from VsanVcClusterUtil import FindAllVcClusters

class VsanEventMonitor(object):
   _HEALTH_TEST_PREFIX = 'com.vmware.vsan.health.test.'
   # To avoid the event/alarm ID exceed the maximum allowed length during
   # register extension, we use shorter event/alarm ID prefix. So the event
   # ID format will be 'vsan.health.test.$groupid.$testid.event'.
   _HEALTH_EVENT_PREFIX = 'vsan.health.test.'
   _HEALTH_USER = 'com.vmware.vsan.health'
   # Default VSAN health check interval when it's enabled (1 hour)
   _DEFAULT_HEALTH_CHECK_INTERVAL = 60
   # Default daemon interval (1 minutes). The daemon will check the interval setting
   # periodically and trigger the health check when it reaches the interval.
   _DEFAULT_DAEMON_INTERVAL = 1

   def __init__(self, vsanVcClusterHealthSystem):
      self.vcchs = vsanVcClusterHealthSystem
      # We only need keep the latest health check result for each of cluster
      self.clusterHealthCheckResult = {}

      self.healthCheckInterval = self._DEFAULT_HEALTH_CHECK_INTERVAL
      # The tick for VSAN health check, when the tick is 0, we will trigger
      # VSAN health check
      self.healthCheckIntervalTick = \
         self.healthCheckInterval / self._DEFAULT_DAEMON_INTERVAL
   
   def startVsanEventMonitor(self):
      logging.info("Start VSAN Health Event Daemon Thread...")

      # Build VSAN health check summary according to the historical VC event for the clusters
      # which is used for as the baseline to trigger the new VSAN health event against
      # the current VSAN cluster health status
      def _buildVsanHealthSummaryFromEvent(vcchs,  clusters):
         from VsanHealthHelpers import aggregateHealth
         # Rebuild VSAN health check result from event
         # Map for the VC cluster and the VSAN health check result
         clusteredHealthResult = {}

         # Get historical VSAN health event for each of cluster
         for cluster in clusters:
            # Search VC historical event
            eventFilterSpec = vim.EventFilterSpec(
               userName = vim.EventFilterSpecByUsername(
                  systemUser = False,
                  userList = [self._HEALTH_USER]
               ),
               entity = vim.EventFilterSpecByEntity(
                  entity = cluster,
                  recursion = 'self'
               )
            )
            events = vcchs.conn.em.QueryEvents(filter=eventFilterSpec)

            # The map for testId and latest event for this health test
            clusteredEvents = {}

            for event in events:
               #filter event not belongs to VSAN health check
               if not hasattr(event, 'eventTypeId') or \
                  event.eventTypeId is None or \
                  not event.eventTypeId.startswith(self._HEALTH_EVENT_PREFIX):
                  continue

               cluster = event.computeResource.computeResource
               if cluster is None:
                  continue
               assert isinstance(cluster, vim.ClusterComputeResource)

               # Get testID from event type Id
               testId,groupId = VsanEventUtil.getHealthTestGroupIdFromEvent(event)
               logging.info("Get group id %s from test id %s" % (groupId, testId))

               # We only rebuild the individual test item from event
               # The group status and overall status can be inferred from
               # each of individual test result to make sure it's compatible
               if testId == None or groupId == None or testId == groupId:
                  continue

               groupedEvents = clusteredEvents.setdefault(groupId, {})
               # Check if there are duplicated event with the same test id
               # If have, we choose the latest one
               if testId not in groupedEvents or \
                  event.createdTime > groupedEvents[testId].createdTime:
                  groupedEvents[testId] = event
               else:
                  continue

            #Rebuild VSAN health check result from event for each of cluster
            logging.info("Rebuild health check result from the cluster %s" % cluster)
            if cluster not in clusteredHealthResult:
               clusteredHealthResult[cluster] = vim.cluster.VSANClusterHealthSummary(
               overallHealth = 'green', #Default status
               groups = []
            )
            healthResult = clusteredHealthResult[cluster]

            for groupId in clusteredEvents:
               groupedEvents = clusteredEvents[groupId]
               groupTest = vim.cluster.VSANClusterHealthGroup(
                     groupId = groupId,
                     groupName = "Group Test for " + groupId,
                     groupHealth = 'green', #Set green as default value
                     groupTests = []
               )
               healthResult.groups.append(groupTest)

               testHealths = []
               for testId in groupedEvents:
                  event = groupedEvents[testId]

                  testName, preStatus, curStatus = \
                     VsanEventUtil.getHealthStatusFromEvent(event)

                  # Skip those events/tests which hasn't group ID
                  if testName is None or groupId is None:
                     continue

                  # Add individual health test result into the group test result
                  groupTest.groupTests.append(
                     vim.cluster.VSANClusterHealthTest(
                        testId = testId,
                        testName = testName,
                        testHealth = curStatus
                     )
                  )

                  # Bug Fix 1460929: update the group health by health
                  # aggregation
                  testHealths.append(curStatus)
               groupTest.groupHealth = aggregateHealth(testHealths)

            healthResult.overallHealth = aggregateHealth([g.groupHealth for \
                 g in healthResult.groups])
         logging.info("Get cluster health result from event : %s" % clusteredHealthResult)
         return clusteredHealthResult

      # Trigger VSAN Health Check Event when the status of any of health check item has been changed
      # including the overall VSAN cluster health status, each of group health check status and
      # each of individual health check item status
      #
      # The event format is like "VSAN Health Test '%testName' status changed from %preStatus" to %curStatus
      def _generateVcEvent(vcchs, groupId, testId, testName, previousStatus, currentStatus, cluster):
         clusterName = cluster.name
         logging.info("Generate VC event for cluster %s with \n, \
                   testName =%s, testId=%s, \n preStatus=%s, curStatus=%s" % \
                      (clusterName, testName, testId, previousStatus, currentStatus)
         )
         # We don't need define message for the event because \
         # it already has been registered into extension as L10N resource
         event = vim.EventEx(
            eventTypeId = VsanEventUtil.getHealthEventTypeIdFromTestId(groupId, testId),
            chainId = 0,
            createdTime = vcchs.getCurrentTime(),
            key = 0,
            userName = self._HEALTH_USER,
            severity = VsanEventUtil.getEventServityFromStatus(currentStatus),
            computeResource = vim.ComputeResourceEventArgument(
               computeResource = cluster,
               name = clusterName
            )
         )
         event.SetArguments([
            vmodl.KeyAnyValue(
               key = 'prestatus',
               value = previousStatus
            ),
            vmodl.KeyAnyValue(
               key = 'curstatus',
               value = currentStatus
            ),
         ])

         logging.info("Post event = %s" % str(event))
         vcchs.conn.em.PostEvent(eventToPost=event)

      # Trigger event for those test items which is not in green status in the group test result
      #
      # Refer to the comments in _triggerUnhealthVsanEvent() for the reason
      def _triggerUnhealthTestGroupEvent(vcchs, curHealthGroup, cluster, previousStatus='unknown'):
         if curHealthGroup.groupHealth != 'green':
            _generateVcEvent(vcchs,
                             curHealthGroup.groupId,
                             curHealthGroup.groupId,
                             curHealthGroup.groupName,
                             previousStatus,
                             curHealthGroup.groupHealth,
                             cluster)
            for curHealthResultItem in curHealthGroup.groupTests:
               if curHealthResultItem.testHealth != 'green':
                  _generateVcEvent(vcchs, curHealthGroup.groupId,
                                   curHealthResultItem.testId,
                                   curHealthResultItem.testName,
                                   previousStatus,
                                   curHealthResultItem.testHealth,
                                   cluster)

      # Trigger event for those test items which is not in green status in the VSAN cluster health check result
      #
      # When the VSAN health service is started up, it's possible that VC doesn't include any health related 
      # event to rebuild the last health check result as the baseline to trigger new event. If the VSAN cluster
      # is not in green state, it will never report any event and alarm. To address this issue, we will report
      # events for the issued test items against the VSAN cluster whenever the VSAN health service is started
      def _triggerUnhealthVsanEvent(vcchs, curHealthResult, cluster):
         if curHealthResult.overallHealth != 'green':
            _generateVcEvent(vcchs,
                             'vsan.health.test.overallsummary',
                             'vsan.health.test.overallsummary',
                             'OverallSummary',
                             'unknown',
                             curHealthResult.overallHealth,
                             cluster)
         for curHealthGroup in curHealthResult.groups:
            _triggerUnhealthTestGroupEvent(vcchs, curHealthGroup, cluster)

      def _triggerVsanHealthCheckEvent(vcchs, curHealthResult, lastHealthResult, cluster):
         if curHealthResult is None:
            return

         if lastHealthResult is None:
            # If there is no last health result,
            # we will post event for the current unhealth test item result
            logging.info('Trigger VSAN health event for unhealth test items')
            _triggerUnhealthVsanEvent(vcchs, curHealthResult, cluster)
            return

         logging.info('Trigger VSAN health event based on the last health check result')
         #Check overall health result
         if curHealthResult.overallHealth != lastHealthResult.overallHealth:
            _generateVcEvent(vcchs,
                             'vsan.health.test.overallsummary',
                             'vsan.health.test.overallsummary',
                             'OverallSummary',
                             lastHealthResult.overallHealth,
                             curHealthResult.overallHealth,
                             cluster)

         # Check group health result
         # Considering the order of group health check may be changed in the groups result
         # We need query the group result according to group ID
         lastHealthGroups = dict([(g.groupId, g) for g in lastHealthResult.groups])

         for curHealthGroup in curHealthResult.groups:
            if curHealthGroup.groupId not in lastHealthGroups:
               # If there is no last health check result for the current test group,
               # we should trigger the unhealth status event for each of test item in the group
               #
               # This situation can happen when the current health check result contains
               # new check group than that of last one. For example, if the last health result is
               # rebuilt from event, it may don't include all of health check result. In this situation,
               # we will report the unhealth check item event, otherwise, no any event & alarm will
               # be triggered for the unhealth VSAN cluster
               _triggerUnhealthTestGroupEvent(vcchs=vcchs,
                                              curHealthGroup=curHealthGroup,
                                              cluster=cluster,
                                              previousStatus='green')
               continue

            lastHealthGroup = lastHealthGroups[curHealthGroup.groupId]

            if curHealthGroup.groupHealth != lastHealthGroup.groupHealth:
               _generateVcEvent(vcchs, 
                                curHealthGroup.groupId,
                                curHealthGroup.groupId,
                                curHealthGroup.groupName,
                                lastHealthGroup.groupHealth,
                                curHealthGroup.groupHealth,
                                cluster)

            lastHealthTests = dict([(test.testId, test) for test in lastHealthGroup.groupTests])
            # Check the individual health check result
            for curHealthResultItem in curHealthGroup.groupTests:
               # We need consider the case that a specific test will only appear when there is issue 
               # like physical disk status retrieve issue when host is disconnected

               # If current health result has one test while it's not included in last result,
               # it indicates the last health check result for this item is green
               if curHealthResultItem.testId not in lastHealthTests:
                  if curHealthResultItem.testHealth != 'green':
                     _generateVcEvent(vcchs, curHealthGroup.groupId,
                                      curHealthResultItem.testId,
                                      curHealthResultItem.testName,
                                      'green',
                                      curHealthResultItem.testHealth,
                                      cluster)
               else:
                  lastHealthResultItem = lastHealthTests[curHealthResultItem.testId]

                  if curHealthResultItem.testHealth != lastHealthResultItem.testHealth:
                     _generateVcEvent(vcchs,
                                      curHealthGroup.groupId,
                                      curHealthResultItem.testId,
                                      curHealthResultItem.testName,
                                      lastHealthResultItem.testHealth,
                                      curHealthResultItem.testHealth,
                                      cluster)

            curHealthTests = dict([(test.testId, test) for test in curHealthGroup.groupTests])
            # If one of last health check result item is not included in current health check result,
            # it indicates the current health check status for this item is green
            for lastHealthResultItem in lastHealthGroup.groupTests:
               if lastHealthResultItem.testId not in curHealthTests and \
                  lastHealthResultItem.testHealth != 'green':
                  _generateVcEvent(vcchs,
                                   lastHealthGroup.groupId,
                                   lastHealthResultItem.testId,
                                   lastHealthResultItem.testName,
                                   lastHealthResultItem.testHealth,
                                   'green',
                                   cluster)

      def triggerVsanHealthEventCollectorMain(self, clusters):
         si = self.vcchs.conn.si

         for cluster in clusters:
            clusterName = cluster.name
            clusterId = cluster._moId
            try:
               from VsanVcClusterHealthSystemImpl import GetClusterHostInfos
               hostInfos = GetClusterHostInfos(
                  si, cluster,
                  includeDisconnected = True
               )
               # FIX PR 1482608. When the cluster is disabled, we will skip the trigger VSAN
               # health event and clean the cached health check result for the cluster. And
               # we should use the unified method _GetClusterInstallStatus() to check the VSAN
               # health installation status for the cluster
               clusterStatus = self.vcchs._GetClusterInstallStatus(cluster, hostInfos)
               if clusterStatus['goalState'] == 'uninstalled' and \
                  clusterStatus['status'] == 'green':
                  if clusterId in self.clusterHealthCheckResult:
                     del self.clusterHealthCheckResult[clusterId]
                  continue

               curHealthResult = self.vcchs._QueryClusterHealthSummary(cluster, hostInfos)

               lastHealthResults = None
               # Get last VSAN health check result and trigger
               # SAN health event if exists last health check result
               if clusterId in self.clusterHealthCheckResult:
                  logging.info("Get last VSAN health check result for cluster '%s'" % clusterName)
                  lastHealthResults =  \
                     self.clusterHealthCheckResult[clusterId]

               _triggerVsanHealthCheckEvent(self.vcchs,
                                            curHealthResult,
                                            lastHealthResults,
                                            cluster)

               logging.info("Add latest VSAN health check result into cache for cluster '%s'" % \
                            clusterName)
               #Save latest health check result into result cache
               self.clusterHealthCheckResult[clusterId] = curHealthResult

            except Exception as e:
               logging.error("Failed to trigger VSAN cluster '%s' health check event : %s" % \
                             (clusterName, str(e))
               )

      def setHealthCheckIntervalTick(newInterval):
         self.healthCheckIntervalTick = \
            newInterval / self._DEFAULT_DAEMON_INTERVAL \
            if newInterval > self._DEFAULT_DAEMON_INTERVAL else 1

      def triggerVsanHealthEventCollector(self):
         #rebuild the last VSAN health check result from historical VC event data
         try:
            content = self.vcchs.conn.si.content
            # Fix PR1493471. The cluster without enabling VSAN should be skipped for triggering
            # VSAN health event and also shouldn't perform periodical health check
            clusters = FindAllVcClusters(content, content.rootFolder, includeVsanEnabledOnly=True)
            clusterHealthResult = _buildVsanHealthSummaryFromEvent(self.vcchs, clusters)
            for cluster in clusterHealthResult:
               self.clusterHealthCheckResult[cluster._moId] = clusterHealthResult[cluster]

            # Trigger the health check event collection at startup
            triggerVsanHealthEventCollectorMain(self, clusters)
         except Exception as e:
            logging.error("Failed to build VSAN health check result from event : %s" % str(e))

         while True:
            #Get VSAN health event collector interval.Default is 1 hour
            intervalInMin = int(VsanHealthConfig.getVsanHealthConfig(section="General",
                                                                     option="vsanBasicHealthCheckInterval",
                                                                     defaultValue=self._DEFAULT_HEALTH_CHECK_INTERVAL))

            # If the interval is equal or less than 0
            # we will disable the VSAN health check
            if intervalInMin > 0:
               if self.healthCheckInterval != intervalInMin:
                  # Reset the health check interval tick when the interval is updated
                  setHealthCheckIntervalTick(intervalInMin)
                  self.healthCheckInterval = intervalInMin

               if self.healthCheckIntervalTick <= 0:
                  # Retrieve current VC cluster
                  content = self.vcchs.conn.si.content
                  clusters = FindAllVcClusters(content, content.rootFolder, includeVsanEnabledOnly=True)
                  triggerVsanHealthEventCollectorMain(self, clusters)
                  # Reset the health check interval tick
                  setHealthCheckIntervalTick(self.healthCheckInterval)
               else:
                  self.healthCheckIntervalTick -= 1

            time.sleep(self._DEFAULT_DAEMON_INTERVAL * 60)

      thread = threading.Thread(target=triggerVsanHealthEventCollector,
                                args = (self, ))
      thread.daemon = True
      thread.start()

class VsanEventUtil(object):
   # Extract all of health event ID from event definition file
   # The VSAN health event ID format is "vsan.health.test.$groupId.$testId.event"
   resourcePath = os.path.join(os.path.dirname(__file__), "healthResources", "locale", "{0}", "event.vmsg")
   healthTextProvider = TextProvider(resourcePath)
   eventIds = set()
   for key in healthTextProvider.languageDict[DEFAULT_LOCALE]:
      if key.startswith(VsanEventMonitor._HEALTH_EVENT_PREFIX) and \
         key.endswith("description"):
         try:
            eventIds.add(key[:key.find('.description')])
         except:
            pass
   eventIds = list(eventIds)

   def __init__(self):
      pass

   @classmethod
   def getEventServityFromStatus(cls, status):
      if status == 'green':
         return 'info'
      elif status == 'yellow':
         return 'warning'
      elif status == 'red':
         return 'error'
      else:
         return 'info'

   @classmethod
   def getHealthEventDesc(cls, eventId):
      return cls.healthTextProvider.get_text(DEFAULT_LOCALE, eventId + ".description")

   # Get event ID from groupId and testId.
   # The event ID format is "vsan.health.test.$gid.$tid.event"
   # and the test ID format is "com.vmware.vsan.health.test.$gid.$tid"
   @classmethod
   def getHealthEventTypeIdFromTestId(cls, groupId, testId):
      if groupId != testId and \
         groupId.startswith(VsanEventMonitor._HEALTH_TEST_PREFIX) and \
         testId.startswith(VsanEventMonitor._HEALTH_TEST_PREFIX):
            return "%s%s.%s.event" % (VsanEventMonitor._HEALTH_EVENT_PREFIX, \
                                      groupId.split('.')[-1], \
                                      testId.split('.')[-1])

      return groupId.replace("com.vmware.", "") + ".event"

   @classmethod
   def getHealthTestGroupIdFromEvent(cls, event):
      eventId = event.eventTypeId
      if eventId is not None and eventId.endswith('.event'):
         fullTestId = eventId[:eventId.find('.event')]
         testgroupId = fullTestId.replace(VsanEventMonitor._HEALTH_EVENT_PREFIX, "").split(".")
         if len(testgroupId) > 0:
            groupId = VsanEventMonitor._HEALTH_TEST_PREFIX + testgroupId[0]
            testId = VsanEventMonitor._HEALTH_TEST_PREFIX + testgroupId[1] \
                      if len(testgroupId) > 1 else groupId
            return testId, groupId
      return None, None
   
   @classmethod
   def getAllHealthEventTypeIds(cls):
      return [eventId for eventId in cls.eventIds]

   @classmethod
   def getHealthStatusFromEvent(cls, event):
      testName = None
      preStatus = None
      curStatus = None
      if event is not None and event.fullFormattedMessage is not None:
         # The VSAN health event message has the format like
         # "Virtual SAN Health Test 'test' change status from 'green' to 'red'"
         # test name will be in the first section of ' '
         # previous status will be in the second section of ' '
         # current status will be in the third section of ' '

         # And for supporting L10N, we cannot hardcode the event message pattern with english
         # so we use wildcard for match any character in the string
         formatmessage = re.search('(.*) \'(.*)\' (.*) \'(.*)\' (.*) \'(.*)\'',
                                   event.fullFormattedMessage)

         # The formatmessage.groups() will be the list with 6 elements like
         # ('Virtual SAN Health Test', 'test1', 'change status from', 'green', 'to', 'red')
         if formatmessage == None or len(formatmessage.groups()) != 6:
            logging.error("Invalid VSAN health event message format : %s" % \
                          event.fullFormattedMessage)
         else:
            testName = formatmessage.group(2)
            preStatus = formatmessage.group(4)
            curStatus = formatmessage.group(6)

      return (testName, preStatus, curStatus)

   '''
   Get the alarm ID from the given testId
   The alarm ID format is "alarm.testId"
   '''
   @classmethod
   def getAlarmIdFromEventId(cls, eventId):
      return "alarm.%s" % eventId[:eventId.find('.event')]

   """
   Get the unregistered alarms for the given test ID list on the entity

   :param content: The content for the VC connection
   :param mo:      The VC entity which the alarm will be associated with
   :param testId: The test ID list
   """
   @classmethod
   def _getUnRegisterTestId(cls, content, mo, eventIds):
      am = content.alarmManager
      alarms = am.GetAlarm(mo)
      # Extract eventId from alarm
      eventIdFromAlarm = []
      for alarm in alarms:
         try:
            if alarm.info.expression is None or \
               not isinstance(alarm.info.expression, vim.alarm.OrAlarmExpression):
               continue
            expressions = alarm.info.expression.expression
            if len(expressions) > 0 and \
               isinstance(expressions[0], vim.alarm.EventAlarmExpression) and \
               expressions[0].eventTypeId is not None:

               eventTypeId = expressions[0].eventTypeId
               if eventTypeId is not None:
                  eventIdFromAlarm.append(eventTypeId)
         except Exception as ex:
            logging.info("Cannot get the alarm info %s" % str(ex)) 

      unregisterNames = [eventId for eventId in eventIds if eventId not in eventIdFromAlarm]

      return unregisterNames

   """
   Register alarm for the list of testIds

   :param content: The content for the VC connection
   :param mo:      The VC entity which the alarm will be associated with
   :param testIds: The testId list each of test Id will be registered as an alarm
   :param enable : If the alarm is enabled by default
   """
   @classmethod
   def registerAlarm(cls, content, mo, eventIds, enable):
      am = content.alarmManager
      unregisterEventIds = cls._getUnRegisterTestId(content, mo, eventIds)

      for eventTypeId in unregisterEventIds:
         alarmId = cls.getAlarmIdFromEventId(eventTypeId)

         expressions = []
         for status in ['green', 'yellow', 'red']:
            equalOp = 'equals'

            expressions.append(
               vim.alarm.EventAlarmExpression(
                  eventType = vim.event.EventEx,
                  eventTypeId = eventTypeId,
                  objectType = vim.ClusterComputeResource,
                  comparisons = [
                     vim.EventAlarmExpressionComparison(
                        attributeName = 'curstatus',
                        value = status,
                        operator = equalOp,
                     )
                  ],
                  status = status
               )
            )

         setting = vim.alarm.AlarmSetting(
            toleranceRange = 0,
            reportingFrequency = 0
         )

         spec = vim.alarm.AlarmSpec(
            name = alarmId,
            systemName = alarmId,
            actionFrequency = 0,
            description = "Alarm for event (%s)" % eventTypeId,
            enabled = enable,
            expression = vim.alarm.OrAlarmExpression(
               expression = expressions
            ),
            setting = setting
         )

         am.CreateAlarm(mo, spec)

   """
   Register alarms for VSAN health service on the VC and
   propagated to all of children clusters

   :param content: The content for the VC connection
   """
   @classmethod
   def registerHealthAlarms(cls, content):
      try:
         cls.registerAlarm(content, content.rootFolder, cls.eventIds, enable=True)
      except Exception as e:
         logging.error("Failed to register health alarm : %s" % str(e))
