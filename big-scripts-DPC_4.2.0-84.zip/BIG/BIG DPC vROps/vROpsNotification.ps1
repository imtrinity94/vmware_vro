﻿param([string]$EventServer, [string]$EventDescription)
#
#	Ignore the self signed certificates
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
#
#Just for testing, fill the parameters
#$EventServer = "ADEVWGREEPO001"
#$EventDescription = "Testing Master Repository Update "
#
# Set the log file and write initial content
$LogFile = "C:\vrops\vROpsNotification.log"
Add-content $LogFile ""
Add-content $LogFile "*** vROps Notification called at $(Get-Date)"
Add-content $LogFile "EventServer: $EventServer"Add-content $LogFile "EventDescription: $EventDescription"Add-content $LogFile ""
#
#	Initialize the credentials used to connect to vROps
$username = "epo_alert"
$password = "FromEPO5!1"
$secPw = ConvertTo-SecureString $password -AsPlainText -Force
$cred = New-Object PSCredential -ArgumentList $username,$secPw
#
#	Set the needed variables
$vropsserver = "ADEVLGREOPS005.devdpc.local"
$BaseUrl = "https://" + $vropsserver.ToString() + "/suite-api/api"
$Headers = @{}
$TimeOut = 30
#
#	Set the API string for getting the resource-id of the server
$api = "/resources?regex=$EventServer"
#
#	Create the url to get te resource-id
$uri = $BaseUrl + $api
#
#	Write the url used to the display
Add-content $LogFile "Call vROps with: $uri"
#
#	Use REST to get the resource-id, for straange reasons sometimes the first attempt does not work
$TryAgain = $false
Try {
    $data = Invoke-RestMethod -Method Get -Uri $uri -Credential $cred -Headers $Headers -TimeoutSec $TimeOut
}
Catch {
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Add-content $LogFile "Error calling vROps: $ErrorMessage at $(Get-Date)"
    Add-content $LogFile ""
    $TryAgain = $true
}
if ($TryAgain) {
    Add-Content $LogFile "Second Attpemt to call vROps"
    $TryAgain = $false
    Try {
        $data = Invoke-RestMethod -Method Get -Uri $uri -Credential $cred -Headers $Headers -TimeoutSec $TimeOut
    }
    Catch {
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
        Add-content $LogFile "Error calling vROps: $ErrorMessage at $(Get-Date)"
        Add-content $LogFile ""
        Break
    }
}
$NoResources = $data.resources.pageInfo.totalCount
Add-content $LogFile "Number of resources found is $NoResources"

If ( $NoResources -eq "1" ) {
    $Resource = $data.resources.resource.identifier
    Add-content $LogFile ("Resource-id of server is " + $data.resources.resource.identifier)

#
#      Now raise the alert
    $AlertString = "EPO $EventServer $EventDescription at " + (Get-Date)
#
#	   Set the API string for posting an Alert
    $api = "/events"
#
#	   Create the url to get te resource-id
    $uri = $BaseUrl + $api
#
#	   Create the Alert body
    $body = @{}
    $body.eventType = "NOTIFICATION"
    $body.resourceId = $Resource
    $tmpdate=get-date (get-date).touniversaltime() -uformat "%s"
    $tmpdate=$tmpdate.split(".")[0]
    $body.startTimeUTC= ([convert]::ToInt32($tmpdate, 10))*1000
    $body.message = $AlertString
    $body.severity="CRITICAL"
    $body.managedExternally="TRUE"
    $body.others=@()
    $body.otherAttributes=@{}
    $sendbody = ConvertTo-Json $body
    $sendbody = $sendbody.Replace("""TRUE""","true")
#
#      Change the headers for the Alert
    $Headers = @{}
    $Headers.Accept="application/json"
    $Headers.add("Content-Type","application/json")
#
#	Write the url and body used to the log file
    Add-content $LogFile "Call vROps with: $uri"
    Add-Content $LogFile "and alert body:"
    Add-content $LogFile $sendbody
    Exit-PSSession
    Try {
       $data = Invoke-RestMethod -Method Post -Uri $uri -Credential $cred -Body $sendbody -Headers $Headers -ContentType 'application/json' -TimeoutSec $TimeOut
    }
    Catch {
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
        Add-content $LogFile "Error calling vROps: $ErrorMessage at $(Get-Date)"
        Add-content $LogFile ""
    }
    $data
} else
{
    Add-Content $LogFile "Quit without raising the Alert"
}