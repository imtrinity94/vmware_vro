# Author : Piotr Lewandowski  <piotr.lewandowski@atos.net>
# Version : 1.0
# For ACCP VCM Patch Repo Synchonization, use repos.txt in the same folder.

$sourcerepo = read-host 'Please provide the source path (eg. "\\AACPWGREVCM001\PatchRepo")'
$source = gci $sourcerepo | ?{(!$_.psiscontainer)}
$credentials = Get-Credential -Message "Please provide credentials to copy files"
$Repos = Get-Content .\repos.txt 


foreach ($repo in $repos)
    {
    $destination = gci $repo | ?{(!$_.psiscontainer)}
        if ($destination)
        {
        $result = (Compare-Object -ReferenceObject $source -DifferenceObject $destination | ? {$_.sideindicator -eq "<="}).inputobject.fullname
        }
        else
        {
        $result = $source.FullName
        }

    foreach ($file in $result)
        {
        Write-Output "copying $file to $repo"
        #Copy-Item -LiteralPath $file -Destination $repo -Credential $credentials
        Start-BitsTransfer -Source $file -Destination $repo -Credential $credentials
        }
    }
