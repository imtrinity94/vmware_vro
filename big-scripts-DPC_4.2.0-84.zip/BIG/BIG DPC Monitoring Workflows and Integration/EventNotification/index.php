<?php

//		Function to log messages to file
    function addLog($logfile, $state, $content){
        $fp = fopen($logfile, 'a');
        fwrite($fp, "##########".date("Y-m-d H:i:s")."###"."_".$state."_##########".PHP_EOL);
        fwrite($fp, $content.PHP_EOL);
        fclose($fp);
    }

include("config.php"); 

//	Log the SOAP message received from ServiceNow to the log
addLog($rest_logs,"START",$parameters[0]["value"]);

$curl = curl_init();
//	Set the url for starting the Incident management - Callback event workflow in the monitoring vRO using REST
$rest_url = "https://$rest_host:8281/vco/api/workflows/$rest_workflow/executions" ;

//	Set the parameters for the REST call to start the workflow, this contains the SOAP message from ServiceNow
//	quotes have to be escaped by back slashes
$rest_fields = "{\r\n\t\"parameters\": [\r\n\t{\r\n\t\t\"value\": {\"string\":{\"value\": \"" ;
$rest_fields .= addslashes( $parameters[0]["value"] );
$rest_fields .= "\"}},\r\n\t\t\"type\": \"string\",\r\n\t\t\"name\": \"callback_data\",\r\n\t\t\"scope\": \"local\"\r\n\t}]\r\n}\r\n" ;

//	Log the composed parameters string to file
addLog($rest_logs,"REST FIELDS",$rest_fields);

$auth = base64_encode($rest_user . ":" . $rest_pass);
addLog($rest_logs,"AUTH",$auth);

//	Prepare the complete REST message
curl_setopt_array($curl, array(
  CURLOPT_PORT => "8281",
  CURLOPT_URL => $rest_url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => $rest_fields,
//  CURLOPT_USERPWD => "$rest_user:$rest_pass",
  CURLOPT_HTTPHEADER => array(
    "accept: application/json",
//    "authorization: Basic U1ZDLUFDUC1WT1AwMUBkZXZkcGMubG9jYWw6ZG9wZXItZjdGK21iY2Y3RittYmM=",
    "authorization: Basic $auth",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));

// Make sure the certificate is not checked
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

//	Send the REST message
$response = curl_exec($curl);
$err = curl_error($curl);
addLog($rest_logs,"RESONSE",$response);

curl_close($curl);

if ($err) {
  addLog($rest_logs,"cURL ERROR",$err);
}?>
