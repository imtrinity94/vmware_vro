<?php
    $rest_logs       = "./request_withREST.log";
    $rest_host       = "adevlgre1vro007.devdpc.local";
    $rest_user       = "svc-acp-vop01@devdpc.local";
    $rest_pass       = "doper-f7F+mbcf7F+mbc";   
    $rest_workflow   = "f39d7323-88bb-48fa-9c6c-527e9dd7ebfb";

    $parameters[0]["name"]  = "callback_data";
    $parameters[0]["type"]  = "string";
    $parameters[0]["value"] = file_get_contents('php://input');
?>
