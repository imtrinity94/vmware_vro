 Add-PSSnapin vmware* -ErrorAction Stop
#sftp parameters 

#ip of the sftp server
$sftpserver="146.254.11.15"
#ssh figerprint of sftp host
$SshHostKeyFingerprint="ssh-rsa 2048 b2:4c:28:73:77:ab:11:49:8f:bf:26:e4:d9:12:b0:d2"
#directory to store ovf files on sftp
$remoteDirectory="/srv/ftp/images/"

#vsphere parameters
#name of tempalte to export
$name=#provide image name here
#vsphere server ip
$serverIP=#vsphere address
#local path to export ovf files before moving to sftp
$exportPath="D:\MasterTemplates"

$date = (Get-Date).tostring("yyyy-MM-dd")
#logfile location
$logfileLocation=$exportPath+"\logs\"
$filename = $logfileLocation + 'ImportError'+ $date + '.log'
#winscp.dll path
$winSCP="C:\Program Files (x86)\WinSCP\WinSCPnet.dll"

#email parameters
#mail from which the notification should be sent
$mailFrom="ro-cloud-epc@atos.net"
#mail to which the notification should be sent
$mailTo=@("ro-cloud-epc@atos.net","ro-gsa-sh-ux@atos.net","AISMSSiemensICSGDCWIN3@atos.net")
#SmtpServer address
$SmtpServer="139.25.208.14"


#log level type "Debug" to get mail notifications for both success and failure, type "Standard" for only error mail notification
$logLevel="Standard"


#credentials change only if the default path was changed during deploy
#sftp credentials
$credSFTPpath = $HOME+"\credentials\credSFTP.xml"
#vSphere credentials
$credpath = $HOME+"\credentials\cred.xml"
#smtp credentials
$credSMTPPath=$HOME+"\credentials\credSMTP.xml"

$log=$name+"`n"

function md5($files){
#md5 generator

	$in=$exportPath+"\"+$name


	foreach ($file in $files){
		$log+= "files md5: "+$file+" `n"
		$md5=Get-FileHash -Path $file -Algorithm MD5
		$md5.hash | Out-File $file".md5"
	}
}
$script:ErrorActionPreference = "stop"
try
{
	if(!(Test-Path -Path $logfileLocation )){
		New-Item -ItemType directory -Path $logfileLocation
	}
	if(Test-Path $exportPath"\"$name".lock"){
		$body="lock already exist for the machine"
		$body| Out-File -FilePath $filename
		exit 1
	}
	else{
		New-Item $exportPath"\"$name".lock" -type file
	}
	
	$PSCredential=Import-CliXml $credpath
	$SMTPCredential=Import-CliXml $credSMTPPath
	Connect-VIServer -Server $serverIP -Credential $PSCredential
	$log+="Connection to vsphere succesfull `n"
	$vm=Get-VM -Name $name -ErrorAction SilentlyContinue
	if(!$vm){
		$body="no vm found"
        Remove-Item $exportPath"\"$name".lock"
			Send-MailMessage -to $mailTo -from $mailFrom -Subject "export VM script finished" -SmtpServer $SmtpServer -Credential $SMTPCredential -Port 25 -Body $body
			
		exit 0
	}
	if($vm.PowerState -eq "PoweredOn"){
		$log+= "Machine is currently on, Powering down`n"
		Shutdown-VMGuest $vm -Confirm:$false

		do{
			Start-Sleep -s 5
			$vm=Get-VM -Name $name
		}until($vm.PowerState -eq "PoweredOff")
	}

	$export=Export-VApp -Destination $exportPath -VM $vm -Force
	$log+="VM "+$name +" exported `n"	
	md5 -files $export

	
	
	

}
catch [Exception]
{

    #Write-Host ("Error: {0}" -f $_.Exception.Message)
	$body="Error during import of vm: `n"+$log+$_.Exception.Message
    Write-Host ("Error: {0}" -f $_.Exception.Message)
	$body| Out-File -FilePath $filename
	Send-MailMessage -to $mailTo -from $mailFrom -Subject "Export VM script Error" -SmtpServer $SmtpServer -Credential $SMTPCredential -Port 25 -Body $body
	Remove-Item $exportPath"\"$name".lock"
	exit 1
}

try
{
	$SFTPCredential=Import-CliXml $credSFTPpath
    # Load WinSCP .NET assembly
    Add-Type -Path $winSCP
 
    # Setup session options
    $sessionOptions = New-Object WinSCP.SessionOptions -Property @{
        Protocol = [WinSCP.Protocol]::Sftp
        HostName = $sftpserver
        UserName = $SFTPCredential.UserName
        SecurePassword = $SFTPCredential.Password
        SshHostKeyFingerprint = $SshHostKeyFingerprint
    }
 
    $session = New-Object WinSCP.Session
 
    #try
    #{
        # Connect
    $session.Open($sessionOptions)
	$log+="Session to sftp opened `n"
        # Upload files
		
	if (-Not $session.FileExists($remoteDirectory+$name)){
        $session.CreateDirectory($remoteDirectory+$name);
    }
    $transferOptions = New-Object WinSCP.TransferOptions
    $transferOptions.TransferMode = [WinSCP.TransferMode]::Binary
 
    $transferResult = $session.PutFiles($exportPath+"\"+$name+"\*", $remoteDirectory+$name+"/", $False, $transferOptions)
 
        # Throw on any error
    $transferResult.Check()
 
        # Print results
    foreach ($transfer in $transferResult.Transfers)
    {
         $log+="Upload of {0} succeeded `n" -f $transfer.FileName
    }
    $session.Dispose()
	Remove-Item $exportPath"\"$name".lock"
    if($logLevel -eq "Debug"){
		$body="Export succesfull: `n"+$log+$_.Exception.Message
		Send-MailMessage -to $mailTo -from $mailFrom -Subject "Export VM script finished" -SmtpServer $SmtpServer -Credential $SMTPCredential -Port 25 -Body $body
		$body | Out-File -FilePath $filename
	}
	
	if(Get-VM -Name $name"_exported"  -ErrorAction SilentlyContinue){
		$log+="removing previous _exported vm `n"
		$oldVM=Get-VM -Name $name"_exported"
		Remove-VM -VM $oldVM -DeletePermanently -Confirm:$false
	}
	
	Set-VM -VM $vm -Name $name"_exported" -Confirm:$false
	$log+="vm "+$name +" name changed `n"

	$log+="VM "+$name +" turned back ON `n"
    exit 0
}
catch [Exception]
{
	$body="Error during import of vm: `n"+$log+$_.Exception.Message
     Write-Host ("Error: {0}" -f $_.Exception.Message)
	$body | Out-File -FilePath $filename
	Remove-Item $exportPath"\"$name".lock"
	Send-MailMessage -to $mailTo -from $mailFrom -Subject "Export VM script Error" -SmtpServer $SmtpServer -Credential $SMTPCredential -Port 25 -Body $body
		$session.Dispose()
	exit 1
}


