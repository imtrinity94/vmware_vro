 Add-PSSnapin vmware* -ErrorAction Stop
#sftp parameters 
#sftp ip
$sftpserver="146.254.11.15"
#ssh figerprint of sftp host
$SshHostKeyFingerprint="ssh-rsa 2048 b2:4c:28:73:77:ab:11:49:8f:bf:26:e4:d9:12:b0:d2"
#directory to store ovf files on sftp
$remoteDirectory="/srv/ftp/images/"

#vsphere parameters
#template name
$name=#provide image name here
$templateName=#provide template name here
#local path to use for export
$importPath="D:\MasterTemplates"
#vsan datastore
$datastoreName=#provide datastore name here
#portgroupname
$network=#provide network name here
#vsphere ip address
$serverIP=#provide vsphere address

#local parameters
#winscp.dll path
$winSCP="C:\Program Files (x86)\WinSCP\WinSCPnet.dll"



$date = (Get-Date).tostring("yyyy-MM-dd")


#email parameters
#mail from which the notification should be sent
$mailFrom="ro-cloud-epc@atos.net"
#mail to which the notification should be sent : remove unecessary (for linux remove "AISMSSiemensICSGDCWIN3@atos.net" for windows "ro-gsa-sh-ux@atos.net")
$mailTo=@("ro-cloud-epc@atos.net","ro-gsa-sh-ux@atos.net","AISMSSiemensICSGDCWIN3@atos.net")
#SmtpServer address
$SmtpServer="139.25.208.14"
#log level type "Debug" to get mail notifications for both success and failure, type "Standard" for only error mail notification
$logLevel="Standard"


#logfile location
$logfileLocation=$importPath+"\logs\"
$filename = $logfileLocation + 'ImportError'+ $date + '.log'

#credentials change only if the default path was changed during deploy
#sftp credentials
$credSFTPpath = $HOME+"\credentials\credSFTP.xml"
#vSphere credentials
$credpath = $HOME+"\credentials\cred.xml"
#smtp credentials
$credSMTPPath=$HOME+"\credentials\credSMTP.xml"

$log=$name+"`n"

function checkmd5{
#md5 checker
	$In = $importPath+"\"+$name
	write-host $In
	$md5files=Get-ChildItem -Path $In"\"*.md5 -File
	if(!$md5files){
		$log+=  "no md5 files found"
		return 
	}

	$ovfFiles=Get-ChildItem -Path $In"\"*.* -exclude *.md5 -File 
	if(!$ovfFiles){
		$log+=  "no files found"
		return 
	}

	if($ovfFiles.count -ne $md5files.count){
	$log+=  "missing files"
	return 
	}
	foreach ($file in $ovfFiles){

		$file.name
		$md5=Get-FileHash -Path $file -Algorithm MD5
		$sftpmd5=Get-Content -Path $file".md5"
		Write-Host $md5.hash	
		Write-Host $sftpmd5
		if($md5.hash -ne $sftpmd5){
			$log+=  "difference in md5 sum found"
			return 
		}

	} 
	$log+=  "md5 checksums ok no new files found on sftp"
	if($logLevel -eq "Debug"){
		$body="Export succesfull: `n"+$log+$_.Exception.Message
		Remove-Item $importPath"\"$name".lock"
		Send-MailMessage -to $mailTo -from $mailFrom -Subject "Export VM script finished" -SmtpServer $SmtpServer -Credential $SMTPCredential -Port 25 -Body $body
		$body | Out-File -FilePath $filename
	}

	Remove-Item $importPath"\"$name".lock"
	exit 0
}
$script:ErrorActionPreference = "stop"
try
{

	if(!(Test-Path -Path $logfileLocation )){
		New-Item -ItemType directory -Path $logfileLocation
	}
	if(Test-Path $importPath"\"$name".lock"){
		$body="lock already exist for the machine"
		$body| Out-File -FilePath $filename
		exit 1
	}
	else{
		New-Item $importPath"\"$name".lock" -type file
	}
	
	$SFTPCredential=Import-Clixml $credSFTPpath
	$SMTPCredential=Import-CliXml $credSMTPPath
	if(-Not (Test-Path -PathType Container -Path $importPath"\"$name) ){
		New-Item $importPath"\"$name -type directory
	}
    # Load WinSCP .NET assembly
	Add-Type -Path $winSCP
	$body="Error during import of vm: "+$_.Exception.Message

    # Setup session options
    $sessionOptions = New-Object WinSCP.SessionOptions -Property @{
        Protocol = [WinSCP.Protocol]::Sftp
        HostName = $sftpserver
        UserName = $SFTPCredential.UserName
        SecurePassword = $SFTPCredential.Password
        SshHostKeyFingerprint = $SshHostKeyFingerprint
    }
 
    $session = New-Object WinSCP.Session
 
    #try
    #{
        # Connect
    $session.Open($sessionOptions)
	$log+="Session to sftp opened `n"
        # Upload files
    $transferOptions = New-Object WinSCP.TransferOptions
    $transferOptions.TransferMode = [WinSCP.TransferMode]::Binary
 
    $transferResult = $session.GetFiles( $remoteDirectory+"/"+$name+"/*.md5", $importPath+"\"+$name+"\*",$False, $transferOptions)
	checkmd5
 
	$transferResult = $session.GetFiles( $remoteDirectory+"/"+$name+"/*.*", $importPath+"\"+$name+"\*",$False, $transferOptions)
        # Throw on any error
    $transferResult.Check()
 
        # Print results
    foreach ($transfer in $transferResult.Transfers)
    {
        $log+="download of {0} succeeded `n" -f $transfer.FileName
    }
    
    $session.Dispose()
    
	


	$PSCredential=Import-Clixml $credpath
	Connect-VIServer -Server $serverIP -Credential $PSCredential -ErrorAction Stop

	if(Get-Template -Name $templateName"_old"  -ErrorAction SilentlyContinue){
		$log+="removing previous _old template `n"
		$temp=Get-Template -Name $templateName"_old"
		Remove-Template -Template $templateName"_old" -DeleteFromDisk -Confirm:$false
	}

	

	$datastore=Get-Datastore -name $datastoreName
	$hosts=Get-VMHost -Datastore $datastore
	$minusage=$null
	$chosenHost=$null
    $ovfConfig=Get-OvfConfiguration -Ovf $importPath"\"$name"\"$name".ovf"
    $portGroup=Get-VirtualPortGroup -Name $network
    $ovfConfig.NetworkMapping.epc_gsa_172.Value=$portGroup
	ForEach($vMHost in $hosts){
		if($vMHost.ConnectionState -eq "Connected"){
            if(Get-VirtualPortGroup -VMHost $vMHost -Name $network -ErrorAction SilentlyContinue){
            $chosenHost=$vMHost
                    
            }
			
			 
		}
	}

    if($chosenHost -eq $null){
    throw "no host with VM Network found"
    }
	$log+="chosen host "+$chosenHost+"`n"

	Import-VApp -Source $importPath"\"$name"\"$name".ovf" -VMHost $chosenHost -Name $name"_new" -Datastore $datastore -OvfConfiguration $ovfConfig
	$log+="Importing template `n"
    if(Get-Template -Name $templateName  -ErrorAction SilentlyContinue){
		$log+="renaming previous template `n"
		$temp=Get-Template -Name $templateName
		Set-Template -Template $temp -Name $templateName"_old" -Confirm:$false
	}
	$vm=Get-VM -Name $name"_new"

	Move-VM -VM $vm -Destination "Templates"
	$log+="moving to vcac folder"
	Set-VM -ToTemplate -VM $vm -Name $templateName -Confirm:$false
	if($logLevel -eq "Debug"){
		$body="Export succesfull: `n"+$log+$_.Exception.Message
		Send-MailMessage -to $mailTo -from $mailFrom -Subject "Export VM script finished" -SmtpServer $SmtpServer -Credential $SMTPCredential -Port 25 -Body $body
		$body | Out-File -FilePath $filename
	}
	Remove-Item $importPath"\"$name".lock"
}

catch [Exception]
{
	$body="Error during import of vm: `n"+$log+$_.Exception.Message
    Write-Host ("Error: {0}" -f $_.Exception.Message)
	$body | Out-File -FilePath $filename
	Remove-Item $importPath"\"$name".lock"
	Send-MailMessage -to $mailTo -from $mailFrom -Subject "Import VM script Error" -SmtpServer $SmtpServer -Credential $SMTPCredential -Port 25 -Body $body
    exit 1
}

