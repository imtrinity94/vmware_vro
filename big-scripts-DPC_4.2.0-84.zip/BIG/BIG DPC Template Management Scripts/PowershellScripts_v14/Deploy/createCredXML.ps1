##!!important!!
$path=$HOME+"\credentials"

if(!(Test-Path -Path $path )){
		New-Item -ItemType directory -Path $path
	}


#provide credentials for sftp
$pathsftp=$path+"\credSFTP.xml"
$cred=Get-Credential -Message "provide credentials for sftp server"
$cred|Export-Clixml $pathsftp

#provide credentials for vsphere
$pathVsphere=$path+"\cred.xml"
$cred=Get-Credential -Message "provide credentials for vsphere server"
$cred|Export-Clixml $pathVsphere
get-host	
#provide credentials for mailbox
$pathSMTP=$path+"\credSMTP.xml"
$cred=Get-Credential -Message "provide credentials for smtp account"
$cred|Export-Clixml $pathSMTP