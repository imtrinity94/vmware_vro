#DPC SQL Server 2016 config script 
#v0.1 03-04-2018
#v1.0 10-06-2018 Added DTC section to prevent possible issues
#Author(s): Original - Jarek Gajewski

 Function GeneralOptions {
Write-Host "Change CD rom drive letter to R: " -Foregroundcolor DarkYellow
$cdrom = Get-WmiObject win32_cdromdrive


Get-WmiObject Win32_Volume -filter "DriveLetter='$($cdrom.Drive)'" | Set-WmiInstance -Arguments @{DriveLetter="R:"} > $null
$cdrom = Get-WmiObject win32_cdromdrive

Write-Host "Drive letter is:" $cdrom.Drive
}
 function FormatDisk {

Stop-Service shellhwdetection
$newdisk = @(get-disk | Where IsSystem -eq $false | Where-Object partitionstyle -eq 'RAW' )
$Labels = @('Data','Log','Database','Backup')
$DriveLetter = @('D','E','F','G')

for($i = 0; $i -lt $newdisk.Count ; $i++)
{

    $disknum = $newdisk[$i].Number
    $dl = get-Disk $disknum | Initialize-Disk -PartitionStyle MBR -PassThru | New-Partition -DriveLetter $DriveLetter[$i] -UseMaximumSize
          Start-Sleep -s 2
    Format-Volume -driveletter $DriveLetter[$i] -FileSystem NTFS -NewFileSystemLabel $Labels[$i] -Confirm:$false

}
Start-Service shellhwdetection


}
function ClusterPrep {
Install-WindowsFeature -Name Failover-Clustering -IncludeManagementTools

}
function DTCprep {
Uninstall-Dtc -confirm:$false
Install-Dtc
Set-DtcNetworkSetting -DtcName "Local" -RemoteAdministrationAccessEnabled:$False -RemoteClientAccessEnabled:$True -InboundTransactionsEnabled:$True -OutboundTransactionsEnabled:$True -LUTransactionsEnabled:$True -XATransactionsEnabled:$False -AuthenticationLevel Mutual -Confirm:$False
}
GeneralOptions
FormatDisk
ClusterPrep
DTCprep