// Read all Sheet Rows ignoring Columns starting Column and Stop if Column1 is Empty into Object List
function ReadColumn1NonBlankWithKey(sheetname, csheet,keyname) {
	msg("Processing Sheet : " + sheetname)
	var jdata = {};
	msg("headers : " + csheet.Item(0).StringList(", "));
	for (var i=0;i<csheet.length;i++) {
		var bag = csheet.Item(i);
		var entry = {};
		var bagKeys = bag.Keys();
		var nonblank = bagKeys.Item(0);
		if (bag[nonblank] == undefined) break;
		if (bag[keyname] == undefined) break;
		for (var k=0;k<bagKeys.length;k++) {
			var key = bagKeys.Item(k);
			if (key.indexOf("Column") == 0) continue;
			if (bag[key] == undefined) bag[key] = "";
			entry[key] = bag[key].toString();
		}
		var keyvalue = bag[keyname]
		keyvalue = keyvalue.replace(/ /g,"");
		jdata[keyvalue] = entry;		
	}
	return jdata
}

// Read all Sheet Rows ignoring Columns starting Column and Stop if Column1 is Empty
function ReadColumn1NonBlank(sheetname, csheet) {
	msg("Processing Sheet : " + sheetname)
	var jdata = [];
	msg("headers : " + csheet.Item(0).StringList(", "));
	for (var i=0;i<csheet.length;i++) {
		var bag = csheet.Item(i);
		var entry = {};
		var bagKeys = bag.Keys();
		var nonblank = bagKeys.Item(0);
		if (bag[nonblank] == undefined) break;
		for (var k=0;k<bagKeys.length;k++) {
			var key = bagKeys.Item(k);
			if (key.indexOf("Column") == 0) continue;
			if (bag[key] == undefined) bag[key] = "";
			entry[key] = bag[key].toString();
		}
		jdata.push(entry);
	}
	return jdata
}

// Read all Sheet Rows ignoring Columns starting Column and ignore entries where Column 2 is Empty and Stop when Column1 is Empty with Keys
function ReadColumn2NonBlankWithKeys(sheetname,csheet,Keys) {
	msg("Processing Sheet : " + sheetname)
	var jdata = {};
	msg("headers : " + csheet.Item(0).StringList(", "));
	var key1 = Keys[0];
	var key2 = Keys[1];
	for (var i=0;i<csheet.length;i++) {
		var bag = csheet.Item(i);
		var entry = {};
		var bagKeys = bag.Keys();
		var nonblank1 = bagKeys.Item(0);
		var nonblank2 = bagKeys.Item(1);
		if (bag[nonblank2] == undefined) continue;
		if (bag[nonblank1] == undefined) break;
		if (bag[key1] == undefined) break;
		if (bag[key2] == undefined) break;

		for (var k=0;k<bagKeys.length;k++) {
			var key = bagKeys.Item(k);
			if (key.indexOf("Column") == 0) continue;
			if (bag[key] == undefined) bag[key] = "";
			entry[key] = bag[key].toString();
			entry[key] = bag[key];
		}

		var key1value = bag[key1];
		var key2value = bag[key2];
		key1value = key1value.replace(/ /g,"");
		key2value = key2value.replace(/ /g,"");
		if (jdata[key1value] == undefined) {
			jdata[key1value] = {};
		}
		
		jdata[key1value][key2value] = entry;
	}
	return jdata	
}	

// Read all Sheet Rows ignoring Columns starting Column and ignore entries where Column 2 is Empty and Stop when Column1 is Empty
function ReadColumn2NonBlank(sheetname, csheet) {
	msg("Processing Sheet : " + sheetname)
	var jdata = {};
	msg("headers : " + csheet.Item(0).StringList(", "));
	for (var i=0;i<csheet.length;i++) {
		var bag = csheet.Item(i);
		var entry = {};
		var bagKeys = bag.Keys();
		var nonblank1 = bagKeys.Item(0);
		var nonblank2 = bagKeys.Item(1);
		if (bag[nonblank2] == undefined) continue;
		if (bag[nonblank1] == undefined) break;
		for (var k=0;k<bagKeys.length;k++) {
			var key = bagKeys.Item(k);
			if (key.indexOf("Column") == 0) continue;
			if (bag[key] == undefined) bag[key] = "";
			entry[key] = bag[key].toString();
			entry[key] = bag[key];
		}
		jdata.push(entry);
	}
	return jdata
}

// Read all Sheet Rows ignoring Columns starting Column and ignore entries where Column 3 is Empty and put Column3 into an Array
function ReadLineNotEmptyArrayColumn3(sheetname, csheet) {
	msg("Processing Sheet : " + sheetname)
	var jdata = [];
	msg("headers : " + csheet.Item(0).StringList(", "));
	var entry = {};
	var pushNeeded = false;
	msg("Sheet has : " + csheet.length.toString() + " lines");
	for (var i=0;i<csheet.length;i++) {
		var bag = csheet.Item(i);		
		var bagKeys = bag.Keys();
		var nonblank1 = bagKeys.Item(0);
		var nonblank3 = bagKeys.Item(2);
		if (bag[nonblank1] != undefined) {
			if (pushNeeded) jdata.push(entry);
			entry = {};
			pushNeeded = true;
		}
		if (bag[nonblank3] == undefined) continue;		
		for (var k=0;k<bagKeys.length;k++) {
			var key = bagKeys.Item(k);
			if (key.indexOf("Column") == 0) continue;
			if (k == 2) {
				if (entry[key] == undefined) {
					entry[key] = [];
				}
				if (bag[key] == undefined) bag[key] = "";			
				entry[key].push(bag[key].toString());
			}
			else if (bag[key] != undefined) {
				entry[key] = bag[key].toString();			
			}
		}		
	}
	if (pushNeeded) jdata.push(entry);
	return jdata
}

// Read all Sheet Rows ignoring Columns starting Column and ignore entries where Column 3 is Empty and put Column3 to 5 into a JSON Array
function ReadLineNotEmptyArrayColumn3To5(sheetname, csheet,arraytitle) {
	msg("Processing Sheet : " + sheetname)
	var jdata = [];
	msg("headers : " + csheet.Item(0).StringList(", "));
	var entry = {};
	var pushNeeded = false;
	msg("Sheet has : " + csheet.length.toString() + " lines");
	for (var i=0;i<csheet.length;i++) {
		var bag = csheet.Item(i);		
		var bagKeys = bag.Keys();
		var nonblank1 = bagKeys.Item(0);
		var nonblank3 = bagKeys.Item(2);
		if (bag[nonblank1] != undefined) {
			if (pushNeeded) jdata.push(entry);
			entry = {};
			pushNeeded = true;
		}
		if (bag[nonblank3] == undefined) continue;	
		var arrayentry = {};		
		for (var k=0;k<bagKeys.length;k++) {
			var key = bagKeys.Item(k);
			if (key.indexOf("Column") == 0) continue;
			if (k == 2) {
				if (entry[arraytitle] == undefined) {
					entry[arraytitle] = [];
				}
				arrayentry = {};				
			}
			if (k >= 2) {
				arrayentry[key] = bag[key].toString();
			}
			else if (bag[key] != undefined) {
				entry[key] = bag[key].toString();			
			}
			if (k == 4) {
				entry[arraytitle].push(arrayentry);
			}			
		}		
	}
	if (pushNeeded) jdata.push(entry);
	return jdata
}

// Read all Sheet Rows ignoring Columns starting Column and ignore entries where Column 7 is Empty and put Column 4 to 6 into Arrays
function ReadLineNotEmptyArrayColumn4To6Each(sheetname, csheet) {
	msg("Processing Sheet : " + sheetname)
	var jdata = [];
	
	msg("headers : " + csheet.Item(0).StringList(", "));
	var entry = {};
	var pushNeeded = false;
	msg("Sheet has : " + csheet.length.toString() + " lines");
	for (var i=0;i<csheet.length;i++) {
		var bag = csheet.Item(i);		
		var bagKeys = bag.Keys();
		var nonblank1 = bagKeys.Item(0);
		var nonblank7 = bagKeys.Item(6);
		if (bag[nonblank1] != undefined) {
			if (pushNeeded) jdata.push(entry);
			entry = {};
			pushNeeded = true;
		}
		if (bag[nonblank7] == undefined) continue;	
		var arrayentry = {};		
		for (var k=0;k<bagKeys.length;k++) {
			var key = bagKeys.Item(k);
			if (key.indexOf("Column") == 0) continue;
			if (k >= 3 && k <= 5) {
				if (entry[key] == undefined) {
					entry[key] = [];
				}
				if (bag[key] != undefined) entry[key].push(bag[key].toString());
			}
			else if (bag[key] != undefined) {
				entry[key] = bag[key].toString();			
			}
		}		
	}
	if (pushNeeded) jdata.push(entry);
	return jdata;
}

function msg(text) {
	api.Info.WriteLine(text);
}

function output(text) {
	api.Output.WriteLine(text);	
}	



var filename = api.File.SelectFile("","*.xlsx")
api.Info.WriteLine(filename)
var ex = api.Excel.Load(filename)
var s = ex.sheetnames

//mes : start here, networks, devices, cabling switches, cabling servers, omb, install steps, input (hide), build parameter, nsx ip sets, nsx services, nsx service //oups, nsx security groups, nsx medge rules, nsx iedge rules, nsx vedge rules, sheet5, software repository

var sheetextracts = [
						{"name":"networks","type":"ReadColumn1NonBlankWithKey","Key":"Name"},
						{"name":"devices","type":"ReadColumn2NonBlankWithKeys","Keys":["DeviceName","Network"]},
						{"name":"nsx ip sets","type":"ReadColumn1NonBlank"},
						{"name":"nsx services","type":"ReadColumn1NonBlank"},
						{"name":"nsx service groups","type":"ReadLineNotEmptyArrayColumn3"},
						{"name":"nsx security groups","type":"ReadLineNotEmptyArrayColumn3To5","arrayname":"memberinfo"},
						{"name":"nsx medge rules","type":"ReadLineNotEmptyArrayColumn4To6Each"},
						{"name":"nsx iedge rules","type":"ReadLineNotEmptyArrayColumn4To6Each"}
					]

var info = {};					
for (var i=0;i<sheetextracts.length;i++) {
	var sheetextract = sheetextracts[i];
	var data = null;
	var csheet = ex.GetSheet(sheetextract.name);
	var infoKey = sheetextract.name;
	var subkey = null;
	switch (sheetextract.type) {
		case "ReadColumn1NonBlank":
			data = ReadColumn1NonBlank(sheetextract.name, csheet);
			break;
		case "ReadColumn1NonBlankWithKey":
			data = ReadColumn1NonBlankWithKey(sheetextract.name,csheet,sheetextract.Key);
			break;
		case "ReadColumn2NonBlank":
			data = ReadColumn2NonBlank(sheetextract.name, csheet);
			break;
		case "ReadColumn2NonBlankWithKeys":
			data = ReadColumn2NonBlankWithKeys(sheetextract.name,csheet,sheetextract.Keys);
			break;		
		case "ReadLineNotEmptyArrayColumn3":
			data = ReadLineNotEmptyArrayColumn3(sheetextract.name, csheet);
			break;	
		case "ReadLineNotEmptyArrayColumn3To5":
			data = ReadLineNotEmptyArrayColumn3To5(sheetextract.name, csheet,sheetextract.arrayname);
			break;
		case "ReadLineNotEmptyArrayColumn4To6Each":
			data = ReadLineNotEmptyArrayColumn4To6Each(sheetextract.name, csheet);
			infoKey = "firewallrules";
			subkey = sheetextract.name.split(" ")[1];
			break;			
		default:
			msg("Unknown Type : " + sheetextract.type + " for Sheet : " + sheetextract.name);		
	}
	if (data != undefined) 
	{
		if (subkey == null) {
			info[infoKey] = data;
		}
		else {
			if (info[infoKey] == null) info[infoKey] = {};
			info[infoKey][subkey] = data;
		}
	}
	
}
output(JSON.stringify(info));
