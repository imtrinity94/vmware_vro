# SetDellAlertAction.ps1
# Version: 1.0
# Changes: first verion adjusted for 
# Author: Oliver Scholle
$vc = Connect-VIServer -Server 10.216.248.20 -Username root -Password xxx

# Dell Alarms to be added with SNMP action
$tgtAlarms = "Dell - AC power has been lost Warning",
"Dell - An error was detected for a PCI device",
"Dell - Current sensor detected a failure value",
"Dell - Device configuration error",
"Dell - Fan sensor detected a failure value",
"Dell - Integrated Dual SD module failure",
"Dell - Integrated Dual SD Module warning",
"Dell - Integrated Dual SD Module redundancy is lost",
"Dell - Memory Device error",
"Dell - Module SD Card Failed (Error)",
"Dell - Power supply detected a failure",
"Dell - Processor sensor detected a failure value",
"Dell - Storage: Array disk failure",
"Dell - Storage: Controller failure",
"Dell - Temperature sensor detected a failure value",
"Dell - Voltage sensor detected a failure value"

 
#=================================
# Uncomment one of the following actions
# Fill in the required parameters
#=================================
# New createtask action
# $actType = "CreateTaskAction"
# $actTaskTypeId =
# $actCancelable =
#-- -------------------------------
# New method action
# $actType = "MethodAction"
# $actArgument =
# $actName =
#---------------------------------
# New runscript action
# $actType = "RunScriptAction"
# $actScript =
#---------------------------------
# New sendmail action
$actType = "SendEmailAction"
$actTo = "luc@lucd.info"
$actCc = ""
$actSubject = "Alarm email"
$actBody = ""
#---------------------------------
 #New sendSNMP action
 $actType = "SendSNMPAction"
#=================================
 
function Set-AlarmAction{
  param($alarm)
 
  switch($actType){
    "CreateTaskAction"{
      $trigger = New-Object VMware.Vim.AlarmTriggeringAction
      $trigger.action = New-Object VMware.Vim.CreateTaskAction
      $trigger.action.Cancelable = $actCancelable
      $trigger.action.taskTypeId = $actTaskTypeId
    }
    "MethodAction"{
      $trigger = New-Object VMware.Vim.AlarmTriggeringAction
      $trigger.action = New-Object VMware.Vim.MethodAction
      $trigger.action.Argument = $actArgument
      $trigger.action.Name = $actName
    }
    "RunScriptAction"{
      $trigger = New-Object VMware.Vim.AlarmTriggeringAction
      $trigger.action = New-Object VMware.Vim.RunScriptAction
      $trigger.action.Script = $actScript
    }
    "SendEmailAction"{
      $trigger = New-Object VMware.Vim.AlarmTriggeringAction
      $trigger.action = New-Object VMware.Vim.SendEmailAction
      $trigger.action.ToList = $actTo
      $trigger.action.Subject = $actSubject
      $trigger.Action.CcList = $actCc
      $trigger.Action.Body = $actBody
    }
    "SendSNMPAction"{
      $trigger = New-Object VMware.Vim.AlarmTriggeringAction
      $trigger.action = New-Object VMware.Vim.SendSNMPAction
    }
  }
# Transition a - yellow --> red
  $transa = New-Object VMware.Vim.AlarmTriggeringActionTransitionSpec
  $transa.StartState = "yellow"
  $transa.FinalState = "green"
# Transition b - red --> yellow
  $transb = New-Object VMware.Vim.AlarmTriggeringActionTransitionSpec
  $transb.StartState = "yellow"
  $transb.FinalState = "red"
  $trigger.TransitionSpecs += $transa
  $trigger.TransitionSpecs += $transb
 
  if($alarm.Info.Action -eq $null){
    $action = New-Object VMware.Vim.GroupAlarmAction
  }
  else{
    if($alarm.Info.Action.GetType().Name -ne "GroupAlarmAction"){
      $action = New-Object VMware.Vim.GroupAlarmAction
      $action.action += $alarm.Info.Action
    }
    else{
      $action = $alarm.Info.Action
    }
  }
  $action.action += $trigger
 
  $spec = New-Object VMware.Vim.AlarmSpec
  $spec.Action = $action
  $spec.actionFrequency = $alarm.Info.ActionFrequency
  $spec.Description = $alarm.Info.Description
  $spec.Enabled = $alarm.Info.Enabled
  $spec.Expression = $alarm.Info.Expression
  $spec.Name = $alarm.Info.Name
  $spec.Setting = $alarm.Info.Setting
 
  $alarm.ReconfigureAlarm($spec)
}
 
# Get all alarms
$alarmMgr = Get-View AlarmManager
$alarms = $alarmMgr.GetAlarm($null)
 
# For all selected alarms
$alarms | % {
  $alarm = Get-View $_
  if($tgtAlarms -contains $alarm.Info.Name){
    Set-AlarmAction $alarm
  }
}
