﻿#####Script is being used for automated installation of EPOPs and vRLI agents remotly on Windows and Linux VMs.
#1.	Prerequsites
To achieve full functionality you need those files to be present in SINGLE directory:
•	Install_vRLI_Agents.ps1 – script itself
•	list.csv – CSV file with server list and installation parameters
•	plink.exe – executable used for remote commands on linux
•	pscp.exe – executable used for file transfer to linux
•	vRLI MSI – Log Insight Windows installer (required version can be downloaded from vRLI Appliance itself – tab: Administration > Agents)
•	vRLI rpm – Log Insight Linux installer (same as with Windows installer)
•	ca-certificates.crt root CA certificate in .crt format (used by linux agents for SSL communication)


#2.	CSV preparation:
CSV file contains multiple lines, first line is description of each values and SHOULD NOT be modified, all other lines are providing information on which server agent should be installed. Those lines must be edited for deployment purposes. Each line have 4 values separated by coma:
•	Name - provide FQDN for server on which you would like install agents
•	OS – numeric value, put 0 if it is Windows server or 1 if it is Linux
•	vrli – Boolean value, put 1 if you want to install vRLI agent on this server or 0 if it should be skipped

Sample CSV file – Windows server on which we would like to install both agents:
Name,OS,vrli,vrops
Testserver.devdpc.local,0,1,1

#3.	Run script
BEFORE launching the script change directory to one on which you have script itself and all mentioned files in point 1. 

Script is being run without parameters, but on base of CSV content it will ask for additional information like:
•	Domain credentials – if you choose at least one Windows server to process, you will be asked for this only once.
•	Local linux credential - if you choose at least one Linux server to process. If used login is different than root it will still, ask for root password for sudo purposes. You will be asked for this for each processed Linux server.
•	Installer file names – depending on provided OS and required agents, you will be asked to provide specific file names. Provide ONLY file name, not a whole path. I.e. if file is named vrli.msi just put “vrli.msi”, not “.\vrli.msi” or “c:\...\vrli.msi”
•	Appliances addresses – you will be asked to provide vRLI appliances IP addresses, with which agents should communicate
