####Automated installation of vRLI agents on Windows and Linux servers
####Version: 0.1
####Date: 15.01.2018
####Author:Andrei Savu (adapted after Mateusz Rutkowski Install Monitoring Agents script)
#
#
####README SECTION BEGIN####
#Update list.csv with servers on which you would like to install agents. File properties:
#- Name - enter DNS name or IP address of destination server
#- OS - 0 = Windows, 1 = Linux
#- vrli - 0 = skip, 1 = install
####README SECTION END####

####FUNCTION SECTION BEGIN####
#I. What will be installed
#0 = nothing, 1 = vRLI
function prereqCheck ($os){
    $result = 0
    foreach($temp in $servers){
        #checking if server have correct OS
        if($temp.os -eq $os) {
            #checking if vrli will be installed
            if(($temp.vrli -eq 1) -and ($result -eq 0)){
                $result = 1 #install vRLI and check further
                break
            }
        }
    }
    return $result
}

#II. Ask for parameter
function giveParam($name){
    Write-host "Enter $name"
    $result = Read-host 
    return $result
}

#III. Installation functions
function WinInstall($servername,$installer,$scriptblock){
    writeServer 
    if(-Not (test-path "\\$servername\c$\temp\")){
		New-Item -ItemType Directory -Force -Path "\\$servername\c$\temp\"
	}
	Copy-Item $installer -Destination "\\$servername\c$\temp\" 
	Invoke-Command -ComputerName $servername -ScriptBlock $scriptblock -credential $credentials
    Remove-Item "\\$servername\c$\temp\$installer"
}

function LinInstall($servername,$installer,$command){
    #$credentialsLinux = Get-Credential -message "$servername credentials" #for some reason not working on some windows servers
	if($credFOR -ne $servername){ #to not ask 2 times for same credentials
		$username = read-host "Enter username for $servername"
		$password = read-host "Enter password for $servername" -assecurestring
		$global:credentialsLinux = new-object -typename System.Management.Automation.PSCredential -argumentlist $username, $password
		if($username -ne "root"){
			$ROOTpassword = read-host "Enter ROOT password for $servername" -assecurestring
			$global:ROOTcredentialsLinux = new-object -typename System.Management.Automation.PSCredential -argumentlist "root", $ROOTpassword
			$global:sudo = "echo "+$global:ROOTcredentialsLinux.GetNetworkCredential().password+" | sudo -S"
		} else {$global:sudo = ""}
	}
	$global:credFOR = $servername
	writeServer
	Write-host "Coping installer and certificate...(Check new window for error messages)"
	Start-Process -wait '.\pscp.exe' -ArgumentList ("-scp -pw "+$credentialsLinux.GetNetworkCredential().password+" "+$installer+" "+$credentialsLinux.UserName+"@"+$servername+":/tmp/") 
    cmd.exe /C .\plink.exe -ssh $servername -l $credentialsLinux.UserName -pw $credentialsLinux.GetNetworkCredential().password $command
	Start-Process -wait '.\pscp.exe' -ArgumentList ("-scp -pw "+$credentialsLinux.GetNetworkCredential().password+" "+$certificate+" "+$credentialsLinux.UserName+"@"+$servername+":/etc/ssl/certs/") 
    cmd.exe /C .\plink.exe -ssh $servername -l $credentialsLinux.UserName -pw $credentialsLinux.GetNetworkCredential().password $command
}

#IV. Additional
function writeServer{
    write-host "========================"
    write-host "Working on: "$servername; 
}

####FUNCTION SECTION END####

####SCRIPT SECTION BEGIN####
#1. CHECKING WHAT WILL BE INSTALLED - WHICH PREREQUISITES ARE NEEDED
#1.1. Import server information from CSV
$servers = Import-Csv .\list.csv
$global:credentialsLinux = ""
$global:credFOR = ""

#1.2. What will be installed on Windows
$windowsReq = prereqCheck -os 0

#1.3. What will be installed on Linux
$linuxReq = prereqCheck -os 1

#2. ASKING USER FOR REQUIRED PARAMETERS 
#2.1. If there is something for Windows servers, get domain credentials
if($windowsReq -gt 0){
	#$credentials = Get-Credential #for some reason not working on some windows servers, causes PS crash
	$username = read-host "Enter domain username"
	$password = read-host "Enter domain password" -assecurestring
	$credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist $username, $password
}

#2.2. Check if there will be vRLI installed on Windows - if so, asking for needed parameters
$vrliGotCommon = $false
if(($windowsReq -eq 1) -or ($windowsReq -eq 3)){
    $vrliServer = giveParam -name "vRLI server address:"
    $vrliMSI = giveParam -name "vRLI MSI installer name (file have to be in same directory as script):"
	$liagent = 'C:\ProgramData\VMware\Log Insight Agent\liagent.ini'
	$ssl = ';ssl=yes'
	$sslnew = 'ssl_accept_any=yes'
	$vrliSB = $ExecutionContext.InvokeCommand.NewScriptBlock("start-process msiexec.exe -Wait '/i C:\temp\$vrliMSI SERVERHOST=""$vrliServer"" AUTOUPDATE=yes SERVERPROTO=cfapi SERVERPORT=9543 LIAGENT_SSL=yes'")
    $vrliGotCommon = $true
}

#2.3. Check if there will be vRLI installed on Linux - if so, asking for needed parameters
if(($linuxReq -eq 1) -or ($linuxReq -eq 3)){
    if($vrliGotCommon -eq $false){$vrliServer = giveParam -name "vRLI server address:"}
    $vrliRPM = giveParam -name "vRLI RPM installer name (file have to be in same directory as script):"
	$certificate = giveParam -name "vRLI RCA Certificate name (file have to be in same directory as script):"
    #command for installation vRLI agent
    $commandvrli = "($sudo SERVERHOST=$vrliServer rpm -i /tmp/$vrliRPM && $sudo rm /tmp/$vrliRPM) || ($sudo SERVERHOST=$vrliServer rpm -U --force /tmp/$vrliRPM && $sudo rm /tmp/$vrliRPM) || (sed -i -e 's/;hostname=LOGINSIGHT/hostname=$vrliServer \nssl=yes \nssl_accept_any=yes/g' /var/lib/loginsight-agent/liagent.ini && /etc/init.d/liagentd restart)"
	#$commandvrli2 = "sed -i -e 's/;hostname=LOGINSIGHT/hostname=$vrliServer \nssl=yes \nproto=cfapi \nport=9543 \nssl_accept_any=yes \nauto_update=yes/g' /var/lib/loginsight-agent/liagent.ini && /etc/init.d/liagentd restart" #not used in this version
}

#3. INSTALLATION PART
foreach($server in $servers){
	#Check if server is Windows
    if($server.os -eq 0){
        #Check if vRLI agent installation is required
        if($server.vrli -eq 1){WinInstall -servername $server.name -installer $vrliMSI -scriptblock $vrliSB};	
		Get-Service -ComputerName $server.name -Name LogInsightAgentService| Stop-Service -Verbose;
        Invoke-Command -ComputerName $server.name -ScriptBlock { (Get-Content $args[0]).replace($args[1],$args[2]) | Set-Content $args[0]} -credential $credentials -ArgumentList $liagent,$ssl,$sslnew;
		Get-Service -ComputerName $server.name -Name LogInsightAgentService| Start-Service -Verbose;
    }
    #Check if server is Linux
    elseif($server.os -eq 1){
        #Check if vRLI agent installation is required
        if($server.vrli -eq 1){
			if($server.name -like '*log0*'){LinInstall -servername $server.name -installer $vrliRPM -command $commandvrli}#exclusion for vRLI nodes, which already have newest package
			else{LinInstall -servername $server.name -installer $vrliRPM -command $commandvrli}  #will leave it to create a bit of flexibility on the script in the future
		}
    }
}
####SCRIPT SECTION END####