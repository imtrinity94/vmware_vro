﻿#
# Created by:   Andrei Savu
# Modified by:  Andrei Savu, 29-11-17
# Released and tested for: DPC 4.0
# Version: Deploy_vRLI.ps1 ; version 0.1
#
Import-Module VMware.VimAutomation.Vds
[System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
#    
# Read the configuration variables from a JSON file
$OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
$OpenFileDialog.filter = "JSON (*.json)| *.json"
$OpenFileDialog.ShowDialog() | Out-Null
$Config = Get-Content -Raw -Path $OpenFileDialog.FileName |  ConvertFrom-Json
#
# Connect to the vCenter sever
$VIServer = Connect-VIServer -Server $Config.vCenterServer
#
# Load OVF/OVA configuration into a variable
$OvfConfig = Get-OvfConfiguration $config.OVFFile
#
# Set the specific parameters for the deployment of the vRLI server
$Ovfconfig.DeploymentOption.value = $Config.DeploymentOption
$ovfconfig.vami.VMware_vCenter_Log_Insight.hostname.Value = $Config.Hostname
$ovfconfig.vami.VMware_vCenter_Log_Insight.ip0.Value = $Config.IPAddress
$ovfconfig.vami.VMware_vCenter_Log_Insight.netmask0.Value = $Config.SubnetMask
$ovfconfig.vami.VMware_vCenter_Log_Insight.gateway.Value = $Config.Gateway
$ovfconfig.vami.VMware_vCenter_Log_Insight.DNS.Value = $Config.DNS
$ovfconfig.vami.VMware_vCenter_Log_Insight.domain.Value = $Config.Domain
$ovfconfig.vami.VMware_vCenter_Log_Insight.searchpath.Value = $Config.DomainSearchPath
$ovfconfig.vm.rootpw.Value = $Config.rootpwd
#
# vSphere Portgroup Network Mapping
$Network = Get-VDPortgroup -Name $Config.NetworkName
$Ovfconfig.NetworkMapping.Network_1.value = $Network
#
# Get the DataStore
$DataStore = Get-Datastore -Name $Config.DatastoreName
#
# Get the Host to run vRLI on, select the first host of the cluster
$OpsHost = Get-Cluster -Name $Config.Cluster | Get-VMHost | select -First 1
#
# Get the folder object for the destination folder
$Folder = Get-Folder -Name $Config.Folder
#
# Deploy the OVF/OVA with the config parameters
Write-Host "Deploying vRLI node " $Config.Name
$vRLIVM = Import-VApp -Source $Config.OVFFile -OvfConfiguration $ovfconfig -Name $Config.Name -Location $Config.Cluster -VMHost $OpsHost -Datastore $DataStore -DiskStorageFormat thin
#
# Start the vRLI Node
Start-VM -VM $vRLIVM

#Move VM to Folder
Move-VM -Destination $Folder -VM $vRLIVM