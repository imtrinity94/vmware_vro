﻿add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
$nsxmanager=Read-Host -Prompt ("NSX-Manager IP")
$pass = Read-Host -Prompt("Admin Password")
$syslogip=Read-Host -Prompt ("LogInsight Master Cluster VIP")

$credPair = "admin:$($pass)"
$encodedCredentials = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($credPair))
$headers = @{ Authorization = "Basic $encodedCredentials" }

$controllerid=Read-Host -Prompt("Controller-ID [blank for canceling]")
while($controllerid -ne ""){

    Invoke-WebRequest -Uri ("https://$nsxmanager/api/2.0/vdn/controller/$controllerid/syslog") -Method Post -ContentType "application/xml" -Body ("<controllerSyslogServer>
<syslogServer>$syslogip</syslogServer>
<port>1514</port>
<protocol>UDP</protocol>
<level>INFO</level>
</controllerSyslogServer>") -Headers $headers
    $controllerid=Read-Host -Prompt("Controller-ID [blank for canceling]")
}