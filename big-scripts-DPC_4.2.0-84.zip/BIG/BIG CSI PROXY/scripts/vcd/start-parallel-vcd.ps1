###################################################################################################
# Title:	     Start Parallel vCloud Director
# Filename:	     Start-Parallel-vCD.ps1      	
# Created by:	 Harold Schoofs			
# Date:		     2 November 2017			
# Version:       1.0
# 
# Added:
# 02-11-2017 - v 1.0 - Initial version,to start vCloud Director Reporting in parallel
#
# Parameters:
#  
# NAME
#     Start-Parallel-vCD.ps1 
#
# SYNTAX
#     Start-Parallel-vCD.ps1 [[-Execution] <String[]>] 
#
# PARAMETERS
#     -Execution <String[]>
#        Specifies the type of executions, mandatory
#           Hourly               All sections will be executed
#
#
#  --------------  Example 1 --------------
#
# D:\Proxy\Scripts\vcd\Start-Parallel.ps1 -Execution Hourly
#
# Start the script and retrieve the Hourly required data
#
###################################################################################################



#----------------------------  S T A R T  P R E R E Q S  ------------------------------------------

    # Check for Execution parameter provided when Script Started
        param (
            [Parameter(Mandatory=$true)]
            [string]$Execution = "Hourly"
        )


    # Fix when running the Script Scheduled (win2k12)
        $FIXUSER = $env:username
        $APPPATH = "C:\Users\" + $FIXUSER + "\AppData\Roaming"

    # Set the AppData environment variable if needed
        if ($env:appdata -eq $null -or $env:appdata -eq 0){
	        $env:appdata = $APPPATH
            }


    # Import Modules
        Get-Module -Name VMware* -ListAvailable | Import-Module


    # Add PowerCLI Snap-in and PowerCLI Cloud Snap-in
        Add-PSsnapin VMware.VimAutomation.Core -Erroraction Silentlycontinue

    # Get vCloud Director Servers from Input file
        $vCDs = Get-Content $PSScriptRoot\..\..\configuration\config.csv | ConvertFrom-Csv | Where {$_.entitytype -eq "vcd"}


    # Disconnect from any vCloud Director, if already connected
        If ($global:DefaultCIServers) {
    	    Disconnect-CIServer -Server $global:DefaultCIServers -Force -Confirm:$false
        }


    # Create the CSI Proxy Windows Eventlog and source, if it not exists
        New-EventLog -Source "CSI Proxy - vCloud Director" -LogName "CSI Proxy" -ErrorAction SilentlyContinue


    # Exit if no vCloud Director servers were found
        if (!$vCDs){
            Write-EventLog -LogName "CSI Proxy" -Source "CSI Proxy - vCloud Director" -Message "CSI Error : No vCD servers found in the Input file" -EventId 502 -Category 0 -EntryType Error 
        } 

#----------------------------  E N D  P R E R E Q S  ----------------------------------------------



#----------------------------  S T A R T  L O O P  ------------------------------------------------

    # Log a START event in the Windows Event Log
        Write-EventLog -LogName "CSI Proxy" -Source "CSI Proxy - vCloud Director" -Message "CSI Information : START : vCD Script has Started" -EventId 500 -Category 0 -EntryType Information


    # Start the loop, and launch the script for each vCloud Director Server in parallel
        $Jobs = @()
        foreach ($vCD in $vCDs){
            $vCDName = $vCD.entityname

            Write-Host "Launching Job for vCD server $vCDName ..."

            $Args = ("Hourly", $vCDName)

            $Jobs += Start-Job -ScriptBlock  {
                 & 'D:\CSI\app\scripts\vcd\vcloud-director.ps1' @args 
            } -ArgumentList $Args

        }

#----------------------------  E N D  L O O P  ----------------------------------------------------



#----------------------------  S T A R T  W A I T  ------------------------------------------------

    # Wait for all Jobs to complete
        Write-Host "Waiting for all jobs to Finish..."
        $starttime = Get-Date

        While (Get-Job $Jobs.id | Where {$_.State -eq "Running"}) { 
            Start-Sleep 10 

            # Stop Jobs if running longer than 50 minutes
                if (((get-date) - $starttime).Minutes -ge 50) {
                    Get-Job $Jobs.id | Stop-Job -Confirm:$false | Out-null
                }
        }

#----------------------------   E N D  W A I T  ---------------------------------------------------



#----------------------------   S T A R T  P O S T  T A S K S -------------------------------------

    # Display output from all jobs
        Get-Job $Jobs.id | Receive-Job

    # Cleanup
        Remove-Job $Jobs.id


    # Disconnect from any vCloud Director, if connected
        If ($global:DefaultCIServers) {
    	    Disconnect-CIServer -Server $global:DefaultCIServers -Force -Confirm:$false
        }

    # Log a END event in the Windows Event Log
        Write-EventLog -LogName "CSI Proxy" -Source "CSI Proxy - vCloud Director" -Message "CSI Information : END : vCloud Director Script has Ended" -EventId 500 -Category 0 -EntryType Information

#----------------------------   E N D  P O S T  T A S K S -----------------------------------------

exit
