


#----------------------------  S T A R T  P R E R E Q S  ------------------------------------------

    $Now = Get-Date

    $TargetFolder = ".\Output\Archive"
    $SourceFolder = ".\Output"	

#----------------------------  E N D  P R E R E Q S  ----------------------------------------------



#----------------------------  S T A R T  L O G  F I L E S  ---------------------------------------

    # Move Log files older then 1 month to the Archive Folder
        $LastWrite = $Now.AddMonths(-1)
        $Files = get-childitem .\Log\* -include *log.txt| Where {$_.LastWriteTime -le "$LastWrite"} 

        if ($Files){
	        foreach ($File in $Files){
		        Move-Item -Force $File $TargetFolder
		    }
        }


    # Delete Log files older then the 3 months from the Archive Folder
        $LastWrite = $Now.AddMonths(-3)
        $Files = get-childitem $TargetFolder\* -include *log.txt| Where {$_.LastWriteTime -le "$LastWrite"} 
   
       
        if ($Files){
	        foreach ($File in $Files){
		        write-host "Deleting File $File" -foregroundcolor "Red";  Remove-Item $File | out-null
		    } 
        }

#----------------------------  E N D  L O G  F I L E S  -------------------------------------------



#----------------------------  S T A R T  O U T P U T  F I L E S  ---------------------------------

    # Move Output files older then 1 Day to the Archive Folder
	    $LastWrite = $Now.AddDays(-1)
	    $Files = get-childitem $SourceFolder\* -include *.csv| Where {$_.LastWriteTime -le "$LastWrite"} 

        if ($Files){
	        foreach ($File in $Files){
		        Move-Item -Force $File $TargetFolder
		    }
        }


    # Delete Output files older then 3 Days from the Archive Folder
	    $LastWrite = $Now.AddDays(-3)
	    $Files = get-childitem $TargetFolder\* -include *.csv | Where {$_.LastWriteTime -le "$LastWrite"} 
    
        if ($Files){
	        foreach ($File in $Files){
		        write-host "Deleting File $File" -foregroundcolor "Red";  Remove-Item $File | out-null
		    } 
        }

#----------------------------  E N D  O U T P U T  F I L E S  -------------------------------------
