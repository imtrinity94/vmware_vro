###################################################################################################
# Title:	     Start Parallel
# Filename:	     Start-Parallel.ps1      	
# Created by:	 Harold Schoofs			
# Date:		     14 november 2016				
# Version:       3.0
# 
# Added:
# 23-09-2016 - v 1.0 - Initial version,to start vCenter Reporting in parallel
# 06-10-2016 - v 2.0 - Added the max 50 minutes runtime
# 14-11-2016 - v 3.0 - Renamed the vcenter script folder en script name to: vCenter / vcenter.ps1
#
# Parameters:
#  
# NAME
#     Start-Parallel.ps1 
#
# SYNTAX
#     Start-Parallel.ps1 [[-Execution] <String[]>] 
#
# PARAMETERS
#     -Execution <String[]>
#        Specifies the type of executions, mandatory
#           Hourly               All sections will be executed
#           VM                   Only VM information will be retrieved
#           Cluster              Only Cluster information will be retrieved
#           Datastore            Only Datastore information will be retrieved
#           Hosts                Only Hypervisor information will be retrieved
#
#
#  --------------  Example 1 --------------
#
# D:\Proxy\Scripts\vCenter>.\Start-Parallel.ps1 -Execution Hourly
#
# Start the script and retrieve the Daily required data
#
###################################################################################################



#----------------------------  S T A R T  P R E R E Q S  ------------------------------------------

    # Check for Execution parameter provided when Script Started
        param (
            [Parameter(Mandatory=$true)]
            [string]$Execution = "Hourly"
        )

    # Get vCenter Server from Input file
        $vCenters = Get-Content $PSScriptRoot\..\Reference.csv | ConvertFrom-Csv


    # Disconnect from any vCenter, if already connected
        If ($global:DefaultVIServers) {
    	    Disconnect-VIServer -Server $global:DefaultVIServers -Force -Confirm:$false
        }

        If ($global:DefaultSRMServers) {
    	    Disconnect-SRMServer -Server $global:DefaultSRMServers -Force -Confirm:$false
        }


    # Create the CSI Proxy Windows Eventlog and source, if it not exists
        New-EventLog -Source "CSI Proxy - vCenter" -LogName "CSI Proxy" -ErrorAction SilentlyContinue


    # Exit if no vCenters were found
        if (!$vCenters){
            Write-EventLog -LogName "CSI Proxy" -Source "CSI Proxy - vCenter" -Message "CSI Error : No vCenters found in the Input file" -EventId 502 -Category 0 -EntryType Error 
        } 

#----------------------------  E N D  P R E R E Q S  ----------------------------------------------



#----------------------------  S T A R T  L O O P  ------------------------------------------------

    # Log a START event in the Windows Event Log
        Write-EventLog -LogName "CSI Proxy" -Source "CSI Proxy - vCenter" -Message "CSI Information : START : vCenter Script has Started" -EventId 500 -Category 0 -EntryType Information


    # Start the loop, and launch the script for each vCenter in parallel
        $Jobs = @()
        foreach ($vcenter in $vcenters){
            $vCenterName = $vCenter.vCenterName

            Write-Host "Launching Job for vCenter $vCentername ..."

            $Args = ($Execution, $vCenterName)

            $Jobs += Start-Job -ScriptBlock  {
                & 'D:\Apps\CSI-SAT\runtime\applications\csi-collectors\vcenter\scripts\vCenter\vcenter.ps1' @args 
            } -ArgumentList $Args

        }

#----------------------------  E N D  L O O P  ----------------------------------------------------



#----------------------------  S T A R T  W A I T  ------------------------------------------------

    # Wait for all Jobs to complete
        Write-Host "Waiting for all jobs to Finish..."
        $starttime = Get-Date

        While (Get-Job $Jobs.id | Where {$_.State -eq "Running"}) { 
            Start-Sleep 10 

            # Stop Jobs if running longer than 50 minutes
                if (((get-date) - $starttime).Minutes -ge 50) {
                    Get-Job $Jobs.id | Stop-Job -Confirm:$false | Out-null
                }
        }

#----------------------------   E N D  W A I T  ---------------------------------------------------



#----------------------------   S T A R T  P O S T  T A S K S -------------------------------------

    # Display output from all jobs
        Get-Job $Jobs.id | Receive-Job

    # Cleanup
        Remove-Job $Jobs.id


    # Disconnect from any vCenter, if already connected
        If ($global:DefaultVIServers) {
    	    Disconnect-VIServer -Server $global:DefaultVIServers -Force -Confirm:$false
        }

        If ($global:DefaultSRMServers) {
    	    Disconnect-SRMServer -Server $global:DefaultSRMServers -Force -Confirm:$false
        }

    # Log a END event in the Windows Event Log
        Write-EventLog -LogName "CSI Proxy" -Source "CSI Proxy - vCenter" -Message "CSI Information : END : vCenter Script has Ended" -EventId 500 -Category 0 -EntryType Information

#----------------------------   E N D  P O S T  T A S K S -----------------------------------------
