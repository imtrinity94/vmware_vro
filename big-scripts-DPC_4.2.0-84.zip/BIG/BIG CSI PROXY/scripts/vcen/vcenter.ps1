#############################################################################################################################################
# Title:	     One Private Cloud vCenter Server Reporting
# Filename:	     vcenter.ps1      	
# Created by:	 Harold Schoofs			
# date:		     20 April 2018				
# Version:       OPCv1.9
# 
# Added:
# 24-10-2017 - OPC v1.0 - Based on the DPC and VPC scripts and requirements
# 24-10-2017 - OPC v1.1 - Adjusted VPC-TAI VM Customer Code detection
# 27-10-2017 - OPC v1.2 - Adjusted reporting time to UTC
# 31-10-2017 - OPC v1.3 - Changed custcode logic to take from Folder Path
# 07-11-2017 - OPC v1.4 - Changed AppPath to match correct profile
#                         Changed VMFolderPath function to handle corrupt VM folders
# 08-11-2017 - OPC v1.5 - Declare Custcode to NA, if it is not 3 characters for CIS only
# 09-02-2018 - OPC v1.6 - Various Speed Improvements and changed schedule to every 2 hours
# 16-03-2018 - OPC v1.7 - To include VcenVmVcpuUsedMaxPct (Mayank Goyal)
# 19-03-2018 - OPC v1.8 - To include VcenVmVmemUsedMaxPct (Mayank Goyal)	
# 20-04-2018 - OPC v1.9 - added diamond class (Mayank Goyal)
#
# Parameters:
#  
# NAME
#    vCenter.ps1 
#
# SYNTAX
#     vCenter.ps1 [[-Execution] <String[]>] [[-vCenterName] <String[]>] 
#
# PARAMETERS
#    -Execution <String[]>
#        Specifies the type of executions, mandatory
#           Hourly               All sections will be executed
#           VM                   Only VM information will be retrieved
#           Cluster              Only Cluster information will be retrieved
#           Datastore            Only Datastore information will be retrieved
#           Hosts                Only Hypervisor information will be retrieved
#
#    -vCenterName <String[]>
#        Specifies the FQDN of the vCenter to connect to
#
#
#  --------------  Example 1 --------------
#
# D:\CSI\app\scripts\vcen\vcenter.ps1 -Execution Hourly -vCenterName vcenter.domain.local
#
# Starts the script and retrieve the Daily required data
#
#############################################################################################################################################

# Check for Execution parameter provided when Script Started
    param (
    [Parameter(Mandatory=$true)]
    [string]$Execution = "Hourly",
    [string]$entityname 
)



#----------------------------  S T A R T  P R E R E Q S  ------------------------------------------
    # Get Start time
        $Starttime = Get-date


    # Fix when running the Script Scheduled (win2k12)
        $FIXUSER = $env:username
        $APPPATH = "C:\Users\" + $FIXUSER + "\AppData\Roaming"


    # Set the AppData environment variable if needed
        if ($env:appdata -eq $null -or $env:appdata -eq 0){
	        $env:appdata = $APPPATH
        }

    # Import Modules
        Get-Module -Name VMware* -ListAvailable | Import-Module


    # Add PowerCLI Snap-in and PowerCLI Cloud Snap-in
        Add-PSsnapin VMware.VimAutomation.Core -Erroraction Silentlycontinue


    # Disconnect if already connected
        If ($global:DefaultVIServers) {
            Disconnect-VIServer -Server $global:DefaultVIServers -Force -Confirm:$false
        }

        If ($global:DefaultSRMServers) {
            Disconnect-SRMServer -Server $global:DefaultSRMServers -Force -Confirm:$false
        }


    # Clear all Variables, just in case
        if ($PerVm_Overview) {Clear-Variable PerVM_Overview}
        if ($PerCluster_Overview) {Clear-Variable PerCluster_Overview}
        if ($PerDatastore_Overview) {Clear-Variable PerDatastore_Overview}
        if ($PerHypervisor_Overview) {Clear-Variable PerHypervisor_Overview}
        if ($myCol) {Clear-Variable myCol}
        if ($myObj) {Clear-Variable myObj}
        if ($datastores) {Clear-Variable Datastores}
        if ($AllHosts) {Clear-Variable AllHosts}
        if ($clusters) {Clear-Variable Clusters}
        if ($cluster) {Clear-Variable Cluster}
        if ($vms) {Clear-Variable VMs}
        if ($statcpu) {Clear-Variable statcpu}
        if ($statmem) {Clear-Variable statmem}
        if ($statpower) {Clear-Variable statpower}
        if ($statupt) {Clear-Variable statosuptime}

		
    # Script Name
        $ScriptName = $MyInvocation.MyCommand.Name

		
    # Log file 
        $logfile = "$PSScriptRoot\..\..\logs\vCenter-"+$entityname.split(".")[0] +"-log.txt"

		
    # Determine Central Repository for Output
		$CSI_Output_Folder = "$PSScriptRoot\..\..\..\data\raw\input\"

		
    # Function to log timestamp and text to console and log file
        function Write-CustomOut ($Details){
    	    $Logdate = [datetime]::UtcNow.ToString("MM'-'dd'-'yyyy' 'HH':'mm':'ss")
            write-output "$($Logdate) (UTC) $Details" | out-file -encoding "ASCII" -append $logfile
            }


    # Function to write events to eventlog for monitoring
        function Write-Event {
            [CmdletBinding()]
            [OutputType([int])]
            Param (
                [Parameter(Mandatory=$true)][string]$EntryType,
                [Parameter(Mandatory=$true)][string]$Message
            )
            
            if ($Entrytype -eq "Information"){ $EventId = 500 }
            if ($Entrytype -eq "Warning")    { $EventId = 501 }
            if ($Entrytype -eq "Error")      { $EventId = 502 }

            if ($EventID){
                Write-EventLog -LogName "CSI Proxy" -Source "CSI Proxy - vCenter" -Message "CSI $EntryType : $ScriptName : $Message" -EventId $EventID -Category 0 -EntryType $EntryType
                }

            # Examples: 
                #  Write-Event Error "Something wrong happened, and we stopped" 
                #  Write-Event Warning "Something bad happened, but we will go on" 
                #  Write-Event Information "Nothing bad happened, happy" 
        }




    # Function to retrieve full folder path per VM
        function Get-VMFolderPath {  
        Begin {}
        Process {  
            foreach ($vmdetailed in $Input) {  
            $DataCenter = $vmdetailed.id | Get-Datacenter
            $DataCenterName = $DataCenter.Name  
            $VMname = $vmdetailed.Name  
            $VMParentName = get-folder -id ($vmdetailed.parent)
            if ($vmdetailed.ParentVApp.value){
                # if parent folder is vApp, get vApp parent folder
	            $VMParentName = get-folder -id (get-vapp -id "VirtualApp-$($vmdetailed.ParentVApp.value)").extensiondata.parentfolder.tostring()
            }
            if ($VMParentName){
            if ($VMParentName.Name -eq "vm") {
                $FolderStructure = "{0}\{1}" -f $DataCenterName, $VMname  
                $FolderStructure
                Continue  
            }
            else {  
                $FolderStructure = "{0}\{1}" -f $VMParentName.Name, $VMname  
                $VMParentID = Get-Folder -Id $VMParentName.ParentId  
                do {  
                $ParentFolderName = $VMParentID.Name  
                if ($ParentFolderName -eq "vm") {  
                    $FolderStructure = "$DataCenterName\$FolderStructure"  
                    $FolderStructure  
                    break  
                } 
                $FolderStructure = "$ParentFolderName\$FolderStructure"  
                $VMParentID = Get-Folder -Id $VMParentID.ParentId  
                } #do  
                until ($VMParentName.ParentId -eq $DataCenter.Id) #until  
            } 
            } 
            }
        } 
        End {}
        }


    # Log status
        Write-CustomOut "-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_"
        Write-CustomOut "-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_"
        Write-CustomOut "Starting the vCenter script..."
        Write-CustomOut "Execution   parameter is $Execution"
        Write-CustomOut "vCenterName parameter is $entityname"
        Write-Event Information "START : $entityname : Starting the vCenter script..."

#----------------------------  E N D  P R E R E Q S  ----------------------------------------------    


#----------------------------  S T A R T  v C E N T E R  I N F O  ---------------------------------


    # Get vCenter Server from Input file
        $vcenters = Get-Content $PSScriptRoot\..\..\configuration\config.csv | ConvertFrom-Csv | Where {$_.entitytype -eq "vcen"}
        $vcenter = $vcenters | Where { $_.entityname -eq $entityname }


    # Determine  vCenter Server
        $entityname = $vcenter.entityname
        $domain = $entityname.split(".")[1,2] -join "."

        Write-CustomOut "Starting on vCenter Server:  $entityname ..."


    # Get the Parameters from Input File
        $custcode    = $vcenter.custcode      # CustomerCode, for VPC will be derived from vcenter
        $countrycode = $vcenter.countrycode   # CountryCode for this vcenter location
        $entitytype  = $vcenter.entitytype    # Will be vcen for this script
        $location    = $vcenter.location      # This is the Datacenter Code
        $ptfcode     = $vcenter.ptfcode       # Atos Cloud Platform (DPC/VPC)
        $ptfsubcode  = $vcenter.ptfsubcode    # Only if relevant. (Within VPC: CIS/TAI)


#----------------------------  E N D  v C E N T E R  I N F O  -------------------------------------


#----------------------------  S T A R T  v C E N T E R  C O N N E C T  ---------------------------

    # Get the credentials, if file in use retry max. 10 times
        $Tries = 0
        if ($creds){Clear-Variable Creds}
            While (!$creds -and $Tries -lt 10) {
            try { 
                Start-Sleep (Get-Random -Max 5)
                $creds = Get-VICredentialStoreItem -Host $entityname -File $PSScriptRoot\credentials\credentials.xml -ErrorAction Stop
                Write-CustomOut "Credentials for $entityname found"
                }
            catch {
                Write-CustomOut "Credentials for $entityname NOT found, retrying"
                $Tries = $Tries + 1
                }
        }


    # Check whether the Credentials have been found
        if (!$creds){
            $ErrorMessage = $error[0] | out-string
            Write-Event Error "Credentials for $entityname were NOT found, unable to connect to vCenter. Exiting Script. ERROR: `n $ErrorMessage"
            Write-CustomOut   "Credentials for $entityname were NOT found, unable to connect to vCenter. Exiting Script"
            exit
        }



    # Now let's connect
        Set-PowerCLIConfiguration -DefaultVIServerMode Multiple -Scope Session -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
        $vcenter = Connect-VIServer -Server $creds.Host -User $creds.User -Password $creds.Password

    # Connect to the related SRM Server
        $srm = Connect-SrmServer -Server $creds.Host -User $creds.User -Password $creds.Password -ErrorAction:SilentlyContinue

    # Check whether the vCenter Connection has been made
        if (!$global:DefaultVIServers){
            $ErrorMessage = $error[0] | out-string
            Write-Event Error "No connection to $entityname was made. Exiting Script. ERROR: `n $ErrorMessage"
            write-CustomOut   "No connection to $entityname was made. Exiting Script"
            exit
        }
                

#----------------------------  E N D  v C E N T E R  C O N N E C T  -------------------------------



#----------------------------  S T A R T  v C E N T E R  D A T A  ---------------------------------

    # Get all the clusters in the vCenter Server
        $clusters = Get-cluster | sort

    # Check whether Clusters have been found
        if (!$clusters){
            Write-Event Error "No clusters for $entityname were found, nothing to query. Exiting Script"
            write-CustomOut   "No clusters for $entityname were found, nothing to query. Exiting Script"
            exit
        }


    # Only continue of there are any clusters
        If ($clusters){
            Write-CustomOut "Starting working on Clusters ..."
            $PerVm_Overview         = @()
            $PerCluster_Overview    = @()
            $PerDatastore_Overview  = @()
            $PerHypervisor_Overview = @()

        
            # Get the statistics for all vCenter Clusters at once
                $counters       = @()
                $counters      += "cpu.usagemhz.average"
                $counters      += "mem.consumed.average"
                $clusters_stats = Get-Stat -Entity ($clusters) -Realtime -Start (Get-date).AddHours(-1) -Stat $counters -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | Group-Object -Property EntityID
                        
                if (!$clusters_stats){
                    Write-Event Warning "Cluster Statistics not queried for $entityname Possibly check https://kb.vmware.com/kb/2107096"
                    write-CustomOut   "Cluster Statistics not queried for $entityname Possibly check https://kb.vmware.com/kb/2107096"
                }


#----------------------------  S T A R T  C L U S T E R S  R E P O R T I N G   --------------------

                ForEach ($cluster in $clusters){
        
                    Write-CustomOut "Starting working on Cluster $cluster ..."

                    # As we collect everything at once, time capture is also only once
                        $date       = get-date -uformat "%Y%m%d"
                        $time       = [datetime]::UtcNow.ToString("HH':'mm':'ss")


                    # Collect the VMs, exclude PlaceHolder VMs, excl
                        $rp = Get-View ($cluster| Get-View).ResourcePool
                        $vmsdetailed = Get-View -ViewType VirtualMachine -SearchRoot $rp.MoRef -Property Name,Config,Parent,ParentVApp,Runtime,Guest,Summary,ResourceConfig,Storage
                        filter isVM { if ($_.Summary.Config.Template -eq $False -and $_.Config.ManagedBy.extensionKey -notmatch "com.vmware.vcDr" -and $_.Config.ManagedBy.Type -ne "placeholderVm") { $_ } }
                        $vms        = get-vm -id ($vmsdetailed | isVM).moref | sort name
                        $vms_Count  = $vms.count.tostring()


                    # Collect the Datastores
                        $datastores = $cluster | Get-Datastore | Where { $_.name -notlike "*-Templates"}


                    # Collect the Hosts
                        $AllHosts   = $cluster | Get-VMHost
                        $Hostsdetailed = Get-View -ViewType HostSystem -Property Name,Summary,Hardware,Runtime,VM,datastore

                    # Start the per Cluster reporting
                        if ($Execution -eq "Hourly" -or $Execution -eq "Cluster"){


                            Write-CustomOut "Start the per Cluster reporting ..."
                            # Get Cluster Detailed Object
                                $clusterDetailed     = $cluster.extensiondata
                            # Collect the Datastore Classes
                                $datastores_classes  = $datastores         | Where { $_.name.split("-")[1].length -ge 3}
                                $datastores_platinum = $datastores_classes | Where { $_.name.split("-")[1].substring(0,3) -like "?pl" -or $_.name.split("-")[1].substring(0,3) -like "pl?" -or $_.name.split("-")[1].substring(0,3) -like "P??" }
                                $datastores_gold     = $datastores_classes | Where { $_.name.split("-")[1].substring(0,3) -like "?go" -or $_.name.split("-")[1].substring(0,3) -like "go?" -or $_.name.split("-")[1].substring(0,3) -like "G??" }
                                $datastores_silver   = $datastores_classes | Where { $_.name.split("-")[1].substring(0,3) -like "?si" -or $_.name.split("-")[1].substring(0,3) -like "si?" -or $_.name.split("-")[1].substring(0,3) -like "S??" }
                                $datastores_bronze   = $datastores_classes | Where { $_.name.split("-")[1].substring(0,3) -like "?br" -or $_.name.split("-")[1].substring(0,3) -like "br?" -or $_.name.split("-")[1].substring(0,3) -like "B??" }
								$datastores_diamond     = $datastores_classes | Where { $_.name.split("-")[1].substring(0,3) -like "?di" -or $_.name.split("-")[1].substring(0,3) -like "di?" -or $_.name.split("-")[1].substring(0,3) -like "D??" }
								
                            # Examine HA Status
                                $VcenCluHaStatus     = "Unknown"
                                if ($cluster.HAEnabled -eq $False){
                                    $VcenCluHaStatus = "Disabled"
                                    }

                                if ($cluster.HAEnabled -eq $True){
                                    $VcenCluHaStatus = "Enabled"
                                    }

                            # Get the Statistics
                                $clusterstats        = ($clusters_stats | Where {$_.name -eq $cluster.ID}).group  | group-object -Property MetricID
                                $Stat_Avg_Cpu_Ghz_Past_Hour  = [math]::Round(((($clusterstats | Where {$_.name -eq "cpu.usagemhz.average"}).group | Measure-Object -Property Value -Average | Select -ExpandProperty Average)/1024),2)
                                $Stat_Avg_Mem_Gb_Past_Hour   = [math]::Round(((($clusterstats | Where {$_.name -eq "mem.consumed.average"}).group | Measure-Object -Property Value -Average | Select -ExpandProperty Average)/1MB),2)

                                if (!$clusterstats){
                                    $Stat_Avg_Cpu_Ghz_Past_Hour  = $Null
                                    $Stat_Avg_Mem_Gb_Past_Hour   = $Null
                                    Write-Event Warning "Cluster Statistics not queried for $cluster . Possibly check https://kb.vmware.com/kb/2107096"
                                    write-CustomOut   "Cluster Statistics not queried for $cluster . Possibly check https://kb.vmware.com/kb/2107096"

                                }

                            # Start collecting the data
                                $myObj = "" | Select date,time,countrycode,custcode,`
                                                    ptfsubcode,VcenCluName,VcenCluVcenName,`
                                                    VcenCluDcCode,VcenCluNoOfHosts,VcenCluNoOfDatastores,`
                                                    VcenCluNoOfVms,VcenCluNoOfCpuCores,VcenCluNoOfCpuThreads,`
                                                    VcenCluNoOfvCpuUsed,VcenCluCpuTotalGhz,VcenCluCpuUsedGhz,`
                                                    VcenCluCpuFreeGhz,VcenCluMemTotalGb,VcenCluMemUsedGb,VcenCluMemFreeGb,`
                                                    VcenCluStgTotalGb,VcenCluStgUsedGb,VcenCluStgFreeGb,VcenCluStgProvGb,`
                                                    VcenCluPtStgTotalGb,VcenCluPtStgUsedGb,VcenCluPtStgFreeGb,`
                                                    VcenCluGoStgTotalGb,VcenCluGoStgUsedGb,VcenCluGoStgFreeGb,`
                                                    VcenCluSiStgTotalGb,VcenCluSiStgUsedGb,VcenCluSiStgFreeGb,`
                                                    VcenCluBrStgTotalGb,VcenCluBrStgUsedGb,VcenCluBrStgFreeGb,`
													VcenCluDiStgTotalGb,VcenCluDiStgUsedGb,VcenCluDiStgFreeGb,`
                                                    VcenCluHaStatus,VcenCluHaCpuFailThresPct,VcenCluHaMemFailThresPct

                                $myObj.date                  = $date
                                $myObj.time                  = $time
                                $myObj.countrycode           = $countrycode
                                
                                if ($ptfcode -eq "vpc"){
                                    $myObj.custcode          = $cluster.name.split("-")[0].ToUpper()
                                } else { 
                                    $myObj.custcode          = $custcode.toUpper().toString()
                                }     
                                $myObj.ptfsubcode            = $ptfsubcode.toUpper().toString()
                                $myobj.VcenCluName           = $cluster.Name
                                $myobj.VcenCluVcenName       = $entityname.split(".")[0].ToUpper()
                                $myobj.VcenCluDcCode         = $location
                                $myobj.VcenCluNoOfHosts      = $clusterDetailed.Host.Count
                                $myobj.VcenCluNoOfDatastores = $clusterDetailed.Datastore.Count
                                $myobj.VcenCluNoOfVms        = $vms_Count
                                $myobj.VcenCluNoOfCpuCores   = $clusterDetailed.summary.NumCpuCores
                                $myobj.VcenCluNoOfCpuThreads = $clusterDetailed.summary.NumCpuThreads
                                $myobj.VcenCluNoOfvCpuUsed   = ($vms.numcpu | Measure-Object -sum).sum
                                $myobj.VcenCluCpuTotalGhz    = [math]::Round((((($AllHosts | Measure-Object -Property CpuTotalMhz -Sum).sum)/1024)),2)
                                $myobj.VcenCluCpuUsedGhz     = $Stat_Avg_Cpu_Ghz_Past_Hour
                                $myobj.VcenCluCpuFreeGhz     = $myobj.VcenCluCpuTotalGhz - $myobj.VcenCluCpuUsedGhz 
                                $myobj.VcenCluMemTotalGb     = [math]::Round((($AllHosts | Measure-Object -Property MemoryTotalGB -Sum).sum),2)
                                $myobj.VcenCluMemUsedGb      =  $Stat_Avg_Mem_Gb_Past_Hour
                                $myobj.VcenCluMemFreeGb      =  [math]::Round(($myobj.VcenCluMemTotalGb - $myobj.VcenCluMemUsedGb),2)
                                $myobj.VcenCluStgTotalGb     = [math]::Round((($datastores | Measure-Object -Property CapacityGB -Sum).sum),2)
                                $myobj.VcenCluStgFreeGb      = [math]::Round((($datastores | Measure-Object -Property FreeSpaceGB -Sum).sum),2)
                                $myobj.VcenCluStgUsedGb      = $myobj.VcenCluStgTotalGb - $myobj.VcenCluStgFreeGb
                                $myobj.VcenCluStgProvGb      = [math]::Round((($vms | Measure-Object -Property ProvisionedSpaceGB -Sum).sum),2)

                            # Storage Classed only if they exist

                                if ($datastores_platinum){
                                    $myobj.VcenCluPtStgTotalGb = [math]::Round((($datastores_platinum | Measure-Object -Property CapacityGB -Sum).sum),2)
                                    $myobj.VcenCluPtStgFreeGb  = [math]::Round((($datastores_platinum | Measure-Object -Property FreeSpaceGB -Sum).sum),2)
                                    $myobj.VcenCluPtStgUsedGb  = $myobj.VcenCluPtStgTotalGb - $myobj.VcenCluPtStgFreeGb
                                }
                                
                                if ($datastores_gold){
                                    $myobj.VcenCluGoStgTotalGb = [math]::Round((($datastores_gold | Measure-Object -Property CapacityGB -Sum).sum),2)
                                    $myobj.VcenCluGoStgFreeGb  = [math]::Round((($datastores_gold | Measure-Object -Property FreeSpaceGB -Sum).sum),2)
                                    $myobj.VcenCluGoStgUsedGb  = $myobj.VcenCluGoStgTotalGb - $myobj.VcenCluGoStgFreeGb
                                }

                                if ($datastores_silver){
                                    $myobj.VcenCluSiStgTotalGb = [math]::Round((($datastores_silver | Measure-Object -Property CapacityGB -Sum).sum),2)
                                    $myobj.VcenCluSiStgFreeGb  = [math]::Round((($datastores_silver | Measure-Object -Property FreeSpaceGB -Sum).sum),2)
                                    $myobj.VcenCluSiStgUsedGb  = $myobj.VcenCluSiStgTotalGb - $myobj.VcenCluSiStgFreeGb
                                }

                                if ($datastores_bronze){
                                    $myobj.VcenCluBrStgTotalGb = [math]::Round((($datastores_bronze | Measure-Object -Property CapacityGB -Sum).sum),2)
                                    $myobj.VcenCluBrStgFreeGb  = [math]::Round((($datastores_bronze | Measure-Object -Property FreeSpaceGB -Sum).sum),2)
                                    $myobj.VcenCluBrStgUsedGb  = $myobj.VcenCluBrStgTotalGb - $myobj.VcenCluBrStgFreeGb
                                }
								
								if ($datastores_diamond){
                                    $myobj.VcenCluDiStgTotalGb = [math]::Round((($datastores_diamond | Measure-Object -Property CapacityGB -Sum).sum),2)
                                    $myobj.VcenCluDiStgFreeGb  = [math]::Round((($datastores_diamond | Measure-Object -Property FreeSpaceGB -Sum).sum),2)
                                    $myobj.VcenCluDiStgUsedGb  = $myobj.VcenCluDiStgTotalGb - $myobj.VcenCluDiStgFreeGb
                                }
								
                                $myobj.VcenCluHaStatus          = $VcenCluHaStatus
                                $myobj.VcenCluHaCpuFailThresPct = $clusterDetailed.Configuration.DasConfig.AdmissionControlPolicy.CpuFailoverResourcesPercent
                                $myobj.VcenCluHaMemFailThresPct = $clusterDetailed.Configuration.DasConfig.AdmissionControlPolicy.MemoryFailoverResourcesPercent

                                $PerCluster_Overview += $myObj

                        }

#----------------------------  S T A R T  H Y P E R V I S O R  R E P O R T I N G  -----------------

                            if ($Execution -eq "Hourly" -or $Execution -eq "Hosts"){
                                Write-CustomOut "Start the per Hypervisor reporting ..."

                                # Get the statistics for all hosts at once
                                    $counters = @()
                                    $counters += "cpu.usagemhz.average"
                                    $counters += "mem.consumed.average" 
                                    $counters += "net.usage.average"
                                    $counters += "net.bytesRx.average"
                                    $counters += "net.bytesTx.average"
                                    $Hypervisor_stats = Get-Stat -Entity ($AllHosts) -Realtime -Start (Get-date).AddHours(-1) -Stat $counters -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | Group-Object -Property EntityID  

                                Foreach ($vmHost in $AllHosts){
                                    # Get the VMHost Detailed Object
                                        $vmHostDetailed = $Hostsdetailed | Where {$_.moref -eq $vmHost.id}

                                    # Get the past day statistics
                                        $vmHostStats                    = ($Hypervisor_stats | Where {$_.name -eq $vmHost.ID}).group         | group-object -Property MetricID
                             
                                        $Stat_Cpu_Mhz_Past_Hour         = ($vmHostStats | Where {$_.name -eq "cpu.usagemhz.average"}).group  | Measure-Object -Property Value -Maximum -Average
                                        $Stat_Avg_Cpu_Mhz_Past_Hour     = [math]::Round(($Stat_Cpu_Mhz_Past_Hour.Average),2)
                                        $Stat_Max_Cpu_Mhz_Past_Hour     = [math]::Round(($Stat_Cpu_Mhz_Past_Hour.Maximum),2)
                                        $Stat_Mem_Gb_Past_Hour          = ($vmHostStats | Where {$_.name -eq "mem.consumed.average"}).group  | Measure-Object -Property Value -Maximum -Average
                                        $Stat_Avg_Mem_Gb_Past_Hour      = [math]::Round((($Stat_Mem_Gb_Past_Hour.Average)/1MB),2)
                                        $Stat_Max_Mem_Gb_Past_Hour      = [math]::Round((($Stat_Mem_Gb_Past_Hour.Maximum)/1MB),2)
                                        $Stat_Net_Kbps_Past_Hour        = ($vmHostStats | Where {$_.name -eq "net.usage.average"}).group     | Where {$_.Instance -eq ""} | Measure-Object -Property Value -Maximum -Average
                                        $Stat_Avg_Net_Kbps_Past_Hour    = [math]::Round((($Stat_Net_Kbps_Past_Hour.Average)),2)
                                        $Stat_Net_Kbps_Rx_Past_Hour     = ($vmHostStats | Where {$_.name -eq "net.bytesRx.average"}).group   | Where {$_.Instance -eq ""} | Measure-Object -Property Value -Maximum -Average
                                        $Stat_Avg_Net_Kbps_Rx_Past_Hour = [math]::Round((($Stat_Net_Kbps_Rx_Past_Hour.Average)),2)
                                        $Stat_Net_Kbps_Tx_Past_Hour     = ($vmHostStats | Where {$_.name -eq "net.bytesTx.average"}).group   | Where {$_.Instance -eq ""} | Measure-Object -Property Value -Maximum -Average
                                        $Stat_Avg_Net_Kbps_Tx_Past_Hour = [math]::Round((($Stat_Net_Kbps_Tx_Past_Hour.Average)),2)

                                    # Start collecting the data
                                        $myObj = "" | Select date,time,countrycode,custcode,`
                                                                ptfsubcode,VcenHypName,VcenHypCluName,`
                                                                VcenHypVcenName,VcenHypDcCode,VcenHypSrvMfgName,`
                                                                VcenHypSrvModelName,VcenHypSrvCpuType,VcenHypSrvSvcTag,`
                                                                VcenHypSrvBiosVer,VcenHypNoOfCpuSockets,VcenHypNoOfCpuCores,`
                                                                VcenHypNoOfProcessors,VcenHypNoOfNics,VcenHypHtStatus,`
                                                                VcenHypHaStatus,VcenHypFtStatus,VcenHypEvcMode,`
                                                                VcenHypEsxVersion,VcenHypEsxBuildNumber,VcenHypNoOfVms,`
                                                                VcenHypNoOfDatastore,VcenHypCpuTotalMhz,VcenHypCpuAvgUsedMhz,`
                                                                VcenHypCpuMaxUsedMhz,VcenHypMemTotalGb,VcenHypMemAvgUsedGb,`
                                                                VcenHypMemMaxUsedGb,vCenHypNtwkAvgKbps,vCenHypNtwkAvgTxKbps,vCenHypNtwkAvgRxKbps
                                        $myObj.date                  = $date
                                        $myObj.time                  = $time
                                        $myObj.countrycode           = $countrycode
                                        if ($ptfcode -eq "vpc"){
                                            $myObj.custcode          = $cluster.name.split("-")[0].ToUpper()
                                        } else { 
                                            $myObj.custcode          = $custcode.toUpper().toString()
                                        }                                          
                                        
                                        $myObj.ptfsubcode            = $ptfsubcode.toUpper().toString()
                                        $myObj.VcenHypName           = $vmHost.Name
                                        $myObj.VcenHypCluName        = $cluster.Name
                                        $myObj.VcenHypVcenName       = $entityname.split(".")[0].ToUpper()
                                        $myObj.VcenHypDcCode         = $location 
                                        $myObj.VcenHypSrvMfgName     = $vmHost.Manufacturer
                                        $myObj.VcenHypSrvModelName   = $vmHost.Model
                                        $myObj.VcenHypSrvCpuType     = $vmHost.ProcessorType
                                        $myObj.VcenHypSrvSvcTag      = ($vmHostDetailed.Summary.Hardware.OtherIdentifyingInfo | Where {$_.IdentifierType.key -eq "ServiceTag"} | Select -Last 1).IdentifierValue.toUpper()
                                        $myObj.VcenHypSrvBiosVer     = $vmHostDetailed.Hardware.BiosInfo.BiosVersion
                                        $myObj.VcenHypNoOfCpuSockets = $vmHostDetailed.Summary.Hardware.NumCpuPkgs
                                        $myObj.VcenHypNoOfCpuCores   = $vmHostDetailed.Summary.Hardware.NumCpuCores
                                        $myObj.VcenHypNoOfProcessors = $vmHostDetailed.Summary.Hardware.NumCpuThreads
                                        $myObj.VcenHypNoOfNics       = $vmHostDetailed.Summary.Hardware.NumNics
                                        $myObj.VcenHypHtStatus       = $vmHost.HyperthreadingActive
                                        $myObj.VcenHypHaStatus       = $vmHostDetailed.Runtime.DasHostState.State
                                        $myObj.VcenHypFtStatus       = $vmHostDetailed.Summary.Config.FaultToleranceEnabled
                                        $myObj.VcenHypEvcMode        = $vmHost.MaxEVCMode
                                        $myObj.VcenHypEsxVersion     = $vmHost.Version
                                        $myObj.VcenHypEsxBuildNumber = $vmHost.Build
                                        $myObj.VcenHypNoOfVms        = $vmHostDetailed.Vm.count
                                        $myObj.VcenHypNoOfDatastore  = $vmHostDetailed.Datastore.count
                                        $myObj.VcenHypCpuTotalMhz    = $vmHost.CpuTotalMhz
                                        $myObj.VcenHypCpuAvgUsedMhz  = $Stat_Avg_Cpu_Mhz_Past_Hour
                                        $myObj.VcenHypCpuMaxUsedMhz  = $Stat_Max_Cpu_Mhz_Past_Hour
                                        $myObj.VcenHypMemTotalGb     = [decimal]::round($vmHost.MemoryTotalGB,2)
                                        $myObj.VcenHypMemAvgUsedGb   = $Stat_Avg_Mem_Gb_Past_Hour
                                        $myObj.VcenHypMemMaxUsedGb   = $Stat_Max_Mem_Gb_Past_Hour
                                        $myObj.vCenHypNtwkAvgKbps    = $Stat_Avg_Net_Kbps_Past_Hour
                                        $myObj.vCenHypNtwkAvgTxKbps  = $Stat_Avg_Net_Kbps_Tx_Past_Hour
                                        $myObj.vCenHypNtwkAvgRxKbps  = $Stat_Avg_Net_Kbps_Rx_Past_Hour
                                        $PerHypervisor_Overview += $myObj
                                }
                            }

#----------------------------  E N D  H Y P E R V I S O R  R E P O R T I N G  ---------------------

#----------------------------  S T A R T  V M  R E P O R T I N G  ---------------------------------

                            if ($Execution -eq "Hourly" -or $Execution -eq "VM"){
                                Write-CustomOut "Start the per VM reporting ..."


                                # Get all statistics upfront, and group them for fast querying
                                    Write-CustomOut "Start Collecting Performance Statistics for $cluster ..."

                                    $counters      = @()
                                    $counters     += "cpu.usagemhz.average"
                                    $counters     += "cpu.usage.average" 
                                    $counters     += "mem.active.average"
                                    $counters     += "mem.usage.average" 
                                    $counters     += "net.usage.average"
                                    $counters     += "net.bytesRx.average"
                                    $counters     += "net.bytesTx.average"
                                    $counters     += "power.power.average" 
                                    $counters     += "virtualdisk.writeoio.latest"
                                    $counters     += "virtualdisk.readoio.latest"
                                    $counters     += "sys.osUptime.latest"
                                    $counters     += "sys.Uptime.latest"
                                    $counters     += "disk.numberwrite.summation"
                                    $counters     += "disk.numberread.summation"
                                    $vms_stats     = Get-Stat -Entity ($vms) -Realtime -Start (Get-date).AddHours(-1) -Stat $counters -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | Group-Object -Property EntityID

                                    Write-CustomOut "End Collecting Performance Statistics for $cluster ..."

                                # Start the VM loop to get all information
                                    Write-CustomOut "Getting All Information for the VMs ($vms_Count) in $cluster ..."
    	                            ForEach ($vm in $vms){
                                        $vm_Name = $vm.Name.split("(")[0]
                                    # Get the VM Detailed Object
                                        $vmDetailed = $vmsDetailed | Where {$_.moref -eq $vm.id}

                                    # Get the VM Folderpath
                                        $vmfolderpath = $vmDetailed | Get-VMFolderPath

                                    # Query the statistics for this VM 
                                        $vm_Cpu_Mhz      = @()
                                        $vm_Cpu_Pct      = @()
                                        $vm_Mem_KB       = @()
                                        $vm_Mem_Pct      = @()
                                        $vm_Power        = @()
                                        $vm_Dsk_Io_Write = @()
                                        $vm_Dsk_Io_Read  = @()
                                        $vm_Net_Kbps     = @()
                                        $vm_Uptime       = @()
                                        $vm_OsUptime     = @()
                                        $vmStats         = ($vms_stats | Where {$_.name -eq $vm.ID}).group  | group-object -Property MetricID

                                        $vmNumHardDisks  = ($vm | Get-HardDisk).count
                                        $vm_Cpu_Mhz      = ($vmStats | Where {$_.name -eq "cpu.usagemhz.average"}).group         | Where {$_.Instance -eq ""} | Select -First 180                   | Measure-Object -Property value -Average -Maximum
                                        $vm_Cpu_Pct      = ($vmStats | Where {$_.name -eq "cpu.usage.average"}).group                                         | Select -First 180                   | Measure-Object -Property value -Average -Maximum
                                        $vm_Mem_KB       = ($vmStats | Where {$_.name -eq "mem.active.average"}).group                                        | Select -First 180                   | Measure-Object -Property value -Average -Maximum
                                        $vm_Mem_Pct      = ($vmStats | Where {$_.name -eq "mem.usage.average"}).group                                         | Select -First 180                   | Measure-Object -Property value -Average -Maximum
                                        $vm_Power        = ($vmStats | Where {$_.name -eq "power.power.average"}).group                                       | Select -First 180                   | Measure-Object -Property value -Average
                                        $vm_Dsk_Io_Write = ($vmStats | Where {$_.name -eq "virtualdisk.writeoio.latest"}).group                               | Select -First ($vmNumHardDisks*180) | Measure-Object -Property value -Sum
                                        $vm_Dsk_Io_Read  = ($vmStats | Where {$_.name -eq "virtualdisk.readoio.latest"}).group                                | Select -First ($vmNumHardDisks*180) | Measure-Object -Property value -Sum
                                        $vm_Net_Kbps     = ($vmStats | Where {$_.name -eq "net.usage.average"}).group            | Where {$_.Instance -eq ""} | Select -First 180                   | Measure-Object -Property value -Average
                                        $vm_Net_Tx_Kbps  = ($vmStats | Where {$_.name -eq "net.bytesTx.average"}).group          | Where {$_.Instance -eq ""} | Select -First 180                   | Measure-Object -Property value -Average
                                        $vm_Net_Rx_Kbps  = ($vmStats | Where {$_.name -eq "net.bytesRx.average"}).group          | Where {$_.Instance -eq ""} | Select -First 180                   | Measure-Object -Property value -Average
                                        $vm_OsUptime     = ($vmStats | Where {$_.name -eq "sys.osUptime.latest"}).group                                       | Select -First 180 
                                        $vm_Uptime       = ($vmStats | Where {$_.name -eq "sys.Uptime.latest"} ).group                                        | Select -First 180 

                                    # Get VM Overview per Virtual Machine
                                        $myObj = "" | Select date,time,countrycode,custcode,ptfsubcode,`
                                                            VcenVmId,VcenVmClientName,VcenVmDispName,VcenVmVcenName,VcenVmCluName,`
                                                            VcenVmDcCode,VcenVmRpoolName,VcenVmDnsName,VcenVmOsName,VcenVmOsVersion,`
                                                            VcenVmVcpuModel,VcenVmNoOfVcpuAlocCount,VcenVmVcpuMaxMhz,`
                                                            VcenVmVcpuReservedMhz,VcenVmVcpuUsedMhz,VcenVmVcpuUsedPct,VcenVmVcpuUsedMaxPct,`
                                                            VcenVmVmemAlocGb,VcenVmVmemMaxGb,VcenVmVmemReservedGb,VcenVmVmemUsedGb,VcenVmVmemUsedPct,VcenVmVmemUsedMaxPct,`
                                                            VcenVmVmUptimePct,VcenVmOsUptimePct,VcenVmStgAlocGb,VcenVmStgUsedGb,`
                                                            VcenVmStgPlatAlocGb,VcenVmStgGoldAlocGb,VcenVmStgDiamAlocGb,VcenVmStgSilvAlocGb,VcenVmStgBronAlocGb,`
                                                            VcenVmStgArchAlocGb,VcenVmStgOtheAlocGb,VcenVmPowerState,VcenVmPowerUsedWatts,VcenVmToolsStatus,`
                                                            VcenVmDrProtectStatus,VcenVmNtwk1,VcenVmNtwk2,VcenVmNtwk3,VcenVmNtwk4,VcenVmNtwk5,`
                                                            VcenVmNtwk6,VcenVmNtwk7,VcenVmNtwk8,VcenVmNtwk9,VcenVmNtwk10,VcenVmNtwkUsageKbps,`
                                                            VcenVmNtwkAvgTxKbps,VcenVmNtwkAvgRxKbps,VcenVmStgIopsBytes
                                        $myObj.date             = $date
                                        $myObj.time             = $time
                                        $myObj.countrycode      = $countrycode
                                        $myObj.VcenVmClientName = $vmDetailed.Name.Split(".")[0].ToUpper()
                                        $myObj.VcenVmDispName   = $vmDetailed.Name.ToLower()
                                    # to be very unique, combine vCenter UUID and VM UUID
                                        $myObj.VcenVmId         = $global:DefaultVIServer.InstanceUuid+"-"+$vmDetailed.config.InstanceUuid
                                    # Custcode for VPC
                                        if ($ptfcode -eq "vpc"){
                                            # Default CustCode
                                                $myObj.custcode = "NA"
                                                    
                                            # CIS
                                                if ($ptfsubcode -eq "cis"){
                                                    if ($vmfolderpath.split("\")[2]){
                                                        $myObj.custcode = $vmfolderpath.split("\")[2].toUpper()

                                                        # Check if the parent folder is a two digit named folder, starting with a '0' (00, 01 etc)
                                                            If ($vmfolderpath.split("\")[1] -notmatch '0\d'){
                                                                $myObj.custcode = "NA"
                                                            }
                                                    }
                                                }

                                            # TAI
                                                if ($ptfsubcode -eq "tai"){
                                                    $myObj.custcode = $vm.folder.parent.parent.name.split("-")[0].toUpper()

                                                    if ($vmDetailed.Name -like "vse-*"){
                                                        $myObj.custcode = "MGT"
                                                    }

                                                    if ($vmfolderpath.split("\")[2] -like "MGT*"){
                                                        $myObj.custcode = "MGT"

                                                        # Check if the parent folder is a two digit named folder, starting with a '0' (00, 01 etc)
                                                            If ($vmfolderpath.split("\")[1] -notmatch '0\d'){
                                                                $myObj.custcode = "NA"
                                                            }
                                                    }
                                                    
                                                }

                                    # Custcode for Others                                                    
                                        } else { 
                                            $myObj.custcode = $custcode.toUpper().toString()
                                        }


                                    # Filter invalid CustCodes (Not 3 characters)
                                        if ($myObj.custcode.length -ne 3 -and $myObj.custcode -ne "CCIP" ){
                                            $myObj.custcode = "NA"
                                        }

                                    # Continue
                                        $myObj.ptfsubcode       = $ptfsubcode.toUpper().toString()
                                        $myObj.VcenVmVcenName   = $entityname.split(".")[0].ToUpper()
                                        $myObj.VcenVmCluName    = $cluster.Name
                                        $myObj.VcenVmDcCode     = $location
                                        $myObj.VcenVmRpoolName  = $vm.ResourcePool

                        
                                        if (($vmDetailed.Guest.HostName -eq $null)  -or ($vmDetailed.Guest.HostName -eq "")) {
                                            $myObj.VcenVmDnsName = ""}
                                            else {
                                                $myObj.VcenVmDnsName = $vmDetailed.Guest.HostName.ToLower()
                                            }

                                
                                        if (!$vmDetailed.Guest.GuestFamily) {
							                $myObj.VcenVmOsName = ""}
							                else {$myObj.VcenVmOsName = $vmDetailed.Guest.GuestFamily}

                                    # If VcenVmOsName was not found, retry through GuestFullName field
                                        # First through field as reported by VMware Tools
                                            if ($myObj.VcenVmOsName -eq "" -and $vmDetailed.Guest.GuestFullName){
                                                if ($vmDetailed.Guest.GuestFullName.contains("Linux")){$myObj.VcenVmOsName = "linuxGuest"}
                                                if ($vmDetailed.Guest.GuestFullName.contains("Windows")){$myObj.VcenVmOsName = "windowsGuest"}
                                            } else { 
                                                # If that fails, through the chosen option during deployment
                                                    if ($myObj.VcenVmOsName -eq "" -and $vmDetailed.config.GuestFullName){
                                                        if ($vmDetailed.config.GuestFullName.contains("Linux")){$myObj.VcenVmOsName = "linuxGuest"}
                                                        if ($vmDetailed.config.GuestFullName.contains("Windows")){$myObj.VcenVmOsName = "windowsGuest"}                   
                                                    }
                                            }

                                        # Finally check whether this is an appliance
                                            if ($vmDetailed.summary.config.product.name){
                                                $myObj.VcenVmOsName = "Appliance"
                                            }
                            
								            if (!$vmDetailed.Guest.GuestFullName) {
									            $myObj.VcenVmOsVersion = $vmDetailed.config.GuestFullName 
                                            }
									        else {
                                                $myObj.VcenVmOsVersion = $vmDetailed.Guest.GuestFullName
                                            }

                                        $myObj.VcenVmNoOfVcpuAlocCount  = $vm.NumCpu
                                        $myObj.VcenVmVcpuModel          = $vm.vmhost.ProcessorType
                                        $myObj.VcenVmVcpuMaxMhz         = [math]::round($vm_Cpu_Mhz.maximum)
                                        $myObj.VcenVmVcpuReservedMhz    = $vmDetailed.ResourceConfig.CpuAllocation.Reservation
                                        $myObj.VcenVmVcpuUsedMhz        = [math]::round($vm_Cpu_Mhz.average)
                                        $myObj.VcenVmVcpuUsedPct        = [math]::round($vm_Cpu_Pct.average,2)
                                        $myObj.VcenVmVcpuUsedMaxPct     = [math]::round($vm_Cpu_Pct.maximum,2)
                                        $myObj.VcenVmVmemAlocGb         = [math]::round($vm.MemoryGB,2)
                                        $myObj.VcenVmVmemMaxGb          = [math]::round($vm_mem_KB.maximum/1024/1024,2)
                                        $myObj.VcenVmVmemReservedGb     = [math]::round($vmDetailed.ResourceConfig.MemoryAllocation.Reservation/1024,2)
                                        $myObj.VcenVmVmemUsedGb         = [math]::round($vm_mem_KB.average/1024/1024,2)
                                        $myObj.VcenVmVmemUsedPct        = [math]::round($vm_Mem_Pct.average,2)
										$myObj.VcenVmVmemUsedMaxPct     = [math]::round($vm_Mem_Pct.maximum,2)
                                        $myObj.VcenVmNtwkUsageKbps      = [math]::round($vm_Net_Kbps.average,2)
                                        $myObj.VcenVmNtwkAvgTxKbps      = [math]::round($vm_net_Tx_Kbps.average,2)
                                        $myObj.VcenVmNtwkAvgRxKbps      = [math]::round($vm_net_Rx_Kbps.average,2)

                                    # Get the Uptime Percentage based on counter
                                        $vm_Uptime_Perc            = ""
                                        $vm_OsUptime_Perc          = ""
                                    
                                        if ($vm_Uptime.count -gt 0){
                                            $vm_Uptime_Total       = $vm_Uptime.count
                                            $vm_Uptime_Up          = ($vm_Uptime | Where {$_.value -ge 20}).count
                                            $vm_Uptime_Perc        = [math]::round(($vm_Uptime_Up/$vm_Uptime_Total)*100,2)
                                        }

                                        if ($vm_OsUptime.count -gt 0){
                                            $vm_OsUptime_Total     = $vm_OsUptime.count
                                            $vm_OsUptime_Up        = ($vm_OsUptime | Where {$_.value -ge 20}).count
                                            $vm_OsUptime_Perc      = [math]::round(($vm_OsUptime_Up/$vm_OsUptime_Total)*100,2)
                                        }

                                        $myObj.VcenVmVmUptimePct   = $vm_Uptime_Perc
                                        $myObj.VcenVmOsUptimePct   = $vm_OsUptime_Perc


                                    # Get allocated Bytes (Hard Disks, Config Files and Memory File)
                                        $myObj.VcenVmStgAlocGb     = [math]::round($vm.ProvisionedSpaceGB,2)


                                    # Get Used Bytes (Space usage reported from within the guest)
                                        $myObj.VcenVmStgUsedGb     = [math]::round(($vmDetailed.guest.disk | select @{N="Used";E={$_.capacity - $_.Freespace}} | Measure-Object Used -Sum).sum/1024/1024/1024,2)


                                    # Get the Storage Usage per Storage Class (if applicable)
                                        $VcenVmStgPlatAlocBytes = @()
                                        $VcenVmStggoldAlocBytes = @()
                                        $VcenVmStgsilvAlocBytes = @()
                                        $VcenVmStgBronAlocBytes = @()
										$VcenVmStgDiamAlocBytes = @()
                                        $VcenVmStgArchAlocBytes = @()
                                        $VcenVmStgOtheAlocBytes = @()

                                        foreach ($datastore in $vmDetailed.Storage.PerDatastoreUsage){
    
                                            $datastoreName = ($datastores | where {$_.id -like "Datastore-"+$datastore.datastore.value}).name
                                            $Class = $datastoreName.split("-")[1].substring(0,3)

                                            $VcenVmStgPlatAlocBytes += $datastore.Committed + $datastore.Uncommitted | where {$Class -like "*pl*" -or $Class -like "P??"}
                                            $VcenVmStggoldAlocBytes += $datastore.Committed + $datastore.Uncommitted | where {$Class -like "*go*" -or $Class -like "G??"}
                                            $VcenVmStgsilvAlocBytes += $datastore.Committed + $datastore.Uncommitted | where {$Class -like "*si*" -or $Class -like "S??"}
                                            $VcenVmStgBronAlocBytes += $datastore.Committed + $datastore.Uncommitted | where {$Class -like "*br*" -or $Class -like "B??"}
                                            $VcenVmStgArchAlocBytes += $datastore.Committed + $datastore.Uncommitted | where {$Class -like "*ar*" -or $Class -like "A??"}
											$VcenVmStgDiamAlocBytes += $datastore.Committed + $datastore.Uncommitted | where {$Class -like "*di*" -or $Class -like "D??"}
                                                        
                                            # Any undetermined storage class will be added to the Other parameter
                                                $VcenVmStgOtheAlocBytes += $datastore.Committed + $datastore.Uncommitted | where {$Class -notlike "*pl*" -and $Class -notlike "*go*" -and $Class -notlike "*si*" -and $Class -notlike "*br*" -and $Class -notlike "*ar*"}

                                        }

                                        $myObj.VcenVmStgPlatAlocGb = [math]::round(($VcenVmStgPlatAlocBytes | Measure-Object -sum).sum/1024/1024/1024,2)
                                        $myObj.VcenVmStgGoldAlocGb = [math]::round(($VcenVmStggoldAlocBytes | Measure-Object -sum).sum/1024/1024/1024,2)
										$myObj.VcenVmStgDiamAlocGb = [math]::round(($VcenVmStgDiamAlocBytes | Measure-Object -sum).sum/1024/1024/1024,2)
                                        $myObj.VcenVmStgSilvAlocGb = [math]::round(($VcenVmStgsilvAlocBytes | Measure-Object -sum).sum/1024/1024/1024,2)
                                        $myObj.VcenVmStgBronAlocGb = [math]::round(($VcenVmStgBronAlocBytes | Measure-Object -sum).sum/1024/1024/1024,2)
                                        $myObj.VcenVmStgArchAlocGb = [math]::round(($VcenVmStgArchAlocBytes | Measure-Object -sum).sum/1024/1024/1024,2)
                                        $myObj.VcenVmStgOtheAlocGb = [math]::round(($VcenVmStgOtheAlocBytes | Measure-Object -sum).sum/1024/1024/1024,2)


                                    # Get Storage IOPS                            
                                        $myObj.VcenVmStgIopsBytes = $vm_Dsk_Io_Write.sum + $vm_Dsk_Io_Read.sum
                                            if (!$myObj.VcenVmStgIopsBytes){
                                                $myObj.VcenVmStgIopsBytes = $null
                                            }


                                        $myObj.VcenVmPowerState     = $vmDetailed.Runtime.PowerState
                                        $myObj.VcenVmPowerUsedWatts = [math]::round($vm_Power.average,2)
                                        $myObj.VcenVmToolsStatus    = $vmDetailed.Guest.ToolsStatus


                                    # Get all the NetworkAdapters
                                        $AllVmNics = $vmDetailed.guest.net | Sort DeviceConfigId | select Network

                                        # Loop through the Networkadapters, and find attached network
                                            $count = $AllVmNics.network.count
                                               
                                            if ($count -ge 1){
                                                1..$count | %{
                                                        set-variable "NIC$_" -Value $AllVmNics[$_ -1].network
                                                        if ((get-variable "NIC$_").value -eq $NULL) {
                                                            set-variable "NIC$_" -Value ""
                                                        } 
                                                    }
                                            }

                                        # Set the variables
                                            $myObj.VcenVmNtwk1  = $NIC1
                                            $myObj.VcenVmNtwk2  = $NIC2
                                            $myObj.VcenVmNtwk3  = $NIC3
                                            $myObj.VcenVmNtwk4  = $NIC4
                                            $myObj.VcenVmNtwk5  = $NIC5
                                            $myObj.VcenVmNtwk6  = $NIC6
                                            $myObj.VcenVmNtwk7  = $NIC7
                                            $myObj.VcenVmNtwk8  = $NIC8
                                            $myObj.VcenVmNtwk9  = $NIC9
                                            $myObj.VcenVmNtwk10 = $NIC10

                                                                
                                    if ((($ProtectedVms | select moref).moref) -like $vmDetailed.MoRef.ToString()){
                                        $myObj.VcenVmDrProtectStatus = 1
                                    } else {
                                        $myObj.VcenVmDrProtectStatus = 0
                                    }

                                    $PerVm_Overview += $myObj

                            }
                        }

#----------------------------  E N D  V M  R E P O R T I N G  -------------------------------------

#----------------------------  S T A R T  D A T A S T O R E  R E P O R T I N G  -------------------

                            if ($Execution -eq "Hourly" -or $Execution -eq "Datastore"){
                                Write-CustomOut "Start the per Datastore reporting ..."
                            
                                # Get Datatore Stats from VM Stats Object
                                    Write-CustomOut "Collecting Datastore statistics ..."
                                    filter isDISK { if ($_.MetricID -like 'disk.*') { $_ } }
                                    $dss_stats = $vms_stats.group | isDISK | Group-Object -Property Instance


                                Foreach ($datastore in $datastores){

                                    # Get Datatore Detailed Object
                                        $datastoreDetailed = $datastore.extensiondata 

                                    # Collect the Datastore Specific Stats
                                        $dsStats   = ($dss_stats | Where {$_.name -eq $datastoreDetailed.info.Vmfs.Extent.diskname}).group  | group-object -Property MetricID

                                        $ds_write_iops = ($dsStats | Where {$_.name -eq "disk.numberwrite.summation"} ).group | Measure-Object -Property value -Sum
                                        $ds_read_iops  = ($dsStats | Where {$_.name -eq "disk.numberread.summation"} ).group  | Measure-Object -Property value -Sum
                                        
                                        if (!$ds_write_iops){ $ds_write_iops = 0 }
                                        if (!$ds_read_iops ){ $ds_read_iops  = 0 }

                                    # Start collecting the data
                                        $myObj = "" | Select date,time,countrycode,custcode,`
                                                            ptfsubcode,VcenDstName,VcenDstVcenName,`
                                                            VcenDstClusterName,VcenDstDcCode,VcenDstType,`
                                                            VcenDstNoOfHosts,VcenDstNoOfVms,VcenDstTotalGb,`
                                                            VcenDstProvGb,VcenDstUsedGb,VcenDstFreeGb,`
                                                            VcenDstAvgReadIops,VcenDstAvgWriteIops,VcenDstAvgIops
                                        $myObj.date                = $date
                                        $myObj.time                = $time
                                        $myObj.countrycode         = $countrycode
                                        if ($ptfcode -eq "vpc"){
                                            $myObj.custcode          = $datastore.name.split("-")[2].ToUpper()
                                        } else { 
                                            $myObj.custcode          = $custcode.toUpper().toString()
                                        } 

                                        $myObj.ptfsubcode          = $ptfsubcode.toUpper().toString()
                                        $myObj.VcenDstName         = $datastore.name
                                        $myObj.VcenDstVcenName     = $entityname.split(".")[0].ToUpper()
                                        $myObj.VcenDstClusterName  = $cluster.Name
                                        $myObj.VcenDstDcCode       = $location 
                                        $myObj.VcenDstType         = $datastore.type
                                        $myObj.VcenDstNoOfHosts    = $datastoreDetailed.host.count
                                        $myObj.VcenDstNoOfVms      = $datastoreDetailed.vm.count
                                        $myObj.VcenDstTotalGb      = [math]::Round(($datastore.CapacityGB),2)
                                        $myObj.VcenDstFreeGb       = [math]::Round(($datastore.FreeSpaceGB),2)
                                        $myObj.VcenDstUsedGb       = [math]::Round(($datastore.CapacityGB - $datastore.FreeSpaceGB),2)
                                        $myObj.VcenDstProvGb       = [math]::Round((($datastoreDetailed.summary.Capacity - $datastoreDetailed.summary.FreeSpace + $datastoreDetailed.summary.Uncommitted)/1024/1024/1024),2)
                                        $myObj.VcenDstAvgReadIops  = [math]::Round(($ds_read_iops.sum/$ds_read_iops.count),2)
                                        $myObj.VcenDstAvgWriteIops = [math]::Round(($ds_write_iops.sum/$ds_write_iops.count),2)
                                        $myObj.VcenDstAvgIops      = $myObj.VcenDstAvgReadIops + $myObj.VcenDstAvgWriteIops

                                        $PerDatastore_Overview += $myObj
                                }

                            }

#----------------------------  E N D  D A T A S T O R E  R E P O R T I N G  -----------------------

                }

#----------------------------  E N D  C L U S T E R S  R E P O R T I N G  -------------------------



#----------------------------  S T A R T  O U T P U T  D A T A  -----------------------------------

                $PerVm_Overview                = $PerVm_Overview         | Sort VcenVmDispName
                $PerCluster_Overview           = $PerCluster_Overview    | Sort VcenCluName
                $PerDatastore_Overview         = $PerDatastore_Overview  | Sort VcenDstName
                $PerHypervisor_Overview        = $PerHypervisor_Overview | Sort VcenHypName


            # Check whether Output was generated.
                if (!$PerVm_Overview){ 
                    Write-Event Error "No per VM output was generated" 
                    Write-CustomOut   "No per VM output was generated"                  
                } 

                if (!$PerCluster_Overview){
                    Write-Event Error "No per Cluster output was generated"
                    Write-CustomOut   "No per Cluster output was generated"
                } 
                
                
                if (!$PerDatastore_Overview){
                    Write-Event Error "No per Datastore output was generated"
                    Write-CustomOut   "No per Datastore output was generated"                  
                } 


                if (!$PerHypervisor_Overview){
                    Write-Event Error "No per Hypervisor output was generated"
                    Write-CustomOut   "No per Hypervisor output was generated"
                } 


            # Define Output Files
                Write-CustomOut "Generating Output"
                $date = [datetime]::UtcNow.ToString("yyyyMMdd")
                $time = [datetime]::UtcNow.ToString("HHmmss")
 
                $PerVm_Overview_Output         = $CSI_Output_Folder + $ptfcode + "_" + $ptfsubcode + "_" + $custcode + "_" + $countrycode + "_" + $location + "_" + $entitytype + "_" + "vm" + "_" + $entityname + "_" + $date + "_" + $time + ".csv"
                $PerCluster_Overview_Output    = $CSI_Output_Folder + $ptfcode + "_" + $ptfsubcode + "_" + $custcode + "_" + $countrycode + "_" + $location + "_" + $entitytype + "_" + "clu" + "_" + $entityname + "_" + $date + "_" + $time + ".csv"
                $PerDatastore_Overview_Output  = $CSI_Output_Folder + $ptfcode + "_" + $ptfsubcode + "_" + $custcode + "_" + $countrycode + "_" + $location + "_" + $entitytype + "_" + "dst" + "_" + $entityname + "_" + $date + "_" + $time + ".csv"
                $PerHypervisor_Overview_Output = $CSI_Output_Folder + $ptfcode + "_" + $ptfsubcode + "_" + $custcode + "_" + $countrycode + "_" + $location + "_" + $entitytype + "_" + "hyp" + "_" + $entityname + "_" + $date + "_" + $time + ".csv"

            # Dump initial Data to CSI Raw Input folders
                Write-CustomOut "Started creating the output files"
                if ( $PerVm_Overview           ){ $PerVm_Overview         | Convertto-Csv -NoTypeInformation | % {$_ -replace '""',''} | Out-File -Encoding utf8 $PerVm_Overview_Output         }
                if ( $PerCluster_Overview      ){ $PerCluster_Overview    | Convertto-Csv -NoTypeInformation | % {$_ -replace '""',''} | Out-File -Encoding utf8 $PerCluster_Overview_Output    }
                if ( $PerDatastore_Overview    ){ $PerDatastore_Overview  | Convertto-Csv -NoTypeInformation | % {$_ -replace '""',''} | Out-File -Encoding utf8 $PerDatastore_Overview_Output  }
                if ( $PerHypervisor_Overview   ){ $PerHypervisor_Overview | Convertto-Csv -NoTypeInformation | % {$_ -replace '""',''} | Out-File -Encoding utf8 $PerHypervisor_Overview_Output }


#----------------------------  E N D  O U T P U T  D A T A  ---------------------------------------

        }
 
#----------------------------  E N D  v C E N T E R  D A T A  -------------------------------------



#----------------------------  S T A R T  F I N I S H  S C R I P T  -------------------------------

    # Disconnect from any vCenter, if still connected
        If ($global:DefaultVIServers)  {
    	    Disconnect-VIServer -Server $global:DefaultVIServers -Force -Confirm:$false
        }

        If ($global:DefaultSRMServers) {
    	    Disconnect-SRMServer -Server $global:DefaultSRMServers -Force -Confirm:$false
        }

    # Get End time
        $Endtime = Get-date

    # Get Run time
        $Runtime      = $Endtime - $Starttime
        $Runtime      = "Total runtime for this script was "+$Runtime.Hours+" Hours and "+$Runtime.minutes+" Minutes"
        $Runtime      = $Runtime.tostring()
        Write-CustomOut "$Runtime"
        Write-Host "$entityname"
        Write-Host "$runtime"

    # Log ending of script
        Write-Event Information "END : $entityname : Ended the vCenter script..."

#----------------------------  E N D  F I N I S H  S C R I P T  -----------------------------------



