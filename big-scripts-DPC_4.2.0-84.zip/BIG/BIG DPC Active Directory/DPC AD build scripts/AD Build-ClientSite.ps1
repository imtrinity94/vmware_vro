﻿#DPC AD Build Script - Client Site build
#Version: 0.3
#Date: 16-05-2017
#Author: Piotr Lewandowski
#Changes:
#1. Added DNS reverse lookup zones creation
#2. fixed issue with Service Accounts DN

#$InstalledRoles = Get-WindowsFeature  |  Where-Object Installed
$ascii=$NULL;For ($a=33;$a –le 126;$a++) {$ascii+=,[char][byte]$a }


 ##########
 # Chceck if you run as admin
 ##########

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"
    Break
}

Function GET-Temppassword() {

###
# Complex password generator
# http://blogs.technet.com/b/heyscriptingguy/archive/2013/06/03/generating-a-new-password-with-windows-powershell.aspx
###



Param(

[int]$length=10,

[string[]]$sourcedata

)

 

For ($loop=1; $loop –le $length; $loop++) {

            $TempPassword+=($sourcedata | GET-RANDOM)

            }

return $TempPassword

}

<# ##########
 # Check if AD DS is already installed
 ##########

if ($InstalledRoles.Name -like "AD-Domain-Services") {
    Write-Host "Powershell installed";
  }
 Else { Write-Host "Powershell not installed" }
 #>
 <#
 function ChangeSrvName {

 ###########
 # 1. Change servername
 ##########


 $dcName = $data.DC2Name
 Rename-Computer $dcName -Restart

 }
 #>
 FUNCTION AddToDomain {

    Add-Computer -DomainName $data.DomainName -Credential (get-credential -Message "Enter domain credentials") -Restart:$true
 }
 <#
 function SecEdit {

  ###########
 # 2. Update Security monitor (BIG 3.4), Require manual job
 ##########

# Copy sceregvl.inf into current user desktop before change

 Copy-Item $env:SystemRoot\inf\sceregvl.inf $env:SystemRoot\sceregvl-old.inf

 Write-Host "File sceregvl.inf has been backed up in the same folder with -old suffix. Proceed to .inf file modification which is described in AD BIG section 3.4 Updating the Security Editor" -BackgroundColor DarkRed 

 }
#>
 Function GeneralOptions {

Write-Host "Deselect Advanced TCP/IP settings\WINS  Enable LMHosts lookup" -BackgroundColor DarkYellow
$nic = [wmiclass]'Win32_NetworkAdapterConfiguration'
$nic.enablewins($false,$false) > $null

Start-Sleep -s 2

Write-Host "Enable ipv6 protocol on network adapters" -BackgroundColor DarkYellow
Set-NetAdapterBinding -Name * -ComponentID  ms_tcpip6 -Enabled:$true 


Start-Sleep -s 2

Write-Host "Enable remote management of this server from other computers" -BackgroundColor DarkYellow
Configure-SMRemoting.exe -enable


Start-Sleep -s 2

Write-Host "Change CD rom drive letter to R: " -BackgroundColor DarkYellow
$cdrom = Get-WmiObject win32_cdromdrive


Get-WmiObject Win32_Volume -filter "DriveLetter='$($cdrom.Drive)'" | Set-WmiInstance -Arguments @{DriveLetter="R:"} > $null
$cdrom = Get-WmiObject win32_cdromdrive

Write-Host "Drive letter is:" $cdrom.Drive
' '
' '

}

 function FormatDisk {

if (get-disk | Where partitionstyle -eq 'raw') {

Get-Disk | Where IsSystem -eq $false | Initialize-Disk -PartitionStyle MBR -PassThru 
Start-Sleep -s 2

Stop-Service shellhwdetection
Get-Disk | Where IsSystem -eq $false | select -first 1 | New-Partition -DriveLetter 'D' -UseMaximumSize 
Start-Sleep -s 2
Format-Volume -DriveLetter 'D' -FileSystem NTFS -NewFileSystemLabel "DATA" -Confirm:$false
Start-Service shellhwdetection

}
else {

# Trick to supress Format partition window
Stop-Service shellhwdetection
Get-Disk | Where IsSystem -eq $false | select -first 1 | New-Partition -DriveLetter 'D' -UseMaximumSize
Start-Sleep -s 2
Format-Volume -DriveLetter 'D' -FileSystem NTFS -NewFileSystemLabel "DATA" -Confirm:$false
Start-Service shellhwdetection

    }
}

 function InstallADDSRole {
  
 ###########
 # Function for installing AD services role
 ##########

 
 Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools

 }

 
 function InstallADDomainController {

 $sitename = $data.Sitename
 $DSRMpass = GET-Temppassword -length 16 -sourcedata $ascii
 Write-Output "DSRM password for $($env:COMPUTERNAME) is: $DSRMpass" >> .\DSRM_pass.txt
 
 $DomainName = $data.DomainName
 #$FirstController = $($data.DC3Name)+"."+$($data.DomainName)
 $AdDomainShort = (Get-ADDomain).Name
 # -ReplicationSourceDC $FirstController `

 Install-ADDSDomainController `
        -NoGlobalCatalog:$false `
        -CreateDnsDelegation:$false `
        -CriticalReplicationOnly:$false `
        -DatabasePath "D:\NTDS" `
        -DomainName $DomainName `
        -InstallDns:$true -LogPath "D:\Logs" `
        -NoRebootOnCompletion:$false `
        -SiteName $SiteName `
        -SysvolPath "D:\SYSVOL" `
        -Force:$true `
        -Credential (get-credential -UserName "$($AdDomainShort)\Administrator" -Message "Enter password for $($AdDomainShort)\Administrator" ) `
        -Confirm:$false `
        -SafeModeAdministratorPassword (ConvertTo-SecureString $DSRMpass -AsPlainText -Force) `

      }


function ConfigureDNS {

$dnssrv = Get-DnsServer

#Remove root hints

Get-DnsServerRootHint | Remove-DnsServerRootHint -Force
Write-Host "DNS root hints have been removed" -Foregroundcolor DarkYellow;

#Remove DNS forwarders

Get-DnsServerForwarder | Remove-DnsServerForwarder -Force
Write-Host "DNS forwarders have been removed" -Foregroundcolor DarkYellow;

#Setting Listening IP and Name check flag

$DNSobj = Get-DnsServerSetting -all
$DNSobj.ListeningIPAddress = $dnsobj.ListeningIPAddress | ?{$_ -match '(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'}
$DNSobj.NameCheckFlag = 0
Set-DnsServerSetting -inputobject $DNSobj

}



function ImportADGroups {

####
# First export AD groups using:
# Get-ADGroup -Filter * -Properties Description | export-csv
# http://www.sysadminlab.net/windows/migrate-or-copy-ou-structure-between-domains-using-powershell
# To Do : replace domain name
#####
$DomainDN = (get-addomain).distinguishedname

$RoleGroups = Import-Csv ".\data\$platform\RoleGroups.csv"

$RoleGroups | foreach  {

$GroupPath = "OU=RoleGroups,OU=Groups,OU=DPC" + "," + $DomainDN
$GroupName = $_.name -replace "<LocationCode>",$LocationCode 
$description = $_.description -replace "<Location>",$Location

    New-ADGroup -Name $GroupName `
                -Path $GroupPath `
                -GroupScope "Global" `
                -GroupCategory "Security" `
                -Description $Description
    
    } 

$ResourceGroups = Import-Csv ".\data\$platform\ResourceGroups.csv"

$ResourceGroups | foreach  {

$GroupName = $_.name -replace "<LocationCode>",$LocationCode
$description = $_.description -replace "<Location>",$Location
$GroupPath = "OU=ResourceGroups,OU=Groups,OU=DPC" + "," + $DomainDN

    New-ADGroup -Name $GroupName `
                -Path $GroupPath `
                -GroupScope "DomainLocal" `
                -GroupCategory "Security" `
                -Description $Description
    
    } 

Write-Host "

Security Groups have been created

" -Foregroundcolor DarkYellow;

}



function ImportServiceAccounts {

####
# First Export AD users:
# Get-ADUser -Filter 'Name -like "s-*"'
####
$ADdomain = get-addomain
$adusers = Import-Csv ".\data\$platform\ServiceAccounts.csv"

$adusers | foreach  {

$password = GET-Temppassword -length 16 -sourcedata $ascii
$securePass = $password | ConvertTo-SecureString -AsPlainText -Force

$username = $_.SamAccountName -replace "<LocationCode>",$LocationCode
$description = $_.description -replace "<Location>",$location
$AccPath = "OU=$platform,OU=ServiceAccounts,OU=DPC" + "," + $ADDomain.distinguishedname
Write-Output "Account name: " $username "Password is: " $password >> .\srv_acc_Pass.csv

    New-ADUser -Name $username `
               -Path $AccPath `
               -SamAccountName $username `
               -GivenName $username `
               -UserPrincipalName "$username@$($addomain.DNSroot)" `
               -PasswordNeverExpires:$true `
               -Description $Description `
               -Enabled:$true `
               -AccountPassword $securePass

    } 

Write-Host "

Service accounts have been created

" -Foregroundcolor DarkYellow;

}

function ADMemberships {

$members = Import-Csv ".\data\$Platform\ADmembership.csv"

$members | ForEach-Object {
    
    $group = ($_.Group).replace("<LocationCode>",$LocationCode)
    $member = ($_.member).replace("<LocationCode>",$LocationCode)
    Add-ADGroupMember -Identity $group -Members $Member
    }

Write-Host "

Group membership has been configured

" -Foregroundcolor DarkYellow;

}

Function CreateReverseLookup {

#Create reverse lookup DNS zone(s)

$reverseDNS = Import-csv .\reverseDNS-ClientSite.csv

foreach ($zone in $reverseDNS) {

Add-DnsServerPrimaryZone -NetworkID "$($zone.NetworkID)" -ReplicationScope "Forest" 

}


# Write result 
Write-host "Zones that have been created:" -Foregroundcolor DarkYellow
Get-DnsServerZone | Where-Object { ($_.IsReverseLookupZone -like 'True') -and ($_.IsAutoCreated -like 'false') } | Format-Table


}


function Menu {

#Interactive menu WiP

Write-Host "
AD Build script - Client Site" -ForegroundColor Yellow

Write-warning "
Make sure that input-ClientSite.csv file is properly filled in before continuing"

do {
  [int]$userMenuChoice = 0
  while ( $userMenuChoice -lt 1 -or $userMenuChoice -gt 10) {
    Write-Host "1. Configure general Options"
    Write-Host "2. Disk configuration"
    Write-Host "3. Install AD DS Role"
    Write-Host "4. Add to domain (REQUIRE REBOOT)"
    Write-Host "5. Install Domain Controller"
    Write-Host "6. Configure DNS"
	Write-Host "7. Create Site-specific service accounts"
	Write-Host "8. Create Site-specific AD group structure"
    Write-Host "9. Configure AD group membership"
    write-host "10. Create reverse lookup zones" 
    Write-Host "11. Quit and Exit"

    [int]$userMenuChoice = Read-Host "Please choose an option"

    switch ($userMenuChoice) {
      1{GeneralOptions}
      2{FormatDisk}
      3{InstallADDSRole}
      4{AddToDomain}
      5{InstallADDomainController}
      6{ConfigureDNS}
      7{ImportServiceAccounts}
      8{ImportADGroups}
      9{ADMemberships}
      10{CreateReverseLookup}
      11{Break switch}
      default {Write-Host "Nothing selected & wrong choice" -foregroundcolor "yellow" }
    }
  }
} while ( $userMenuChoice -ne 99 )

}



$data = import-csv ".\input-clientsite.csv"

$platform = $data.platform
$LocationCode = $data.LocationCode
$location = $data.Location


Menu