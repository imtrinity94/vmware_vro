﻿<#
DPC AD Build script #1
version: 0.1
date: 2016-09-26
Author: Piotr Lewandowski

#>
#$InstalledRoles = Get-WindowsFeature  |  Where-Object Installed
$ascii=$NULL;For ($a=33;$a –le 126;$a++) {$ascii+=,[char][byte]$a }
#$StrOUTree = C:\Users\Administrator\Desktop\OUTree.csv
#$GlobalDomainName


$data = Import-Csv .\input.csv

$CustomerCode = $data.CustomerCode
$LocationCode = $data.LocationCode
$CountryCode = $data.CountryCode


 ##########
 # Chceck if you run as admin
 ##########

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"
    Break
}

Function GET-Temppassword() {

###
# Complex password generator
# http://blogs.technet.com/b/heyscriptingguy/archive/2013/06/03/generating-a-new-password-with-windows-powershell.aspx
###



Param(

[int]$length=10,

[string[]]$sourcedata

)

 

For ($loop=1; $loop –le $length; $loop++) {

            $TempPassword+=($sourcedata | GET-RANDOM)

            }

return $TempPassword

}

<# ##########
 # Check if AD DS is already installed
 ##########

if ($InstalledRoles.Name -like "AD-Domain-Services") {
    Write-Host "Powershell installed";
  }
 Else { Write-Host "Powershell not installed" }
 #>


 Function GeneralOptions {

Write-Host "Deselect Advanced TCP/IP settings\WINS  Enable LMHosts lookup" -Foregroundcolor DarkYellow
$nic = [wmiclass]'Win32_NetworkAdapterConfiguration'
$nic.enablewins($false,$false) > $null

Start-Sleep -s 2

Write-Host "Enable ipv6 protocol on network adapters" -Foregroundcolor DarkYellow
Set-NetAdapterBinding -Name * -ComponentID  ms_tcpip6 -Enabled:$true 


Start-Sleep -s 2

Write-Host "Enable remote management of this server from other computers" -Foregroundcolor DarkYellow
Configure-SMRemoting.exe -enable


Start-Sleep -s 2

Write-Host "Change CD rom drive letter to R: " -Foregroundcolor DarkYellow
$cdrom = Get-WmiObject win32_cdromdrive


Get-WmiObject Win32_Volume -filter "DriveLetter='$($cdrom.Drive)'" | Set-WmiInstance -Arguments @{DriveLetter="R:"} > $null
$cdrom = Get-WmiObject win32_cdromdrive

Write-Host "Drive letter is:" $cdrom.Drive
' '
' '

}

 function FormatDisk {

if (get-disk | Where partitionstyle -eq 'raw') {

Get-Disk | Where IsSystem -eq $false | Initialize-Disk -PartitionStyle MBR -PassThru 
Start-Sleep -s 2

Stop-Service shellhwdetection
Get-Disk | Where IsSystem -eq $false | select -first 1 | New-Partition -DriveLetter 'D' -UseMaximumSize
Start-Sleep -s 2
Format-Volume -DriveLetter 'D' -FileSystem NTFS -NewFileSystemLabel "DATA" -Confirm:$false
Start-Service shellhwdetection

}
else {

# Trick to supress Format partition window
Stop-Service shellhwdetection
Get-Disk | Where IsSystem -eq $false | select -first 1 | New-Partition -DriveLetter 'D' -UseMaximumSize 
Start-Sleep -s 2
Format-Volume -DriveLetter 'D' -FileSystem NTFS -NewFileSystemLabel "DATA" -Confirm:$false
Start-Service shellhwdetection

    }
}

 function InstallADDSRole {
  
 ###########
 # Function for installing AD services role
 ##########

 
 Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools

 }

 function InstallADForest {

$DSRMpass = GET-Temppassword -length 16 -sourcedata $ascii
Write-Output "DSRM password for $($env:COMPUTERNAME) is: $DSRMpass" >> .\DSRM_pass.txt


 $DomainName = $data.DomainName
 

 Install-ADDSForest `
        -DomainName "$DomainName" `
        -DatabasePath "D:\NTDS" `
        -SysvolPath "D:\SYSVOL" `
        -LogPath "D:\Logs" `
        -ForestMode Win2012R2 `
        -DomainMode Win2012R2 `
        -InstallDns:$true `
        -Force:$true `
        -CreateDnsDelegation:$false `
        -SafeModeAdministratorPassword (ConvertTo-SecureString $DSRMpass -AsPlainText -Force)
  }

function CreateACCPSites {

$ACCPMGTSiteName = $data.ACCPMGTSiteName
$PLATMGTSiteName = $data.PLATMGTSiteName
<#
$configNCDN = (Get-ADRootDSE).ConfigurationNamingContext
$siteContainerDN = ("CN=Sites," + $configNCDN)
$SiteName = Get-ADObject -SearchBase $siteContainerDN -filter { objectClass -eq "site" } -properties "siteObjectBL", "location", "description", "Distinguishedname"
#>

#Rename the Default-First-Site

Get-ADReplicationsite -filter * | Rename-ADObject -NewName $ACCPMGTSiteName
Get-ADReplicationsite $ACCPMGTSiteName | Set-ADReplicationSite -description "ACCP Management"


#Create Central site

New-ADReplicationSite -Description "Platform Management (Central Site)" -Name $PLATMGTSiteName

#Display sites
Write-host "The following AD sites have been created:" -Foregroundcolor Yellow
Get-ADReplicationSite -filter * | select name,description

#Edit default site link

}
 
 <#
 function InstallADDomainController {

 #$cred = Get-Credential
 #$cred1 = $cred.Password

 $DSRMpass = GET-Temppassword -length 16 -sourcedata $ascii
 Write-Output $($("DSRM password for "),$($env:COMPUTERNAME),$(" is: "),$($DSRMpass)) >> .\DSRM_2.txt
 
 $DomainName = $data.DomainName
 $FirstController = $Data.DC3Name
 $SiteName = $data.ACCPMGTSiteName

 Install-ADDSDomainController -NoGlobalCatalog:$false -CreateDnsDelegation:$false -CriticalReplicationOnly:$false -DatabasePath "D:\NTDS" -DomainName $DomainName -InstallDns:$true -LogPath "D:\Logs" -NoRebootOnCompletion:$true -ReplicationSourceDC $FirstController -SiteName $SiteName -SysvolPath "D:\SYSVOL" -Force:$true -Credential (get-credential) -Confirm:$false -SafeModeAdministratorPassword (ConvertTo-SecureString $DSRMpass -AsPlainText -Force)
      }
#>


Function SetAccidentalDeletion {

###
# Prevent from accidental deletion of AD objects
###

Get-ADOrganizationalUnit -filter * | Set-ADObject -ProtectedFromAccidentalDeletion:$true

}

function ImportOU {

####
# First export OU using:
# Get-ADOrganizationalUnit -Filter * | export-csv
# http://www.sysadminlab.net/windows/migrate-or-copy-ou-structure-between-domains-using-powershell
# To Do : replace domain name
#####

$DomainDN = (get-addomain).distinguishedname
$oulist = import-csv .\data\OU_structure.csv
$oulist | foreach {

$outemp = $_.Distinguishedname
$ousplit = $outemp -split ',',2 -replace "DC=DPCMGT,DC=LOCAL$", $DomainDN

$newOU = New-ADOrganizationalUnit -Name $_.Name -Path $ousplit[1]

    }
Get-ADOrganizationalUnit -Filter * -properties protectedfromaccidentaldeletion | ?{$_.ProtectedFromAccidentalDeletion -eq $false} | set-ADobject -ProtectedFromAccidentalDeletion:$true

New-ADObject -name "SNOWUsers" -path "OU=Users,OU=DPC,$DomainDN" -type container -protectedfromaccidentaldeletion:$true

#Redirect Default Computers Container

redircmp "OU=Temp,OU=Servers,OU=DPC,$domainDN"

Write-Host "

OU structure has been created

" -Foregroundcolor Yellow;

}

function ImportADGroups {

####
# First export AD groups using:
# Get-ADGroup -Filter * -Properties Description | export-csv
# http://www.sysadminlab.net/windows/migrate-or-copy-ou-structure-between-domains-using-powershell
# To Do : replace domain name
#####
$DomainDN = (get-addomain).distinguishedname

$RoleGroups = Import-Csv .\data\RoleGroups.csv

$RoleGroups | foreach  {

$GroupPath = "OU=RoleGroups,OU=Groups,OU=DPC" + "," + $DomainDN

    New-ADGroup -Name $_.name `
                -Path $GroupPath `
                -GroupScope "Global" `
                -GroupCategory "Security" `
                -Description $_.Description
    
    } 

$ResourceGroups = Import-Csv .\data\ResourceGroups.csv

$ResourceGroups | foreach  {

$GroupPath = "OU=ResourceGroups,OU=Groups,OU=DPC" + "," + $DomainDN

    New-ADGroup -Name $_.Name `
                -Path $GroupPath `
                -GroupScope $_.GroupScope `
                -GroupCategory "Security" `
                -Description $_.Description
    
    } 

Write-Host "

Security Groups have been created

" -Foregroundcolor Yellow;

}

function ImportServiceAccounts {

####
# First Export AD users:
# Get-ADUser -Filter 'Name -like "s-*"'
####

$Domain = get-addomain

$adusers = Import-Csv .\data\ServiceAccounts.csv

$adusers | foreach  {

$password = GET-Temppassword -length 16 -sourcedata $ascii
Write-Output "Account name: " $_.Name "Password is: " $password >> .\srv_acc_Pass.csv
$securePass = $password | ConvertTo-SecureString -AsPlainText -Force

$AccPath = "OU=ACCP,OU=ServiceAccounts,OU=DPC" + "," + $Domain.distinguishedname

$username = $_.SamAccountName
    
    New-ADUser -Name $username `
               -Path $AccPath `
               -SamAccountName $username `
               -GivenName $username `
               -UserPrincipalName "$username@$($domain.DNSroot)" `
               -PasswordNeverExpires:$true `
               -Description $_.Description `
               -Enabled:$true `
               -AccountPassword $securePass

    } 

Write-Host "

Service accounts have been created

" -Foregroundcolor Yellow;

}

<#
function ImportADUsers {

$adusers = Import-Csv .\data\AD_users.csv

$adusers | foreach  {

$password = GET-Temppassword -length 16 -sourcedata $ascii
Write-Output "Account name: " $_.Name "Password is: " $password >> .\AD_Users_cred.csv
$securePass = $password | ConvertTo-SecureString -AsPlainText -Force

$ustemp = $adusers.Distinguishedname
$ussplit = $ustemp -split ',',2 -replace "DC=DDCDEV,DC=LOCAL$", $data.DomainDN
$username = $_.SamAccountName
    
    New-ADUser -Name $username `
               -Path $ussplit[1] `
               -SamAccountName $username`
               -GivenName $_.name `
               -UserPrincipalName "$username@$($data.DomainName)" `
               -PasswordNeverExpires:$true `
               -Description $_.Description `
               -Enabled:$true `
               -AccountPassword $securePass

    } 

}
#>

function ADMemberships {

$members = Import-Csv .\data\ADmembership.csv

$members | ForEach-Object {

    Add-ADGroupMember -Identity $_.Group -Members $_.Member

    }

Write-Host "

Group membership has been configured

" -Foregroundcolor Yellow;

}

function ConfigureDNS {

Import-Module ActiveDirectory
$dnssrv = Get-DnsServer

Set-DnsServerRecursion -Enable:$true;
Write-Host "DNS recursion has been configured" -Foregroundcolor DarkYellow;
Start-Sleep 5;
#Set-DnsServerScavenging -ApplyOnAllZones -ScavengingState $True -RefreshInterval 03:00:00:00 -NoRefreshInterval  02:00:00:00;
Set-DnsServerScavenging -ApplyOnAllZones -ScavengingState $True -RefreshInterval 03:00:00:00 -NoRefreshInterval  02:00:00:00 -ScavengingInterval 07:00:00:00;
Write-Host "DNS scavenging has been configured" -Foregroundcolor DarkYellow;
Start-Sleep 5;

#Remove root hints

Get-DnsServerRootHint | Remove-DnsServerRootHint -Force
Write-Host "DNS root hints have been removed" -Foregroundcolor DarkYellow;

#Remove DNS forwarders

Get-DnsServerForwarder | ?{$_.ipaddress} | Remove-DnsServerForwarder -Force
Write-Host "DNS forwarders have been removed" -Foregroundcolor DarkYellow;

#Change DNS Zone replication scope to Forest

Set-DnsServerPrimaryZone -Name $data.DomainName -ReplicationScope forest;


# Configure SOA record


$SOATTL = "3600" # 1 Day
$RefreshInterval = "3600" # 6 Hours
$RetryDelay = "3600" # 15 Minutes
$ExpireLimit = "604800" # 2 Weeks
$MinimumTTL = "3600" # 1 Day


Get-WMIObject -Namespace "root\MicrosoftDNS" -Class "MicrosoftDNS_SOAType" `
  -ComputerName . -Filter "ContainerName='$($data.DomainName)'" | %{
  # Modifying the SOA Record values
  $_.Modify($SOATTL, $_.SerialNumber, $_.PrimaryServer, $_.ResponsibleParty, `
    $RefreshInterval, $RetryDelay, $ExpireLimit, $MinimumTTL)

Write-Host "SOA records have been modified" -Foregroundcolor DarkYellow;

}


#Create reverse lookup DNS zone(s)

$reverseDNS = Import-csv .\reverseDNS.csv

foreach ($zone in $reverseDNS) {

Add-DnsServerPrimaryZone -NetworkID "$($zone.NetworkID)" -ReplicationScope "Forest" 

}


# Write result 
Write-host "Zones that have been created:" -Foregroundcolor DarkYellow
Get-DnsServerZone | Where-Object { ($_.IsReverseLookupZone -like 'True') -and ($_.IsAutoCreated -like 'false') } | Format-Table



#Setting Listening IP

$DNSobj = Get-DnsServerSetting -all
$DNSobj.ListeningIPAddress = $dnsobj.ListeningIPAddress | ?{$_ -match '(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'}
$DNSobj.NameCheckFlag = 0
Set-DnsServerSetting -inputobject $DNSobj
}
<#
function ConfigureNTP {

$gateway = get-wmiobject win32_networkadapterconfiguration | ? {$_.ipaddress -match '(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'} | select  -expand defaultipgateway

Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\ -Name Type -Value NTP
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config\ -Name AnnounceFlags -Value 5
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer -Name Enabled -Value 1
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient -Name SpecialPollInterval -Value 300
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config -Name MaxPosPhaseCorrection -Value 1800
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config -Name MaxNegPhaseCorrection -Value 1800
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\ -Name NtpServer -Value "$($data.NTPServer),0x1";

#Check keys

Write-Host "Settings should be confgiured as:";
$key1 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\ -Name Type;
$key2 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config\ -Name AnnounceFlags;
$key3 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer -Name Enabled;
$key4 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient -Name SpecialPollInterval;
$key5 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config -Name MaxPosPhaseCorrection;
$key6 = Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\ -Name NtpServer;
$key7 = Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config -Name MaxNegPhaseCorrection;

Write-Host "Required:" -Foregroundcolor DarkYellow
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\Type 	                             NTP";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\AnnounceFlags	                         5";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer\Enabled 	             1";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\NtpServer                         $($data.NTPServer),0x1";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient\SpecialPollInterval   300 Decimal";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\MaxPosPhaseCorrection                  1800 Decimal";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\MaxNegPhaseCorrection                  1800 Decimal";
' '
Write-Host "Configured:" -Foregroundcolor DarkRed;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\Type 	                            "$key1.Type
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\AnnounceFlags	                        "$key2.AnnounceFlags;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer\Enabled 	            "$key3.Enabled;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\NtpServer                         "$key6.NtpServer;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient\SpecialPollInterval  "$key4.SpecialPollInterval;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\MaxPosPhaseCorrection                 "$key5.MaxPosPhaseCorrection;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\MaxNegPhaseCorrection                 "$key7.MaxNegPhaseCorrection;

get-service w32time | Restart-Service
Start-Sleep 5;
}
#>


function CreateGPO {

$addomain = Get-ADDomain
#$path = '.\Domain Basic v0002'
<#
# Creates new GPOs
New-GPO -Name "$($addomain.Name)-AD-2012R2DomainBasic-v0001"
New-GPO -Name "$($addomain.Name)-AD-2012R2DomControllerBasic-v0001"
New-GPO -Name "$($addomain.Name)-AD-2012R2MemberServerBasic-v0001"
Write-host "GP has been created" -Foregroundcolor Yellow
Start-Sleep 3
#>

#Import settings to newly created GPOs

$location = Get-Item -Path .\data\GPOBackup
$locationFullname = $location.FullName

Import-GPO -BackupId 79A2B802-6C86-41E9-8600-BCD6CE978C9C -Path "$locationFullname\DomainBasic-v0005" -TargetName "$CustomerCode-AD-2012R2DomainBasic-v0005" -createifneeded
Import-GPO -BackupId CBE45084-EFBB-40BD-AB8E-8FBD35E55C24 -Path "$locationFullname\DomControllerBasic-v0006" -TargetName "$CustomerCode-AD-2012R2DomControllerBasic-v0006" -createifneeded -migrationtable "$locationfullname\ACCPMigrationTable.migtable"
Import-GPO -BackupId 31CA8CCB-CF15-49FE-98AA-6191EBDC5DAC -Path "$locationFullname\MemberServerBasic-v0006" -TargetName "$CustomerCode-AD-2012R2MemberServerBasic-v0006" -createifneeded -migrationtable "$locationfullname\ACCPMigrationTable.migtable"
Import-GPO -BackupId 3380124C-B092-4717-8985-32CEE145D795 -Path "$locationFullname\ACCPDelegation-v0005" -TargetName "$CustomerCode-SVR-ACCPDelegation-v0005" -createifneeded -migrationtable "$locationfullname\ACCPMigrationTable.migtable"
Write-host "GPO settings have been imported" -Foregroundcolor Yellow
Start-Sleep 3

#Create directory and move GPO

New-Item -ItemType directory -Path D:\GPObackup
Backup-GPO -all -path D:\GPObackup
Write-host "All policies have been backed up to directory: D:\GPOBackup" -Foregroundcolor Yellow
Start-Sleep 3


#Link GPOs

New-GPLink -Name "$CustomerCode-AD-2012R2DomainBasic-v0005" -Target $addomain.DistinguishedName -Order 1
New-GPLink -Name "$CustomerCode-AD-2012R2DomControllerBasic-v0006"-Target "OU=Domain Controllers,$($addomain.DistinguishedName)" -Order 1
New-GPLink -Name "$CustomerCode-AD-2012R2MemberServerBasic-v0006"-Target "OU=Servers,OU=DPC,$($addomain.DistinguishedName)" -Order 1
New-GPLink -Name "$CustomerCode-SVR-ACCPDelegation-v0005"-Target "OU=ACCP,OU=Servers,OU=DPC,$($addomain.DistinguishedName)" -Order 1
Write-host "GPOs have been linked to OU" -Foregroundcolor Yellow
Start-Sleep 3

#Central Store

#New-Item -ItemType directory -Path "\\$($data.DC1Name)\SYSVOL\$($data.DomainName)\Policies\PolicyDefinitions"
Copy-Item C:\Windows\PolicyDefinitions -Recurse -Destination "D:\SYSVOL\domain\Policies"


}

function ConfigureFineGrainedPolicy {

# BIG Section 4.5 New-ADFineGrainedPasswordPolicy
# Konrad's script

New-ADFineGrainedPasswordPolicy -Name "DELG-DPC-AD-G-AdminPwdPolicy" -Precedence 1 `
-MinPasswordLength "16" `
-PasswordHistoryCount "24" `
-MinPasswordAge "1.00:00:00" `
-MaxPasswordAge "42.00:00:00" `
-ComplexityEnabled $true `
-ReversibleEncryptionEnabled $false `
-Description "Applies mandatory password requirements to members of the  DELG-DPC-AD-G-AdminPwdPolicy security group" `
-DisplayName "DELG-DPC-AD-G-AdminPwdPolicy" `
-ProtectedFromAccidentalDeletion $true


Add-ADFineGrainedPasswordPolicySubject DELG-DPC-AD-G-AdminPwdPolicy -Subjects 'DELG-DPC-AD-G-AdminPwdPolicy'

Write-Host "

AD Fine grained policy configured: 
"
 $((Get-ADFineGrainedPasswordPolicy -Filter *))
Start-Sleep 5

}

function RestoreBINConfig {

# Configure Restore BIN and test
# Konrad's script

Enable-ADOptionalFeature "Recycle Bin Feature" `
                         -server ((Get-ADForest -Current LocalComputer).DomainNamingMaster) `
                         -Scope ForestOrConfigurationSet `
                         -Target (Get-ADForest -Current LocalComputer) `
                         -Confirm:$false
Start-sleep -Seconds 5
New-ADUser -name TestUserRB
Start-sleep -Seconds 5
Remove-ADUser -Identity TestUserRB -confirm:$false
Start-sleep -Seconds 5

Get-ADObject -filter 'isdeleted -eq $true -and name -ne "Deleted Objects"' -includeDeletedObjects -property * | Format-List samAccountName,displayName,lastknownParen

Get-ADObject -Filter 'samaccountname -eq "TestUserRB"' -IncludeDeletedObjects | Restore-ADObject
Start-sleep -Seconds 5

if(Get-ADUser TestUserRB) {

Write-host "Test succesfull: Object TestRB1 was restored"

}

else {Write-Host "Check Recycle Manually sth went WRONG"} 

Write-Host "THE TEST OBJECT TEST RB1 WILL BE DELETED IN 5 SECONDS!!!"
Start-sleep -Seconds 5
Remove-ADUser -Identity TestUserRB -confirm:$false
}

function Menu {

' '
Write-Host "AD Build script 1" -Foregroundcolor Yellow
' '

do {
  [int]$userMenuChoice = 0
  while ( $userMenuChoice -lt 1 -or $userMenuChoice -gt 19) {
    Write-Host "1. Configure general Options"
    Write-Host "2. Disk configuration"
	Write-Host "3. Install AD DS Role"
    Write-Host "4. Install AD Forest and first DC (REQUIRE REBOOT)"
    Write-Host "5. Create ACCP AD sites"
    Write-Host "6. Create OU structure"
    Write-Host "7. Create basic AD Groups structure"
    Write-Host "8. Create ACCP Service accounts"
    Write-Host "9. Configure groups memberships"
    Write-Host "10. Create and Configure GPO"
    Write-Host "11. Configure DNS"
    Write-Host "12. Configure Fine Grained Password Policy"
    Write-Host "13. Configure AD Restore BIN"
    Write-Host "14. Quit and Exit "

    [int]$userMenuChoice = Read-Host "Please choose an option"

    switch ($userMenuChoice) {
      1{GeneralOptions}
      2{FormatDisk}
      3{InstallADDSRole}
      4{InstallADForest}
      5{CreateACCPSites}
      6{ImportOU}
      7{ImportADGroups}
      8{ImportServiceAccounts}
      9{ADMemberships}
      10{CreateGPO}
      11{ConfigureDNS}
      12{ConfigureFineGrainedPolicy}
      13{RestoreBINConfig}
      14{Break switch}
      default {Write-Host "Nothing selected & wrong choice" -Foregroundcolor "yellow" }
    }
  }
} while ( $userMenuChoice -ne 99 )

}

<#
do{
$CustomerCode = Read-host "Please provide the 3-character Customer Code"
}
while ($CustomerCode.Length -ne 3)

do{
$CountryCode = Read-host "Please provide the 2-character Country Code"
}
while ($CustomerCode.Length -ne 2)

do{
$LocationCode = Read-host "Please provide the 3-character Location Code"
}
while ($CustomerCode.Length -ne 3)
#>

Menu