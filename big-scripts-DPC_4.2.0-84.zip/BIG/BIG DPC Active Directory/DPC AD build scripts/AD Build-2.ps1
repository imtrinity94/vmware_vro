﻿#DPC AD Build Script #2
#Version: 0.1
#Date: 01-10-2016
#Author: Piotr Lewandowski

#$InstalledRoles = Get-WindowsFeature  |  Where-Object Installed
$ascii=$NULL;For ($a=33;$a –le 126;$a++) {$ascii+=,[char][byte]$a }
#$StrOUTree = C:\Users\Administrator\Desktop\OUTree.csv
$GlobalDomainName
$data = import-csv .\input.csv

 ##########
 # Chceck if you run as admin
 ##########

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"
    Break
}

Function GET-Temppassword() {

###
# Complex password generator
# http://blogs.technet.com/b/heyscriptingguy/archive/2013/06/03/generating-a-new-password-with-windows-powershell.aspx
###



Param(

[int]$length=10,

[string[]]$sourcedata

)

 

For ($loop=1; $loop –le $length; $loop++) {

            $TempPassword+=($sourcedata | GET-RANDOM)

            }

return $TempPassword

}

<# ##########
 # Check if AD DS is already installed
 ##########

if ($InstalledRoles.Name -like "AD-Domain-Services") {
    Write-Host "Powershell installed";
  }
 Else { Write-Host "Powershell not installed" }
 #>
 <#
 function ChangeSrvName {

 ###########
 # 1. Change servername
 ##########


 $dcName = $data.DC2Name
 Rename-Computer $dcName -Restart

 }
 #>
 FUNCTION AddToDomain {

    Add-Computer -DomainName $data.DomainName -Credential (get-credential -Message "Enter domain credentials") -Restart:$true
 }
 <#
 function SecEdit {

  ###########
 # 2. Update Security monitor (BIG 3.4), Require manual job
 ##########

# Copy sceregvl.inf into current user desktop before change

 Copy-Item $env:SystemRoot\inf\sceregvl.inf $env:SystemRoot\sceregvl-old.inf

 Write-Host "File sceregvl.inf has been backed up in the same folder with -old suffix. Proceed to .inf file modification which is described in AD BIG section 3.4 Updating the Security Editor" -BackgroundColor DarkRed 

 }
#>
 Function GeneralOptions {

Write-Host "Deselect Advanced TCP/IP settings\WINS  Enable LMHosts lookup" -BackgroundColor DarkYellow
$nic = [wmiclass]'Win32_NetworkAdapterConfiguration'
$nic.enablewins($false,$false) > $null

Start-Sleep -s 2

Write-Host "Enable ipv6 protocol on network adapters" -BackgroundColor DarkYellow
Set-NetAdapterBinding -Name * -ComponentID  ms_tcpip6 -Enabled:$true 


Start-Sleep -s 2

Write-Host "Enable remote management of this server from other computers" -BackgroundColor DarkYellow
Configure-SMRemoting.exe -enable


Start-Sleep -s 2

Write-Host "Change CD rom drive letter to R: " -BackgroundColor DarkYellow
$cdrom = Get-WmiObject win32_cdromdrive


Get-WmiObject Win32_Volume -filter "DriveLetter='$($cdrom.Drive)'" | Set-WmiInstance -Arguments @{DriveLetter="R:"} > $null
$cdrom = Get-WmiObject win32_cdromdrive

Write-Host "Drive letter is:" $cdrom.Drive
' '
' '

}

 function FormatDisk {

if (get-disk | Where partitionstyle -eq 'raw') {

Get-Disk | Where IsSystem -eq $false | Initialize-Disk -PartitionStyle MBR -PassThru 
Start-Sleep -s 2

Stop-Service shellhwdetection
Get-Disk | Where IsSystem -eq $false | select -first 1| New-Partition -DriveLetter 'D' -UseMaximumSize 
Start-Sleep -s 2
Format-Volume -DriveLetter 'D' -FileSystem NTFS -NewFileSystemLabel "DATA" -Confirm:$false
Start-Service shellhwdetection

}
else {

# Trick to supress Format partition window
Stop-Service shellhwdetection
Get-Disk | Where IsSystem -eq $false | select -first 1| New-Partition -DriveLetter 'D' -UseMaximumSize
Start-Sleep -s 2
Format-Volume -DriveLetter 'D' -FileSystem NTFS -NewFileSystemLabel "DATA" -Confirm:$false
Start-Service shellhwdetection

    }
}

 function InstallADDSRole {
  
 ###########
 # Function for installing AD services role
 ##########

 
 Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools

 }

 
 function InstallADDomainController {

$message = "
Please specify site for this Domain Controller:
" 
$ACCPMGT = New-Object System.Management.Automation.Host.ChoiceDescription "&ACCP Management", "ACCP Management - DCs 003 and 004"
$PLATMGT = New-Object System.Management.Automation.Host.ChoiceDescription "&Platfrom Management", "Central Site - DCs 001 and 002"
$options = [System.Management.Automation.Host.ChoiceDescription[]]($ACCPMGT, $PLATMGT)
$result = $host.ui.PromptForChoice($null, $message, $options,0) 
                        
switch ($result)
{
0 {$sitename = $data.ACCPMGTSiteName}
1 {$sitename = $data.PLATMGTSiteName}            
}
 $DSRMpass = GET-Temppassword -length 16 -sourcedata $ascii
 Write-Output "DSRM password for $($env:COMPUTERNAME) is: $DSRMpass" >> .\DSRM_pass.txt
 
 $DomainName = $data.DomainName
 #$FirstController = $($data.DC3Name)+"."+$($data.DomainName)
 $AdDomainShort = (Get-ADDomain).Name
 # -ReplicationSourceDC $FirstController `

 Install-ADDSDomainController `
        -NoGlobalCatalog:$false `
        -CreateDnsDelegation:$false `
        -CriticalReplicationOnly:$false `
        -DatabasePath "D:\NTDS" `
        -DomainName $DomainName `
        -InstallDns:$true -LogPath "D:\Logs" `
        -NoRebootOnCompletion:$false `
        -SiteName $SiteName `
        -SysvolPath "D:\SYSVOL" `
        -Force:$true `
        -Credential (get-credential -UserName "$($AdDomainShort)\Administrator" -Message "Enter password for $($AdDomainShort)\Administrator" ) `
        -Confirm:$false `
        -SafeModeAdministratorPassword (ConvertTo-SecureString $DSRMpass -AsPlainText -Force) `

      }


function ConfigureDNS {

$dnssrv = Get-DnsServer

#Remove root hints

Get-DnsServerRootHint | Remove-DnsServerRootHint -Force
Write-Host "DNS root hints have been removed" -Foregroundcolor DarkYellow;

#Remove DNS forwarders

Get-DnsServerForwarder | Remove-DnsServerForwarder -Force
Write-Host "DNS forwarders have been removed" -Foregroundcolor DarkYellow;

#Setting Listening IP and Name check flag

$DNSobj = Get-DnsServerSetting -all
$DNSobj.ListeningIPAddress = $dnsobj.ListeningIPAddress | ?{$_ -match '(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'}
$DNSobj.NameCheckFlag = 0
Set-DnsServerSetting -inputobject $DNSobj


}

function ConfigureNTP {

$gateway = get-wmiobject win32_networkadapterconfiguration | ? {$_.ipaddress -match '(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'} | select  -expand defaultipgateway

Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\ -Name Type -Value NTP
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config\ -Name AnnounceFlags -Value 5
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer -Name Enabled -Value 1
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient -Name SpecialPollInterval -Value 300
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config -Name MaxPosPhaseCorrection -Value 1800
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config -Name MaxNegPhaseCorrection -Value 1800
Set-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\ -Name NtpServer -Value "$($data.NTPServer),0x1";

#Check keys

Write-Host "Settings should be confgiured as:";
$key1 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\ -Name Type;
$key2 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config\ -Name AnnounceFlags;
$key3 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer -Name Enabled;
$key4 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient -Name SpecialPollInterval;
$key5 = get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config -Name MaxPosPhaseCorrection;
$key6 = Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\ -Name NtpServer;
$key7 = Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Config -Name MaxNegPhaseCorrection;

Write-Host "Required:" -Foregroundcolor DarkYellow
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\Type 	                             NTP";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\AnnounceFlags	                         5";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer\Enabled 	             1";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\NtpServer                         "$($data.NTPServer),0x1"";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient\SpecialPollInterval   300 Decimal";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\MaxPosPhaseCorrection                  1800 Decimal";
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\MaxNegPhaseCorrection                  1800 Decimal";
' '
Write-Host "Configured:" -Foregroundcolor DarkRed;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\Type 	                            "$key1.Type
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\AnnounceFlags	                        "$key2.AnnounceFlags;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpServer\Enabled 	            "$key3.Enabled;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Parameters\NtpServer                         "$key6.NtpServer;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient\SpecialPollInterval  "$key4.SpecialPollInterval;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\MaxPosPhaseCorrection                 "$key5.MaxPosPhaseCorrection;
Write-Host "HKLM\SYSTEM\CurrentControlSet\Services\W32Time\Config\MaxNegPhaseCorrection                 "$key7.MaxNegPhaseCorrection;

get-service w32time | Restart-Service
Start-Sleep 5;

}

function MoveFSMOROles {
write-host "Moving Domain-wide FSMO roles to $($data.DC1Name)" -ForegroundColor Yellow
Move-ADDirectoryServerOperationMasterRole -Identity $data.DC1Name -OperationMasterRole RIDMaster,InfrastructureMaster,PDCEmulator
write-host "Moving Forest-wide FSMO roles to $($data.DC2Name)" -ForegroundColor Yellow
Move-ADDirectoryServerOperationMasterRole -Identity $data.DC2Name -OperationMasterRole SchemaMaster,DomainNamingMaster

netdom query fsmo
}

function ConfigureSiteLink {
$ACCPMGTSiteName = $data.ACCPMGTSiteName
$PLATMGTSiteName = $data.PLATMGTSiteName
$sites = Get-ADReplicationSite -filter * | select -expand name
get-adreplicationsitelink -filter {name -like "Default*"} | set-adreplicationsitelink -ReplicationFrequencyInMinutes 15 -SitesIncluded @{add=$sites} -description "Platform Management to ACCP Management"
get-adreplicationsitelink -filter {name -like "Default*"} | rename-adobject -newname "$PLATMGTSiteName-$ACCPMGTSiteName"

write-host "Default Site has ben re-configured as follows:"
get-adreplicationsitelink -filter * | select name,cost,replicationfrequency*,@{N="Sites Included";E={$_.sitesincluded | %{$_.split(",")[0].split("=")[1]}}}

}

function Menu {

#Interactive menu WiP
' '
Write-Host "AD Build script 2" -ForegroundColor Yellow
' '
do {
  [int]$userMenuChoice = 0
  while ( $userMenuChoice -lt 1 -or $userMenuChoice -gt 10) {
    Write-Host "1. Configure general Options"
    Write-Host "2. Disk configuration"
    Write-Host "3. Install AD DS Role"
    Write-Host "4. Add to domain (REQUIRE REBOOT)"
    Write-Host "5. Install Domain Controller"
    Write-Host "6. Configure DNS"
    Write-Host "7. Configure site link between ACCP sites"
    Write-Host "8. Configure NTP settings"
    Write-Host "9. Move FSMO roles"
    Write-Host "10. Quit and Exit"

    [int]$userMenuChoice = Read-Host "Please choose an option"

    switch ($userMenuChoice) {
      1{GeneralOptions}
      2{FormatDisk}
      3{InstallADDSRole}
      4{AddToDomain}
      5{InstallADDomainController}
      6{ConfigureDNS}
      7{ConfigureSiteLink}
      8{ConfigureNTP}
      9{MoveFSMORoles}
      10{Break switch}
      default {Write-Host "Nothing selected & wrong choice" -foregroundcolor "yellow" }
    }
  }
} while ( $userMenuChoice -ne 99 )

}

Menu