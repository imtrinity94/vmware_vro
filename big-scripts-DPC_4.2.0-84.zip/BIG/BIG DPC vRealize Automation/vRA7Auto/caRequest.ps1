﻿CertReq.exe -q -submit -attrib CertificateTemplate:webserver -config - "c:\vraAutomation\iaas\rui.csr" Out-File "c:\vraAutomation\iaas\iaas.p7b"
del Out-File
del Out-File.rsp


CertReq.exe -q -submit -attrib CertificateTemplate:webserver -config - "c:\vraAutomation\vra\rui.csr" Out-File "c:\vraAutomation\vra\vra.p7b"
del Out-File
del Out-File.rsp

CertReq.exe -q -submit -attrib CertificateTemplate:webserver -config - "c:\vraAutomation\web\rui.csr" Out-File "c:\vraAutomation\web\web.p7b"
del Out-File
del Out-File.rsp