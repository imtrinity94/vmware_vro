﻿###################################################
## Auto Deploy Windows server based on json file
## Author: Tomasz Korniluk , ver.0.3, 2017-11-15
###################################################
## Updates:
## 
## - Added remote installation of IaaS Mgt Agent
## - Adjusted IaaS Mgt Agent installation
## ## Base parameters #####################################

$workdir = $MyInvocation.MyCommand.Path
$dir = Split-Path $workdir
$json_file = "VRI.json"
$custom_file = "IaaS.xml"
$verb_error1 = "Value is empty!"
$verb_error2 = "Wrong value used"
$status = "/disabled - json file validation required/"
$color_up = "Yellow"
$color_ok= "Green"
$color_error= "Red"
$color="Gray"
$defxml= "default.xml"
$valid="false"
$ap=""


function vcs_connect {

if((Test-Path -Path $json_file)) {

$json = Get-Content $json_file | Out-String | ConvertFrom-Json

$base = $json.Base | Where{$_.Key -eq 'Vcenter'}


} else { 

write-host $("## <ERROR> Unable to locate json file: $json_file - please check name of json file") -ForegroundColor Red

menu; }

## Load VMware modules into powershell session

$vm_modules = Get-Module -ListAvailable VMware* | Import-Module | Out-Null
$ls_modules =  Get-Module -ListAvailable VMware*

$vc = Connect-VIServer -Server $base.Value

if ($vc) {  

write-host $("## <OK> Established connection with Vcenter:[",$vc.Name,"]") -ForegroundColor Yellow

$vcenter1 = $vc.Name

$vmprefix = $vcenter1.substring(0,$vcenter1.Length-11)

$loc = $vcenter1.substring($vcenter1.Length-10,4)

#$vm_prefix2 = $vcenter1.substring(0,$vcenter1.Length-6)

$vm_prefix = $vmprefix+"W"+$loc

write-host $("## <INFO> Suggested VM Name prefix:[",$vm_prefix,"]") -ForegroundColor White


} else {

write-host $("## <ERROR> Unable to establish connection with Vcenter:[",$vcenter1,"]") -ForegroundColor Red

menu;

 }

if(!$vm_modules) { 


foreach ($module in $ls_modules) {

write-host $("## <INFO> Module ",$module.Name," is available") -ForegroundColor White


} 

} else { 

write-host $("## <ERROR> Unable to load VMware modules - please check powerCLI installation") -ForegroundColor Red

menu;

}

validate $vm_prefix

} 


function update_json {

if((Test-Path -Path $json_file)) {

$json = Get-Content $json_file | Out-String | ConvertFrom-Json

## Load property mapping section from json file

$properties1 = $json.PropertyMapping

$features = $json.Features
$base = $json.Base

$applications = $json.Applications

## Load Network properties from json file

$net_name = $json.NetworkMapping

$vmname = $json.Name


foreach ($bs in $base) {

$rollback = $bs.Value

write-host $("## <UPDATE>",$bs.Key,"....< current value:",$bs.Value,">") -ForegroundColor Yellow

$input = read-host $("## <UPDATE> New value [",$ft.Value,"]") 

$bs.Value = $input

if($input -eq "" -OR $input -eq " ") { 

write-host $("## <NO UPDATE>",$bs.Key,"....< use current value:",$rollback,">") -ForegroundColor Green

$bs.Value = $rollback

} else  { 

$json | ConvertTo-JSON | set-content $json_file

if($json) { write-host $("## <UPDATED KEY WITH SUCCESS>",$bs.Key,"....< with value:",$bs.Value,">") -ForegroundColor Yellow } else { 
write-host $("## <ERROR TO UPDATE KEY>",$bs.Key,"....< with value:",$bs.Value,">") -ForegroundColor Red } 

}

}




foreach ($Keys in $properties1) {

$rollback = $Keys.Value

write-host $("## <UPDATE>",$Keys.Key,"....< current value:",$Keys.Value,">") -ForegroundColor Yellow

$input = read-host $("## <UPDATE> New value [",$Keys.Value,"]") 

$Keys.Value = $input

if($input -eq "" -OR $input -eq " ") { 

write-host $("## <NO UPDATE>",$Keys.Key,"....< use current value:",$rollback,">") -ForegroundColor Green

$Keys.Value = $rollback

} else  { 

$json | ConvertTo-JSON | set-content $json_file

if($json) { write-host $("## <UPDATED KEY WITH SUCCESS>",$Keys.Key,"....< with value:",$Keys.Value,">") -ForegroundColor Yellow } else { 
write-host $("## <ERROR TO UPDATE KEY>",$Keys.Key,"....< with value:",$Keys.Value,">") -ForegroundColor Red } 

}

}

} else { 

write-host $("## <ERROR> Json file: $json_file.......[Missing file]") -ForegroundColor Red

}

foreach ($ft in $features) {

$rollback = $ft.Value

write-host $("## <UPDATE>",$ft.Key,"....< current value:",$ft.Value,">") -ForegroundColor Yellow

$input = read-host $("## <UPDATE> New value [",$ft.Value,"]") 

$ft.Value = $input

if($input -eq "" -OR $input -eq " ") { 

write-host $("## <NO UPDATE>",$ft.Key,"....< use current value:",$rollback,">") -ForegroundColor Green

$ft.Value = $rollback

} else  { 

$json | ConvertTo-JSON | set-content $json_file

if($json) { write-host $("## <UPDATED KEY WITH SUCCESS>",$ft.Key,"....< with value:",$ft.Value,">") -ForegroundColor Yellow } else { 
write-host $("## <ERROR TO UPDATE KEY>",$ft.Key,"....< with value:",$ft.Value,">") -ForegroundColor Red } 

}

}

foreach ($app in $applications) {

$rollback = $app.Value

write-host $("## <UPDATE>",$app.Key,"....< current value:",$app.Value,">") -ForegroundColor Yellow

$input = read-host $("## <UPDATE> New value [",$app.Value,"]") 

$app.Value = $input

if($input -eq "" -OR $input -eq " ") { 

write-host $("## <NO UPDATE>",$app.Key,"....< use current value:",$rollback,">") -ForegroundColor Green

$app.Value = $rollback

} else  { 

$json | ConvertTo-JSON | set-content $json_file

if($json) { write-host $("## <UPDATED KEY WITH SUCCESS>",$app.Key,"....< with value:",$app.Value,">") -ForegroundColor Yellow } else { 
write-host $("## <ERROR TO UPDATE KEY>",$app.Key,"....< with value:",$app.Value,">") -ForegroundColor Red } 

}

}


### Updating baseline section

write-host $("## <UPDATE> VM Name:....< current value:",$vmname,">") -ForegroundColor Yellow
write-host $("## <INFO> Suggested VM Name:.............",$vm_prefix,">") -ForegroundColor White
$inputvm = read-host $("## <UPDATE> VM Name new value [",$vmname,"]") 

if($inputvm -eq "" -OR $inputvm -eq " ") { 


write-host $("## <NO UPDATE> VM name....< use current value:",$vmname,">") -ForegroundColor Green


} else {
$vmname = $inputvm

write-host $("## <UPDATED KEY WITH SUCCESS> VM name with new value:",$vmname,">") -ForegroundColor Yellow
 }



### Updating NetworkingMapping Section

write-host $("## <UPDATE> Network name:....< current value:",$net_name.Name,">") -ForegroundColor Yellow

$rollback1 = $net_name.Name

$input = read-host $("## <UPDATE> Network name new value [",$net_name.Name,"]") 

write-host $("## <UPDATE> Network group:....< current value:",$net_name.Network,">") -ForegroundColor Yellow

$input1 = read-host $("## <UPDATE> Network group name new value [",$net_name.Network,"]") 


if($input -eq "" -OR $input -eq " ") { 


write-host $("## <NO UPDATE> Network name....< use current value:",$net_name.Name,">") -ForegroundColor Green


} else {
$net_name.Name = $input
write-host $("## <UPDATED KEY WITH SUCCESS> Network name with new value:",$net_name.Name,">") -ForegroundColor Yellow
 }


if($input1 -eq "" -OR $input1 -eq " ") { 

write-host $("## <NO UPDATE> Network group name....< use current value:",$net_name.Network,">") -ForegroundColor Green



} else { 

$net_name.Network = $input1

write-host $("## <UPDATED KEY WITH SUCCESS> Network group name with new value:",$net_name.Network,">") -ForegroundColor Yellow

}




$json | ConvertTo-JSON | set-content $json_file

if($json) { write-host $("## <UPDATED JSON FILE: $json_file SUCCESSFULLY> ################") -ForegroundColor Yellow } 
else { 

write-host $("## <ERROR> Json file: $json_file.......[Missing file]") -ForegroundColor Red


}



}


function InstallAgent() {

$args = 'msiexec.exe /i "{0}" /qn /norestart /Lvoicewarmup! "{1}\VMware\vCAC\Logs\ManagementAgentInstall-{2:yyyyMMdd-HHmm}.log" ADDLOCAL="ALL" INSTALLLOCATION="{1}\VMware\vCAC\Management Agent\" MANAGEMENT_ENDPOINT_ADDRESS="{3}" MANAGEMENT_ENDPOINT_THUMBPRINT="{4}" SERVICE_USER_NAME="{5}" SERVICE_USER_PASSWORD="{6}" VA_USER_NAME="{7}" VA_USER_PASSWORD="{8}"' 
 
if((Test-Path -Path $json_file)) {

$json = Get-Content $json_file | Out-String | ConvertFrom-Json

## Load property mapping section from json file

$vra = $json.PropertyMapping | Where{$_.Key -eq 'IaaS.Agent.VRA'}
$vhost = $json.PropertyMapping | Where{$_.Key -eq 'vami.hostname'}
$domain = $json.PropertyMapping | Where{$_.Key -eq 'vami.domain'}
$svcvra = $json.PropertyMapping | Where{$_.Key -eq 'vra.svc.account'}
$svcpass = $json.PropertyMapping | Where{$_.Key -eq 'vra.svc.account.password'}
$vrapass = $json.PropertyMapping | Where{$_.Key -eq 'vra.root.password'}

$vaRootUserName = "root"
$share = "c$\Temp"
$Target = "\\"+$vhost.Value+"\c$\Temp"
$programfiles = "C:\Program Files (x86)"
$svcvradom = $domain.value+"\"+$svcvra.value

$local = "C:\Temp\vCAC-IaaSManagementAgent-Setup.msi"
$url2 = "https://"+$vra.Value+":5480"
$url3 = $url2+"/installer/vCAC-IaaSManagementAgent-Setup.msi"
$destination = "$dir\vCAC-IaaSManagementAgent-Setup.msi"
    
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

$WebClient = New-Object System.Net.WebClient
$download = $webClient.DownloadFile("$url3", "$destination")


   if (Test-Path -Path "$dir\vCAC-IaaSManagementAgent-Setup.msi") {

   write-host $("## <OK> IaaS Management Agent downloaded from location:",$url2,"with success") -ForegroundColor Green

    $copy = Copy-Item -Path $destination -Destination $Target

    } else { write-host $("## <ERROR> Unable to locate file vCAC-IaaSManagementAgent-Setup.msi in $dir") -ForegroundColor Red ; menu; }

    if(Test-Path -Path "$Target\vCAC-IaaSManagementAgent-Setup.msi") { 
    
    write-host $("## <OK> IaaS Management Agent copied to remote location:",$Target,"with success") -ForegroundColor Green
    
    $get_req = [System.Net.Webrequest]::Create("$url2/installer")
    
    if ($get_req) {  write-host $("## <OK> Established SSL connection to",$url2,"with success") -ForegroundColor Green

    $SSL = $get_req.ServicePoint.Certificate.GetCertHashString()

    if ($SSL) { write-host $("## <OK> Extracted SSL thumbprint [$SSL] from",$url2,".") -ForegroundColor Green 
    
    #$global:vraThumbprint = $SSL -replace '(..(?!$))','$1:'

    $args = $args -f $local, $programfiles, (Get-Date), $url2, $SSL, $svcvradom, $($svcpass.Value), $vaRootUserName, $($vrapass.Value)
      
    $comm = $args
    
    $installloc = "\\"+$vhost.Value+"\C$\Program Files (x86)\VMware"
    
    $log = ($comm -split ':')[2].substring(0)
    $loc = ($log -split '"')[0].substring(0)
    $logpath = "\\"+$vhost.Value+"\C$"+$loc

    invoke-command -computername $vhost.Value -ScriptBlock {param($comm) $comm > C:\Temp\Install.bat } -Argumentlist $comm
    invoke-command -ComputerName $vhost.Value -ScriptBlock { Set-Content -Path C:\Temp\Install.bat -Encoding ASCII -Value (Get-Content -Path C:\Temp\Install.bat) }
   
    ## Execution for Agent remote installation

    if((Test-Path -Path "$installloc")) {
       
    $fvcac = New-Item -Path "$installloc\vCAC\Logs" -type directory -Force

    if($fvcac) { 
    
     write-host $("## <OK> Created missing folder structure ",$installloc,"\vCAC\Logs") -ForegroundColor Green

     $install = invoke-command -computername $vhost.Value -ScriptBlock {Start-Process -FilePath C:\Temp\Install.bat -Wait -Passthru}
    
    } else { 
    
    write-host $("## <ERROR> Unable to create missing folder structure ",$installloc,"\vCAC\Logs") -ForegroundColor Red
    
    }

     } else {
     
     $fvmware = New-Item -Path "$installloc\vCAC\Logs" -type directory -Force
     
     if($fvmware) { write-host $("## <OK> Created missing base Vmware folder structure ",$installloc,"with success") -ForegroundColor Green 
     
     $install = invoke-command -computername $vhost.Value -ScriptBlock {Start-Process -FilePath C:\Temp\Install.bat -Wait -Passthru}
     
     } else {

     write-host $("## <ERROR> Unable to create base Vmware folder structure ",$installloc,".") -ForegroundColor Red

     }

     } 

          
    #invoke-command -computername $vhost.Value -ScriptBlock {param($comm) $comm > C:\Temp\Install.bat } -Argumentlist $comm
    #invoke-command -ComputerName $vhost.Value -ScriptBlock { Set-Content -Path C:\Temp\Install.bat -Encoding ASCII -Value (Get-Content -Path C:\Temp\Install.bat) }
    #$install = invoke-command -computername $vhost.Value -ScriptBlock {Start-Process -FilePath C:\Temp\Install.bat -Wait -Passthru}
    #invoke-command -computername $vhost.Value -ScriptBlock {echo . > C:\Temp\Install.bat}
            
    if ($install) { 

    write-host $("## <OK> Remote installation of vCAC-IaaSManagementAgent on ",$vhost.Value,"started") -ForegroundColor Green

     While (!$Start) {
   
      $Start = $true
   
      $service_lookup = Get-Service -ComputerName $vhost.Value | Where { $_.Name -eq "VMware vCloud Automation Center Management Agent"} 

      if($service_lookup.Name -eq "VMware vCloud Automation Center Management Agent") { 

      $Service = Get-Service -ComputerName $vhost.Value -ServiceName "VMware vCloud Automation Center Management Agent"

      write-host $("## <INFO> Waiting for vCloud Automation Center Management Agent installator to complete on....[",$vhost.Value,"] ") -ForegroundColor White
     
        if ($Service.Status -eq "Running") {
        
        $logging = Get-Content -Path "$logpath" | Select-String ": Product:"
        
        write-host $logging

        write-host $("## <OK> vCloud Automation Center Management Agent installation completed on....[",$vhost.Value,"]") -ForegroundColor Green

        $Start = $True

        write-host $("## <DEPLOYMENT> FINAL DEPLOYMENT STEP COMPLETED WITH SUCCESS ON....[",$vhost.Value,"]") -ForegroundColor Yellow ; menu;
  
       } 

          
      } else {

      write-host $("## <INFO> vCloud Automation Center Management Agent not yet installed on....[",$vhost.Value,"] ") -ForegroundColor White

      $logging = Get-Content -Path "$logpath" | Select-String ": Product:"
                 
      $log = ($logging -split ':')[6].substring(0)

      if ($log -like "*Installation failed.") {

      write-host $logging

      write-host $("## <ERROR> Remote installation of vCAC-IaaSManagementAgent on",$vhost.Value,"server failed") -ForegroundColor Red
                 
      $Start = $True


      } 

      }

      sleep 5



    } 

    sleep 5

          
    } else {

    write-host $("## <ERROR> Unable to start remote installation vCAC-IaaSManagementAgent on",$vhost.Value,"server") -ForegroundColor Red

    }
            
    } else { write-host $("## <ERROR> Unable to extract SSL thumbprint from $url2") -ForegroundColor Red  ; menu;}

    } else { write-host $("## <ERROR> Unable to establish SSL connection with $url2") -ForegroundColor Red ; menu;}

    } else { write-host $("## <ERROR> Unable to copy IaaS Management Agent to remote location: $Target") -ForegroundColor Red ; menu;} 

    } else { write-host $("## <ERROR> Unable to download file vCAC-IaaSManagementAgent-Setup.msi") -ForegroundColor Red ; menu;} 

    invoke-command -computername $vhost.Value -ScriptBlock {echo . > C:\Temp\Install.bat}

    
}


function Add2adm {

$json = Get-Content $json_file | Out-String | ConvertFrom-Json

## Load property mapping section from json file

$vra = $json.PropertyMapping | Where{$_.Key -eq 'IaaS.Agent.VRA'}
$vhost = $json.PropertyMapping | Where{$_.Key -eq 'vami.hostname'}
$domain = $json.PropertyMapping | Where{$_.Key -eq 'vami.domain'}
$svcvra = $json.PropertyMapping | Where{$_.Key -eq 'vra.svc.account'}


write-host $("## <INFO> Adding service account",$svcvra.Value,"into local admin group on....[",$vhost.Value,"] ") -ForegroundColor White

    $AdminGroup = [ADSI]"WinNT://",$vhost.Value,"/Administrators,group"

    if ($AdminGroup) {

    write-host $("## <OK> Established remote connection to get local group on....[",$vhost.Value,"] ") -ForegroundColor Green

    $User = [ADSI]"WinNT://",$domain.Value,"/",$svcvra.Value,",user"

    $AdminGroup.Add($User.Path)

    if ($User) { write-host $("## <INFO> Added account",$svcvra.Value," to administrator local group on....[",$vhost.Value,"] ") -ForegroundColor White
    
    $Check = $AdminGroup.Members() | ForEach-Object { $_.GetType().InvokeMember("Name","GetProperty",$NULL,$_,$NULL) }
    
    $account = $Check | Select-String $svcvra.Value

    if($account) { write-host $("## <OK> Successfully added account",$svcvra.Value," to administrator local group on....[",$vhost.Value,"] ") -ForegroundColor Green 
    
    write-host $("## <DEPLOYMENT> FINAL DEPLOYMENT STEP COMPLETED WITH SUCCESS ON....[",$vhost.Value,"]") -ForegroundColor Yellow ; menu;
    
    } 
   
    else { write-host $("## <ERROR> Unable to add service account on....[",$vhost.Value,"]") -ForegroundColor Red }

    } else { write-host $("## <ERROR> Unable to add service account on....[",$vhost.Value,"]") -ForegroundColor Red }

    
    } else { write-host $("## <ERROR> Unable to establish connection with....[",$vhost.Value,"]") -ForegroundColor Red ; menu; }


}


function convert2xml ([string]$filejson,[string]$filexml) {

if((Test-Path -Path $filejson)) { 

$json = Get-Content $filejson | Out-String | ConvertFrom-Json

if (!$json) { write-host $("## <ERROR> Missing file",$filejson,"") -ForegroundColor Red } else {

$input = read-host $("## <CONVERT> Use XML default name:[",$filexml,"] or provide new xml name:") 


if($input -eq "") { write-host $("## <CONVERT> Converting file",$filejson,"using default filename:",$filexml,"") -ForegroundColor Yellow

$json | Export-Clixml $filexml

} else {

write-host $("## <CONVERT> Converting file",$filejson,"to file ",$input,"") -ForegroundColor Yellow

$json | Export-Clixml $input

}


}  

} else { write-host $("## <ERROR> Missing file",$filejson,"") -ForegroundColor Red  }
menu;

}



function validate ([string]$v) {


if((Test-Path -Path $json_file)) { 

## Load json content

$json = Get-Content $json_file | Out-String | ConvertFrom-Json

## Checking Base settings

$base = $json.Base
$cpu = $json.Base | Where{$_.Key -eq 'vCPU'}
$mem = $json.Base | Where{$_.Key -eq 'Memory'}

## Checking Property Mappings

$properties = $json.PropertyMapping
$vmname = $json.PropertyMapping | Where{$_.Key -eq 'vami.Hostname'}

## Checking Features

$features = $json.Features 

##| Where{$_.Value -eq 'Enable' -OR $_.Value -eq 'Disable'}

## Checking applications

$applications = $json.Applications

## Checking Network Mappings
$networkmap = $json.NetworkMapping


foreach ($bs in $base) {

if($bs.Value -eq "" -OR $bs.Value -eq " ") { 
write-host $("## <ERROR>",$bs.Key,"..........[",$verb_error1,"]") -ForegroundColor Red
$bs1= "True"
} else {

write-host $("## <OK>",$bs.Key,"..........[",$bs.Value,"]") -ForegroundColor Green

}
}


foreach ($Key in $properties) {

if($Key.Value -eq "" -OR $Key.Value -eq " ") { 
write-host $("## <ERROR>",$Key.Key,"..........[",$verb_error1,"]") -ForegroundColor Red

$prop = "True"

} else {

write-host $("## <OK>",$Key.Key,"..........[",$Key.Value,"]") -ForegroundColor Green

}
}

foreach ($ft in $features) {

if($ft.Key -eq "" -OR $ft.Key -eq " ") { 

write-host $("## <ERROR> Missing feature key name",$ft.Key,"..........[",$verb_error1,"]") -ForegroundColor Red

$ft1= "True"

}



if($ft.Value -eq "" -OR $ft.Value -eq " ") {  
write-host $("## <ERROR>",$ft.Key,"..........[",$verb_error1,"]") -ForegroundColor Red } else {

if($ft.Value -eq "Enable" -OR $ft.Value -eq "Disable" ) {

write-host $("## <OK> Feature installation ",$ft.Key,"has been......[",$ft.Value,"]") -ForegroundColor Green } else {

write-host $("## <ERROR>",$ft.Key,"wrong value used..........[",$ft.Value,"] use: Enable/Disable") -ForegroundColor Red

$ft1= "True"

 }

if($cpu.Value -eq 2 -OR $cpu.Value -eq 1 -OR $cpu.Value -eq 4) { 


} else {  write-host $("## <ERROR>",$cpu.Key,"amount incorrect value:",$cpu.Value,"..........[",$verb_error2,"]") -ForegroundColor Red 
$cpu1 = "True"

 }

if($mem.Value -eq 6 -OR $mem.Value -eq 4 -OR $mem.Value -eq 2) { 


} else { write-host $("## <ERROR>",$mem.Key,"amount incorrect value:",$mem.Value,"..........[",$verb_error2,"]") -ForegroundColor Red  
$mem1 = "True"
}

}

}

foreach ($app in $applications) {

if($app.Value -eq "" -OR $app.Value -eq " ") {  
write-host $("## <ERROR>",$app.Key,"..........[",$verb_error1,"]") -ForegroundColor Red
$app1 = "True"


} else {

if($app.Value -eq "Enable" -OR $app.Value -eq "Disable" ) {

write-host $("## <OK> Application installation ",$app.Key,"has been......[",$app.Value,"]") -ForegroundColor Green } else {

write-host $("## <ERROR>",$app.Key,"wrong value used..........[",$app.Value,"] use: Enable/Disable") -ForegroundColor Red
$app1 = "True"
 }

}
}



foreach ($Name in $networkmap) {

if($Name.Network -eq "" -OR $Name.Network -eq " ") { 

$Name1 = "true"

write-host $("## <ERROR>",$Name.Name,"..........[",$verb_error1,"]") -ForegroundColor Red

} else {

write-host $("## <OK>",$Name.Name,"..........[",$Name.Network,"]") -ForegroundColor Green

}
}


if($vmname.value -notlike "$v*") { write-host $("## <ERROR> VM name ..........[",$verb_error2,",use prefix",$v,"]") -ForegroundColor Red

$vmname1 = "true"

menu;

} else {

write-host $("## <OK> VM name..........[",$vmname.value,"]") -ForegroundColor Green

}


} else { 

write-host $("## <ERROR> Json file: $json_file.......[Missing file]") -ForegroundColor Red


}

if($vmname1 -eq "true" -OR $Name1 -eq "true" -OR $app1 -eq "true" -OR $ft1 -eq "true" -OR $bs1 -eq "true" -OR $cpu1 -eq "true" -OR $mem1 -eq "true" -OR $prop -eq "true") { 

write-host $("## <ERROR> Validation failed - make sure to update missing above values") -ForegroundColor Red

}  else { write-host $("## <OK> Validation passed for json file: $json_file [READY FOR DEPLOYMENT]") -ForegroundColor Yellow

$valid = "true"
$Color = "Yellow"
$status = "(passed validation)"

}

}


function deploy {

if((Test-Path -Path $json_file)) { 

## Load json content

$json = Get-Content $json_file | Out-String | ConvertFrom-Json


$base = $json.Base
$cpu = $json.Base | Where{$_.Key -eq 'vCPU'}
$mem = $json.Base | Where{$_.Key -eq 'Memory'}
$datastore = $json.Base | Where{$_.Key -eq 'Datastore'}
$cluster = $json.Base | Where{$_.Key -eq 'Cluster'}
$cluster1 = $json.Base | Where{$_.Key -eq 'Folder'}
$Template = $json.Base | Where{$_.Key -eq 'Template'}
$custom = $json.Base | Where{$_.Key -eq 'Profile'}

$vm = $json.PropertyMapping | Where{$_.Key -eq 'vami.Hostname'}
$gateway = $json.PropertyMapping | Where{$_.Key -eq 'vami.gateway'}
$ip = $json.PropertyMapping | Where{$_.Key -eq 'vami.ip0'}
$mask = $json.PropertyMapping | Where{$_.Key -eq 'vami.netmask0'}
$dns = $json.PropertyMapping | Where{$_.Key -eq 'vami.DNS'}
$domain = $json.PropertyMapping | Where{$_.Key -eq 'vami.domain'}

$features = $json.Features 

$applications = $json.Applications

$network = $json.NetworkMapping | Where{$_.Name -eq 'Network 1'}

} else { write-host $("## <ERROR>Unable to load json file: $json_file") -ForegroundColor Red }


$vmhost = Get-Cluster $cluster.Value | Get-VMHost | Sort MemoryGB | Select -first 1
$dc = Get-DataCenter

if ($vmhost) {

write-host $("## <DEPLOYMENT PRE-CHECK> Checking if VM with name",$vm.Value,"inside environment is free") -ForegroundColor Yellow

$check = Get-VM | Select Name | Where {$_.Name -eq $vm.Value}

write-host $("## <DEPLOYMENT PRE-CHECK> Checking if VDS port group",$network.Network,"exists inside environment") -ForegroundColor Yellow

$netcheck = Get-VDPortGroup -Name $network.Network } else { 

write-host $("## <ERROR>VM with name [",$vm.Value,"]already exist inside environment !") -ForegroundColor Red
 write-host $("## <ERROR>Deployment aborted for VM [",$vm.Value,"]") -ForegroundColor Red ; menu; }


if($check -eq $vm.Value) {

 write-host $("## <ERROR>VM with name [",$vm.Value,"]already exist inside environment !") -ForegroundColor Red
 write-host $("## <ERROR>Deployment aborted for VM [",$vm.Value,"]") -ForegroundColor Red
 menu;
 } 
 
 
if($netcheck.Name -ne $network.Network) {

 write-host $("## <ERROR>VDS port group [",$network.Network,"]not found inside environment !") -ForegroundColor Red
 write-host $("## <ERROR>Deployment aborted for VM [",$vm.Value,"]") -ForegroundColor Red ; menu;

} else {

write-host $("## <DEPLOYMENT PRE-SET> Setup OS customization:",$custom.Value,"adjusting ip & DNS configuration & domain join") -ForegroundColor Yellow

#write-host $("## <UPDATE> Provide OS customization profile local admininistrator password:>") -ForegroundColor Yellow

#$admpass = Read-Host -Prompt "## <UPDATE> Local administrator password:" -AsSecureString

#$decryptadm = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($admpass)
#$dadmpass = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($decryptadm)

$specnet = Get-OSCustomizationNicMapping -OSCustomizationSpec $custom.Value

$specnet | Set-OSCustomizationNicMapping -Position 1 -IpMode UseStaticIP -IpAddress $ip.Value -SubnetMask $mask.Value -Dns $dns.Value -DefaultGateway $gateway.Value

$specos = Get-OSCustomizationSpec -Name $custom.Value

### Get domain crednetials

write-host $("## <UPDATE> Provide domain ",$domain.Value,"account credentials>") -ForegroundColor Yellow

$suser = Read-Host -Prompt "## <UPDATE> Domain account user name:"
$spass = Read-Host -Prompt "## <UPDATE> Domain account user password:" -AsSecureString

$decryptp = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($spass)
$dpass = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($decryptp)

$specos | Set-OSCustomizationSpec -Domain $domain.Value  -DomainUsername $suser -DomainPassword $dpass -DnsServer $dns.Value -DnsSuffix $domain.Value


write-host $("## <DEPLOYMENT STARTED> Deploying VM [",$vm.Value,"inside cluster",$cluster.Value,"on datastore",$datastore.Value,"]") -ForegroundColor Yellow

sleep 10

$pool = $dc.Name+"\"+$cluster1.Value

$deploy1 = New-VM -Name $vm.Value -Template $Template.Value -OSCustomizationSpec $custom.Value -Datastore $datastore.Value -ResourcePool $cluster.Value

if($deploy1) {

write-host $("## <INFO> VM name..........[",$vm.Value,"] with success") -ForegroundColor White
write-host $("## <INFO> Powering ON VM..........[",$vm.Value,"] on cluster",$cluster.Value,".") -ForegroundColor White
write-host $("## <UPDATE> Network card basic settings on VM..........[",$vm.Value) -ForegroundColor Yellow


$setcard = Get-VM -Name "$($vm.Value)" | Get-NetworkAdapter -Name "Network adapter 1" | Set-NetworkAdapter -PortGroup "$($network.Network)" -Confirm:$false
$concard = Get-VM -Name "$($vm.Value)" | Get-NetworkAdapter -Name "Network adapter 1" | Set-NetworkAdapter -StartConnected:$true -Confirm:$false


##$net = New-NetworkAdapter -VM $vm -Type Vmxnet3 -PortGroup $network -StartConnected:$true -Confirm:$false

$memcpu = Set-VM -VM $vm.Value -NumCpu $cpu.value -MemoryGB $mem.Value -Confirm:$false


if($setcard -AND $concard) {

write-host $("## <OK> Setup on VM..........[",$vm.Value,"] proper network group:", $network.Network,".") -ForegroundColor Green
write-host $("## <INFO> Starting VM..........[",$vm.Value,"] on",$cluster.Value,"cluster") -ForegroundColor White



} else { write-host $("## <ERROR> Unable to setup on VM name..........[",$vm.Value,"] network group", $network.Value,".") -ForegroundColor Red }

$movevm = Move-VM -VM $vm.value -Destination $cluster1.Value

if ($movevm) { write-host $("## <OK> Moved VM..........[",$vm.value,"] into folder",$cluster1.value,"with success") -ForegroundColor Green } else {

write-host $("##<ERROR> Unable to move VM..........[",$vm.value," into folder",$cluster1.value,"]") -ForegroundColor Red
}


if ($memcpu) {

write-host $("## <OK> Setup on VM..........[",$vm.Value,"] vcpu:", $cpu.Value,".") -ForegroundColor Green
write-host $("## <OK> Setup on VM..........[",$vm.Value,"] MemoryGB:", $mem.Value,".") -ForegroundColor Green

$start = Start-VM -VM $vm.Value

write-host $("## <INFO> Starting VM..........[",$vm.Value,"] on cluster", $cluster.Value,".") -ForegroundColor White

} else { write-host $("## <ERROR> Unable to setup on VM vcpu:[",$cpu.Value,"] and MemoryGB", $mem.Value,".") -ForegroundColor Red }

if ($start) { write-host $("## <INFO> Powered ON VM..........[",$vm.Value,"] with success") -ForegroundColor White 

While (!$Go) {
   
      $Go = $True
   
      $Tools = Get-VM -Name $vm.Value

     write-host $("## <INFO> Waiting for VMTools to complete customization on..........[",$vm.Value,"] ") -ForegroundColor White

        if ($Tools.ExtensionData.Guest.ToolsRunningStatus -ne "guestToolsRunning") { $Go = $false}
        if ($Tools.ExtensionData.Guest.ToolsRunningStatus -eq "guestToolsRunning") { $Go = $True}
 
      sleep 5
    } 

write-host $("## <INFO> VMTools completed customization on..........[",$vm.Value,"]", $cluster.Value,".") -ForegroundColor White



While (!$OS) {
   
      $OS = $True
   
     
      if((Test-Connection -Cn $vm.Value -BufferSize 16 -Count 4 -ea 0 -quiet)) {

      $netlogon = Get-Service -ComputerName $vm.Value -Name "NetLogon"

      if($netlogon.Name -eq "NetLogon") { 
                
        if ($netlogon.Status -eq "Running") { $OS = $True}
        if ($netlogon.Status -ne "Running") { $OS = $False}
     
      write-host $("## <INFO> Waiting for VM Guest OS customization process to end on..........[",$vm.Value,"] ") -ForegroundColor White
          
      } else { 
      
      write-host $("## <INFO> Waiting for VM Guest OS customization process to end on..........[",$vm.Value,"] ") -ForegroundColor White
      
      $OS = $False } 
     
      } else { $OS = $False

      write-host $("## <INFO> No connection - Waiting for VM Guest OS customization process to end on..........[",$vm.Value,"] ") -ForegroundColor White }
      
      sleep 5
          
    }

write-host $("## <INFO> VM Guest OS customization completed on..........[",$vm.Value,"]") -ForegroundColor White
write-host $("## <DEPLOYMENT COMPLETED> Deployment of Windows VM ..........[",$vm.Value,"] completed with successs.") -ForegroundColor Yellow

} else  {

## $vm = Start-VM VM* | Wait-Tools
## dism /online /enable-feature /featurename:NetFx3 /all /source:\\ADEVWGRE1TSS002\c$\Windows\WinSxS /limitAccess
## Get-WindowsOptionalFeature -Online -FeatureName NetFx3
##Invoke-VMScript -VM VM -ScriptText "dir" -GuestUser administrator-GuestPassword pass2

write-host $("## <ERROR> Unable to power ON VM name..........[",$vm.Value,"]") -ForegroundColor Red
write-host $("## <ERROR> VM name..........[",$vm.Value,"] deployment failure") -ForegroundColor Red

write-host $("## <INFO> Waiting for VMTools to complete customization on..........[",$vm.Value,"]", $cluster.Value,".") -ForegroundColor White


} 

write-host $("## <INFO> Starting task to install IaaS Management Agent..........[",$vm.Value,"]") -ForegroundColor White

sleep 5

### Install & configure required components
if($ap -eq "True") {

write-host $("## <INFO> Starting remote installation of components inside [",$vm.Value,"]") -ForegroundColor White

$cred1 = "$domain\$user"

install $vm.Value $domain.value $cred1 $dpass

} else { write-host $("## <INFO> Skipped remote installation of components inside [",$vm.Value,"]") -ForegroundColor Yellow }

}
}
}


function install ([string]$machine,[string]$user,[string]$pass){

$rcheck = Invoke-VMScript -VM $machine -ScriptText "who" -GuestUser $user -GuestPassword $pass



if ($rcheck) {
write-host $("## <OK> Remote connection established with [",$machine,"]") -ForegroundColor Green
#Invoke-VMScript -VM $machine -ScriptText "dism /online /enable-feature /featurename:NetFx3 /all /source:\\ADEVWGRE1TSS002\c$\Windows\WinSxS /limitAccess" -GuestUser $user -GuestPassword $pass -ScriptType Bat


} else {

write-host $("## <ERROR> Unable to establish remote connection with [",$machine,"]") -ForegroundColor Red
write-host $("## <ERROR> Remote installation aborted inside [",$machine,"]") -ForegroundColor Red

menu;
}




}


function menu {

Write-Host "**************************************************" -ForegroundColor Yellow
Write-Host " Auto deploy Windows machine - choose steps" -ForegroundColor Yellow
Write-Host "**************************************************" -ForegroundColor Yellow
Write-Host "					                               "

Write-Host "[1]  Update json file for windows machine"
Write-Host "[2]  Validate deployment of windows machine"
Write-Host "[3]  Deploy windows machine"
Write-Host "[4]  Re-deploy IaaS agent on windows machine"
Write-host "[0]  Exit"
Write-Host " "
$a = Read-Host "Select 1-4: "
 
Write-Host " "
 
switch ($a) 
    { 

 	0 {
           if($global:DefaultVIServer.Name) { 
           
           $vc = Disconnect-VIServer -Server $global:DefaultVIServer.Name -Confirm:$FALSE
           
           write-host $("## <OK> Disconnected connection with Vcenter:[",$global:DefaultVIServer.Name,"]") -ForegroundColor Yellow
           write-host $("## <OK> Goodbye - have a nice day") -ForegroundColor Yellow

           exit

           } else { 

           write-host $("## <OK> Goodbye - have a nice day") -ForegroundColor Yellow 
           
           exit
           
           }

           }
                 
                   
       1 {
           Write-Host "#####################################################" -ForegroundColor Yellow;
           Write-Host "####     Update json file for machine              ##" -ForegroundColor Yellow;
           Write-Host "#####################################################" -ForegroundColor Yellow;

           update_json


		 menu;
 
          } 

          2 {
           Write-Host "##########################################" -ForegroundColor Yellow;
           Write-Host "#### Validate json file                 ##" -ForegroundColor Yellow;
           Write-Host "##########################################" -ForegroundColor Yellow;
          
          vcs_connect
                 
          menu;
          }
		  
		          
          3 {
           Write-Host "#####################################################" -ForegroundColor Yellow;
           Write-Host "####     Deploy machine using customization        ##" -ForegroundColor Yellow;
           Write-Host "#####################################################" -ForegroundColor Yellow;
          
          
           
         vcs_connect
         deploy
         InstallAgent

        menu;

           }

                   
          4 {
           Write-Host "#####################################################" -ForegroundColor Yellow;
           Write-Host "####    Re-deploy IaaS agent on machine            ##" -ForegroundColor Yellow;
           Write-Host "#####################################################" -ForegroundColor Yellow;
          
                
        InstallAgent
            

        menu;

           }

                              
          default {
          "** Wrong selection **";
	 menu;	         
          }

     }
 }

cls

menu;
           
