﻿#################################################################
## Create Certificates for vRA7.3 Auto Deploy
## Author: Brian Gerrard , ver.0.2, 2017-10-27
#################################################################
## Following corrections by Tomasz Korniluk ver.0.2, 2018-01-04
## - Adjusted directories paths
## - Added invocation folder directory path with test path check
## - Added variable to defined name of csv file
#################################################################

$vmfile = "vm_list.csv"


$wdir = $MyInvocation.MyCommand.Path
$dir = Split-Path $wdir

### CSV file location check

if((Test-Path -Path $dir\$vmfile)) {

write-host "<OK> File $vmfile exists in location $dir\$vmfile" -ForegroundColor Yellow

$info = Import-Csv $dir\$vmfile

} else { write-host "<ERROR> File $vmfile missing in location $dir\$vmfile" -ForegroundColor Red ;exit}


foreach ($row in $info) {

$caServer = $row.caServer
$vraCommon = $row.vraCommon
$vraSAN = $row.vraSAN
$webCommon = $row.webCommon
$webSAN = $row.webSAN
$iaasCommon = $row.iaasCommon
$iaasSAN = $row.iaasSAN
}

#Create Directories

New-Item -ItemType directory -Path $dir\vra
New-Item -ItemType directory -Path $dir\web
New-Item -ItemType directory -Path $dir\iaas

#Copy cfg files

cp dpc.cfg $dir\vra
cp dpc.cfg $dir\web
cp dpc.cfg $dir\iaas

#Update cfg files with subject and common names for the vRA appliance

$commonName = $vraCommon
$subjectName = $vraSAN

Get-Content -Path "$dir\vra\dpc.cfg" | ForEach-Object {$_ -Replace "newcommonName", $commonName -replace "newSubjectName", $subjectName } | Set-Content "$dir\vra\vra.cfg"

#Update cfg files with subject and common names for the IaaS Web

$commonName = $webCommon
$subjectName = $webSAN
Get-Content -Path "$dir\vra\dpc.cfg" | ForEach-Object {$_ -Replace "newcommonName", $commonName -replace "newSubjectName", $subjectName } | Set-Content "$dir\web\web.cfg"

#Update cfg files with subject and common names for IaaS Manager

$commonName = $iaasCommon
$subjectName = $iaasSAN
Get-Content -Path "$dir\vra\dpc.cfg" | ForEach-Object {$_ -Replace "newcommonName", $commonName -replace "newSubjectName", $subjectName } | Set-Content "$dir\iaas\iaas.cfg"

 
# create new original key for vRA appliance

.\openssl.exe req -new -nodes -out $dir\vra\rui.csr -keyout $dir\vra\rui-orig.key -config $dir\vra\vra.cfg 

# create new original key for IaaS Web

.\openssl.exe req -new -nodes -out $dir\web\rui.csr -keyout $dir\web\rui-orig.key -config $dir\web\web.cfg 

# create new original key for IaaS Manager

.\openssl.exe req -new -nodes -out $dir\iaas\rui.csr -keyout $dir\iaas\rui-orig.key -config $dir\iaas\iaas.cfg 


# create new Private key for vRA appliance

.\openssl.exe rsa -in $dir\vra\rui-orig.key -out $dir\vra\rui.key

# create new Private key for IaaS Web

.\openssl.exe rsa -in $dir\web\rui-orig.key -out $dir\web\rui.key

# create new Private key for IaaS Manager

.\openssl.exe rsa -in $dir\iaas\rui-orig.key -out $dir\iaas\rui.key


# Create Temp Directory on CA server

mkdir \\$caServer\c$\vraAutomation
mkdir \\$caServer\c$\vraAutomation\iaas
mkdir \\$caServer\c$\vraAutomation\vra
mkdir \\$caServer\c$\vraAutomation\web

# Copt CSR files to CA server

cp $dir\vra\rui.csr \\$caServer\c$\vraAutomation\vra
cp $dir\iaas\rui.csr \\$caServer\c$\vraAutomation\iaas
cp $dir\web\rui.csr \\$caServer\c$\vraAutomation\web

# Request Certificates in p7b format

Invoke-Command -ComputerName $caServer -FilePath $dir\caRequest.ps1


# copy p7b files back to Terminal Server

cp \\$caServer\c$\vraAutomation\vra\vra.p7b $dir\vra\
cp \\$caServer\c$\vraAutomation\iaas\iaas.p7b $dir\iaas\
cp \\$caServer\c$\vraAutomation\web\web.p7b $dir\web\

# Merge new cert, CA and Subordinate to PEM file for vRA

.\openssl.exe pkcs7 -in $dir\vra\vra.p7b -print_certs -out $dir\vra\vrachain.pem
.\openssl.exe pkcs7 -in $dir\web\web.p7b -print_certs -out $dir\web\webchain.pem
.\openssl.exe pkcs7 -in $dir\iaas\iaas.p7b -print_certs -out $dir\iaas\iaaschain.pem

# Clean up

#Import PEM to CSV

$iaaschain = Get-Content $dir\iaas\iaaschain.pem -Raw
$iaaspk = Get-Content $dir\iaas\rui.key -Raw
$vrachain = Get-Content $dir\vra\vrachain.pem -Raw
$vrapk = Get-Content $dir\vra\rui.key -Raw
$webchain = Get-Content $dir\web\webchain.pem -Raw
$webpk = Get-Content $dir\web\rui.key -Raw

$info.iaasCert = $iaaschain
$info.iaasCertPK = $iaaspk
$info.vraCert = $vrachain
$info.vraCertPK = $vrapk
$info.webCert = $webchain
$info.webCertPK = $webpk

$info | Export-Csv -Path $dir\vm_list.csv 


#openssl pkcs12 -export -in E:\vRA7_Auto_Deploy_Scripts\vra\rui.crt -inkey E:\vRA7_Auto_Deploy_Scripts\vra\rui.key -certfile E:\vRA7_Auto_Deploy_Scripts\Root64.cer -name “rui” -out E:\vRA7_Auto_Deploy_Scripts\vra\rui.pfx 
#openssl pkcs12 -export -in E:\vRA7_Auto_Deploy_Scripts\web\rui.crt -inkey E:\vRA7_Auto_Deploy_Scripts\web\rui.key -certfile E:\vRA7_Auto_Deploy_Scripts\Root64.cer -name “rui” -out E:\vRA7_Auto_Deploy_Scripts\web\rui.pfx