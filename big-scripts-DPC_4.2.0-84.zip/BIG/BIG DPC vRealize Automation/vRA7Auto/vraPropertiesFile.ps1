﻿###################################################
## Update HA Properties for vRA 7 Auto Deploy
## Author: Brian Gerrard , ver.0.1, 2017-10-27
###################################################

$info = Import-Csv D:\vRA7_Auto_Deploy_Scripts\vm_list.csv

foreach ($row in $info) {

$license = $row.license
$ntp = $row.NTP
$serviceAccount = $row.ServiceAcc
$serviceAccountPw = $row.saPw
$ssoPassword = $row.ssoPw
$additionalHosts = $row.additionalHosts
$additionalUsers = $row.additionalHostPw
$additionalHostPw = $row.additionalHostPw
$webHosts = $row.webHosts
$iaasHosts = $row.iaasHosts
$demHosts = $row.demHosts
$vraLb = $row.vraLb
$webLb = $row.webLb
$iaasLb = $row.iaasLb
$sqlHost = $row.sqlHost
$sqlDb = $row.sqlDb
$sqlPassphrase = $row.sqlPassphrase
$agentHosts = $row.agentHosts
$agentName = $row.agentNames
$agentEndpoint = $row.agentEndpoints
$iaasCert = $row.iaasCert
$iaasPk = $row.iaasCertPk
$webCert = $row.webCert
$webPk = $row.webCertPk
$vraCert = $row.vraCert
$vraCertPk = $row.vraCertPk

}

$vraHost2,$vraHost3 = $additionalHosts.Split('')
$webHost1,$webHost2 = $webHosts.Split('')
$iaasHost1,$iaasHost2 = $iaasHosts.Split('')
$demHost1,$demHost2 = $demHosts.Split('')



try {
Write-Host "NSlookup for" $vraHost2 -ErrorAction Stop
[System.Net.DNS]::resolve($vraHost2)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}

#try {
#Write-Host "NSlookup for" $vraHost3
#[System.Net.DNS]::resolve($vraHost3)

#}
#catch {
#Write-Host "address was not found." -ForegroundColor Red
#}

try {
Write-Host "NSlookup for" $webHost1
[System.Net.DNS]::resolve($webHost1)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}

try {
Write-Host "NSlookup for" $webHost2
[System.Net.DNS]::resolve($webHost2)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}

try {
Write-Host "NSlookup for" $iaasHost1
[System.Net.DNS]::resolve($iaasHost1)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}

try {
Write-Host "NSlookup for" $iaasHost2
[System.Net.DNS]::resolve($iaasHost2)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}

try {
Write-Host "NSlookup for" $demHost1
[System.Net.DNS]::resolve($demHost1)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}

try {
Write-Host "NSlookup for" $demHost2
[System.Net.DNS]::resolve($demHost2)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}

try {
Write-Host "NSlookup for" $vraLb
[System.Net.DNS]::resolve($vraLb)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}


try {
Write-Host "NSlookup for" $webLb
[System.Net.DNS]::resolve($webLb)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}

try {
Write-Host "NSlookup for" $iaasLb
[System.Net.DNS]::resolve($iaasLb)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}


try {
Write-Host "NSlookup for" $sqlHost
[System.Net.DNS]::resolve($sqlHost)

}
catch {
Write-Host "address was not found." -ForegroundColor Red
BREAK
}




Get-Content -Path "D:\vRA7_Auto_Deploy_Scripts\hablank_new.properties" | ForEach-Object {$_ -Replace "NewLicense", $license -replace "newNTP", $ntp -replace "newSsoPw", $ssoPassword -replace "ServiceAcc" , $serviceAccount -replace "iaaspw", $serviceAccountPw -replace "addvRA", $additionalHosts -replace "vRA2pw", $additionalHostPw -replace "newWeb" , $webHosts -replace "newIaaS" , $iaasHosts -replace "newDem" , $demHosts -replace "vralb", $vralb -replace "weblb", $webLb -replace "iaaslb", $iaasLb -replace "newSQL" , $sqlHost -replace "newDB", $sqlDb -replace "newpassphrase", $sqlPassphrase -replace "newAgentHosts" , $agentHosts -replace "agentNew", $agentName -replace "newEndpoint", $agentEndpoint -replace "cert_iaas" , $iaasCert -replace "pk_iaas" , $iaasPk -replace "cert_web" , $webCert -replace "pk_web" , $webPk -replace "cert_vra" , $vraCert -replace "pk_vra" ,$vraCertPk } | Set-Content "D:\vRA7_Auto_Deploy_Scripts\ha.properties"

Write-Host ("Successfully populated HA.Properties. Please check and relpace in /usr/lib/vcac/tools/install on vRA appliance") -ForegroundColor Green