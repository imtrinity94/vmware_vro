﻿###################################################
## Deploy vRA 7 appliance based on input json file
## Author: Tomasz Korniluk , ver.0.3, 2017-11-08
###################################################
##
## 
## Base parameters #####################################

$workdir = $MyInvocation.MyCommand.Path
$dir = Split-Path $workdir
$json_file = "vro.json"
$verb_error1 = "Value is empty!"
$verb_error2 = "Wrong value used"
$status = "/disabled - json file validation required/"
$color_up = "Yellow"
$color_ok= "Green"
$color_error= "Red"
$color="Gray"
$defxml= "default.xml"
$valid="false"
$vm_prefix=""



function Date ($set) {

switch ($set) 
    { 

 	1 {
           Get-Date -UFormat "%d_%m_%y_%H"
           } 
           
         2 {
           Get-Date -UFormat "%d_%m_%y"      
           }   
             
         3 {
          Get-Date -UFormat "%d_%m_%y_%H_%M"|Out-string      
           } 
              
           4 {
          Get-Date -UFormat "%d-%m-%Y %H:%M"
           } 
           
default {
         Get-Date -UFormat "%d_%m_%y"|Out-string;
	exit	         
          }
          }

}




function vcs_connect {

$date = Date 4

## Load VMware modules into powershell session

## Load json file

if((Test-Path -Path $json_file)) {

$json = Get-Content $json_file | Out-String | ConvertFrom-Json

$base = $json.Base

$vcenter = $json.Base | Where{$_.Key -eq 'Vcenter'}


$vm_modules = Get-Module -ListAvailable VMware* | Import-Module | Out-Null
$ls_modules =  Get-Module -ListAvailable VMware*

$vc = Connect-VIServer -Server $vcenter.Value

if ($vc) {  

write-host $("##<$date><OK> Established connection with Vcenter:[",$vc.Name,"]") -ForegroundColor Yellow

$vcenter1 = $vc.Name

$vm_prefix = $vcenter1.substring(0,$vcenter1.Length-6)


write-host $("##<$date><INFO> Suggested VM Name prefix:[",$vm_prefix,"]") -ForegroundColor White


} else {

write-host $("##<$date><ERROR> Unable to establish connection with Vcenter:[",$vcenter1,"]") -ForegroundColor Red

menu;

 }

if(!$vm_modules) { 


foreach ($module in $ls_modules) {

write-host $("##<$date><OK> Module ",$module.Name," is available") -ForegroundColor Green


} 

} else { 

write-host $("##<$date><ERROR> Unable to load VMware modules - please check powerCLI installation") -ForegroundColor Red

menu;

}

validate $vm_prefix

} else { 

write-host $("##<$date><ERROR> Unable to load json file - please check json file name") -ForegroundColor Red

}

}



function update_json {

$date = Date 4

if((Test-Path -Path $json_file)) {

$json = Get-Content $json_file | Out-String | ConvertFrom-Json

## Load property mapping section from json file

$properties1 = $json.PropertyMapping

## Load Network properties from json file

$net_name = $json.NetworkMapping

$base = $json.Base

$vmname = $json.Name
$power = $json.PowerOn
$disk = $json.DiskProvisioning
$ipalloc = $json.IPAllocationPolicy
$ipprot = $json.IPProtocol
$inject = $json.InjectOvfEnv
$waitip = $json.WaitForIP


foreach ($Keys in $properties1) {

$rollback = $Keys.Value

write-host $("##<$date><UPDATE>",$Keys.Key,"....< current value:",$Keys.Value,">") -ForegroundColor Yellow

$input = read-host $("##<$date><UPDATE> New value [",$Keys.Value,"]") 

$Keys.Value = $input

if($input -eq "" -OR $input -eq " ") { 

write-host $("##<$date><NO UPDATE>",$Keys.Key,"....< use current value:",$rollback,">") -ForegroundColor Green

$Keys.Value = $rollback

} else  { 

$json | ConvertTo-JSON | set-content $json_file

if($json) { write-host $("##<$date><UPDATED KEY WITH SUCCESS>",$Keys.Key,"....< with value:",$Keys.Value,">") -ForegroundColor Yellow } else { 
write-host $("##<$date><ERROR TO UPDATE KEY>",$Keys.Key,"....< with value:",$Keys.Value,">") -ForegroundColor Red } 

}

}

foreach ($base1 in $base) {

$rollback2 = $base1.Value

write-host $("##<$date><UPDATE>",$base1.Key,"....< current value:",$base1.Value,">") -ForegroundColor Yellow

$input2 = read-host $("##<$date><UPDATE> New value [",$base1.Value,"]") 

$base1.Value = $input2

if($input2 -eq "" -OR $input2 -eq " ") { 

write-host $("##<$date><NO UPDATE>",$base1.Key,"....< use current value:",$rollback2,">") -ForegroundColor Green

$base1.Value = $rollback2

} else  { 

$json | ConvertTo-JSON | set-content $json_file

if($json) { write-host $("##<$date><UPDATED KEY WITH SUCCESS>",$base1.Key,"....< with value:",$base1.Value,">") -ForegroundColor Yellow } else { 
write-host $("##<$date><ERROR TO UPDATE KEY>",$base1.Key,"....< with value:",$base1.Value,">") -ForegroundColor Red } 

}

}


} else { 

write-host $("##<$date><ERROR> Json file: $json_file.......[Missing file]") -ForegroundColor Red

}

### Updating baseline section

write-host $("##<$date><UPDATE> VM Name:....< current value:",$vmname,">") -ForegroundColor Yellow
write-host $("##<$date><INFO> Suggested VM Name:.............",$vm_prefix,">") -ForegroundColor White
$inputvm = read-host $("##<$date><UPDATE> VM Name new value [",$vmname,"]") 

write-host $("##<$date><UPDATE> Disk type:....< current value:",$disk,">") -ForegroundColor Yellow

$inputdisk = read-host $("##<$date><UPDATE> Disk type name new value [",$disk,"]") 


if($inputvm -eq "" -OR $inputvm -eq " ") { 


write-host $("##<$date><NO UPDATE> VM name....< use current value:",$vmname,">") -ForegroundColor Green


} else {
$vmname = $inputvm

write-host $("##<$date><UPDATED KEY WITH SUCCESS> VM name with new value:",$vmname,">") -ForegroundColor Yellow
 }


if($inputdisk -eq "" -OR $inputdisk -eq " " -OR $inputdisk -eq "thick" -OR $inputdisk -eq "thin") { 


write-host $("##<$date><NO UPDATE> Disk type....< use current value:",$disk,">") -ForegroundColor Green


} else {
$disk = $inputdisk

write-host $("##<$date><UPDATED KEY WITH SUCCESS> Disk type with new value:",$disk,">") -ForegroundColor Yellow
 }




### Updating NetworkingMapping Section

write-host $("##<$date><UPDATE> Network name:....< current value:",$net_name.Name,">") -ForegroundColor Yellow

$rollback1 = $net_name.Name

$input = read-host $("##<$date><UPDATE> Network name new value [",$net_name.Name,"]") 

write-host $("##<$date><UPDATE> Network group:....< current value:",$net_name.Network,">") -ForegroundColor Yellow

$input1 = read-host $("##<$date><UPDATE> Network group name new value [",$net_name.Network,"]") 


if($input -eq "" -OR $input -eq " ") { 


write-host $("##<$date><NO UPDATE> Network name....< use current value:",$net_name.Name,">") -ForegroundColor Green


} else {
$net_name.Name = $input
write-host $("##<$date><UPDATED KEY WITH SUCCESS> Network name with new value:",$net_name.Name,">") -ForegroundColor Yellow
 }


if($input1 -eq "" -OR $input1 -eq " ") { 

write-host $("##<$date><NO UPDATE> Network group name....< use current value:",$net_name.Network,">") -ForegroundColor Green



} else { 

$net_name.Network = $input1

write-host $("##<$date><UPDATED KEY WITH SUCCESS> Network group name with new value:",$net_name.Network,">") -ForegroundColor Yellow

}


$json | ConvertTo-JSON | set-content $json_file

if($json) { write-host $("##<$date><UPDATED JSON FILE: $json_file SUCCESSFULLY> ################") -ForegroundColor Yellow } 
else { 

write-host $("##<$date><ERROR> Json file: $json_file.......[Missing file]") -ForegroundColor Red


}



}


function convert2xml ([string]$filejson,[string]$filexml) {

$date = Date 4

if((Test-Path -Path $filejson)) { 

$json = Get-Content $filejson | Out-String | ConvertFrom-Json

if (!$json) { write-host $("##<$date><ERROR> Missing file",$filejson,"") -ForegroundColor Red } else {

$input = read-host $("##<$date><CONVERT> Use XML default name:[",$filexml,"] or provide new xml name:") 


if($input -eq "") { write-host $("##<$date><CONVERT> Converting file",$filejson,"using default filename:",$filexml,"") -ForegroundColor Yellow

$json | Export-Clixml $filexml

} else {

write-host $("##<$date><CONVERT> Converting file",$filejson,"to file ",$input,"") -ForegroundColor Yellow

$json | Export-Clixml $input

}


}  

} else { write-host $("##<$date><ERROR> Missing file",$filejson,"") -ForegroundColor Red  }
menu;

}



function validate ([string]$v) {

$date = Date 4

if((Test-Path -Path $json_file)) { 

##Load json content
$json = Get-Content $json_file | Out-String | ConvertFrom-Json

## Checking Property Mappings

$properties = $json.PropertyMapping
$base = $json.Base
$ov = $json.Base | Where{$_.Key -eq 'OVA'}

## Checking Network Mappings
$networkmap = $json.NetworkMapping

## Checking rest main settings
$power = $json.PowerOn
$disk = $json.DiskProvisioning
$ipalloc = $json.IPAllocationPolicy
$ipprot = $json.IPProtocol
$inject = $json.InjectOvfEnv
$waitip = $json.WaitForIP
$vmname = $json.PropertyMapping | Where{$_.Key -eq 'vami.Hostname'}

foreach ($Key in $properties) {

if($Key.Value -eq "" -OR $Key.Value -eq " ") { #write-host $("## <ERROR>",$Key.Key) , $verb_error1 -ForegroundColor red 
write-host $("##<$date><ERROR>",$Key.Key,"..........[",$verb_error1,"]") -ForegroundColor Red

} else {

write-host $("##<$date><OK>",$Key.Key,"..........[",$Key.Value,"]") -ForegroundColor Green

}
}


foreach ($Key2 in $base) {

if($Key2.Value -eq "" -OR $Key2.Value -eq " ") { 
write-host $("##<$date><ERROR>",$Key2.Key,"..........[",$verb_error1,"]") -ForegroundColor Red

$base1 = "True"

} else {

write-host $("##<$date><OK>",$Key2.Key,"..........[",$Key2.Value,"]") -ForegroundColor Green

}
}


foreach ($Name in $networkmap) {

if($Name.Network -eq "" -OR $Name.Network -eq " ") { #write-host $("## <ERROR>",$Key.Key) , $verb_error1 -ForegroundColor red 

$Name1 = "true"

write-host $("##<$date><ERROR>",$Name.Name,"..........[",$verb_error1,"]") -ForegroundColor Red

} else {

write-host $("##<$date><OK>",$Name.Name,"..........[",$Name.Network,"]") -ForegroundColor Green


}
}

$portgroup = Get-VDPortgroup -Name "$($Name.Network)"

if($Name.Network -eq $portgroup.Name) {

write-host $("##<$date><OK> Port group exists for ",$Name.Name,"..........[",$Name.Network,"]") -ForegroundColor Green

} else { 

write-host $("##<$date><ERROR>Port group not found..........[",$Name.Network,"]") -ForegroundColor Red

$pg1 = "True"

}

if((Test-Path -Path $ov.Value)) { 

write-host $("##<$date><OK>OVA file exists in location..........[",$ov.Value,"]") -ForegroundColor Green } else {

write-host $("##<$date><ERROR>OVA file missing in location..........[",$ov.Value,"]") -ForegroundColor Red
$ov1 = "true" 
}

if($power -eq "") { write-host $("##<$date><ERROR> PowerOn,..........[",$verb_error1,"]") -ForegroundColor Red

$power1 = "true"

} else {

write-host $("##<$date><OK> PowerOn..........[",$power,"]") -ForegroundColor Green

}

if($disk -ne "thin") { write-host $("##<$date><ERROR> DiskProvisioning,..........[",$verb_error2,": use thin]") -ForegroundColor Red

$disk1 = "true"

} else {

write-host $("##<$date><OK> DiskProvisioning..........[",$disk,"]") -ForegroundColor Green

}

if($ipalloc -ne "fixedPolicy") { write-host $("##<$date><ERROR> IPAllocationPolicy,..........[",$verb_error2,"use fixedPolicy]") -ForegroundColor Red

$ipalloc1 = "true"

} else {

write-host $("##<$date><OK> IPAllocationPolicy..........[",$ipalloc,"]") -ForegroundColor Green

}

if($ipprot -ne "IPv4") { write-host $("##<$date><ERROR> IPProtocol,..........[",$verb_error1,"use IPv4 protocol]") -ForegroundColor Red

$ipprot1 = "true"

} else {

write-host $("##<$date><OK> IPProtocol..........[",$ipprot,"]") -ForegroundColor Green

}


if($waitip -eq "") { write-host $("##<$date><ERROR> WaitForIP,..........[",$verb_error1,"]") -ForegroundColor Red

$waitip1 = "true"

} else {

write-host $("##<$date><OK> WaitForIP..........[",$waitip,"]") -ForegroundColor Green

}

if($vmname.value -notlike "$v*") { write-host $("##<$date><ERROR> VM name ..........[",$verb_error2,",use prefix",$v,"]") -ForegroundColor Red

$vmname1 = "true"

menu;

} else {

write-host $("##<$date><OK> VM name..........[",$vmname.value,"]") -ForegroundColor Green

}


} else { 

write-host $("##<$date><ERROR> Json file: $json_file.......[Missing file]") -ForegroundColor Red


}

if($vmname1 -eq "true" -OR $Name1 -eq "true" -OR $disk1 -eq "true" -OR $ipprot1 -eq "true" -OR $base1 -eq "True" -OR $ov1 -eq "True" -OR $pg1 -eq "True") { 

write-host $("##<$date><ERROR> Validation failed - make sure to update missing above values") -ForegroundColor Red

}  else { write-host $("##<$date><OK> Validation passed for json file: $json_file [READY FOR DEPLOYMENT]") -ForegroundColor Yellow


}

}


function deploy {

$date = Date 4

$json = Get-Content $json_file | Out-String | ConvertFrom-Json

$prop = $json.PropertyMapping
$base = $json.BaseSettings
$power = $json.PowerOn
$disk = $json.DiskProvisioning
$ipalloc = $json.IPAllocationPolicy
$ipprot = $json.IPProtocol



#### Extract OVFConfig variables from json
$vmname2 = $json.PropertyMapping | Where{$_.Key -eq 'vami.hostname'}
$vip = $json.PropertyMapping | Where{$_.Key -eq 'vami.ip0.VMware_vRealize_Orchestrator_Appliance'} 
$vdomain = $json.PropertyMapping | Where{$_.Key -eq 'vami.domain.VMware_vRealize_Orchestrator_Appliance'}
$vsearch = $json.PropertyMapping | Where{$_.Key -eq 'vami.searchpath.VMware_vRealize_Orchestrator_Appliance'}
$vdns = $json.PropertyMapping | Where{$_.Key -eq 'vami.DNS.VMware_vRealize_Orchestrator_Appliance'}
$vmask = $json.PropertyMapping | Where{$_.Key -eq 'vami.netmask0.VMware_vRealize_Orchestrator_Appliance'}
$vgateway = $json.PropertyMapping | Where{$_.Key -eq 'vami.gateway.VMware_vRealize_Orchestrator_Appliance'}
$vpass = $json.PropertyMapping | Where{$_.Key -eq 'varoot-password'}
$vssh = $json.PropertyMapping | Where{$_.Key -eq 'va-ssh-enabled'}
$vnetwork = $json.NetworkMapping | Where{$_.Name -eq 'Network 1'}
$cluster = $json.Base | Where{$_.Key -eq 'Cluster'}
$dstore = $json.Base | Where{$_.Key -eq 'Datastore'}
$folder = $json.Base | Where{$_.Key -eq 'Folder'}
$ova = $json.Base | Where{$_.Key -eq 'OVA'}

## Load OVFconfig

$ovfcon1 = Get-OvfConfiguration $ova.value

$ovfcon1.vami.VMware_vRealize_Orchestrator_Appliance.ip0.value = $vip.value
$ovfcon1.vami.VMware_vRealize_Orchestrator_Appliance.domain.value = $vdomain.value
$ovfcon1.vami.VMware_vRealize_Orchestrator_Appliance.searchpath.value = $vsearch.value
$ovfcon1.vami.VMware_vRealize_Orchestrator_Appliance.DNS.value = $vdns.value
$ovfcon1.vami.VMware_vRealize_Orchestrator_Appliance.netmask0.value = $vmask.value
$ovfcon1.vami.VMware_vRealize_Orchestrator_Appliance.gateway.value = $vgateway.value
$ovfcon1.IpAssignment.IpProtocol.value = $json.IPProtocol
$ovfcon1.NetworkMapping.Network_1.value = $vnetwork.Network
$ovfcon1.Common.varoot_password.value = $vpass.value
$ovfcon1.Common.va_ssh_enabled.value = $vssh.value
$vfqdn = $vmname2.Value+"."+$vdomain.value
$ovfcon1.Common.vami.hostname.value = $vfqdn
$ntp = $vdns.value
$ntp1,$ntp2 =$ntp.split(',')


### Selecting proper target host

$vmhost = Get-Cluster $($cluster.value) | Get-VMHost | Sort MemoryGB | Select -first 1

write-host $("##<$date><DEPLOYMENT PRE-CHECK> Checking if VM with name",$vmname2.value,"inside environment is free") -ForegroundColor Yellow

$check1 = Get-VM | Select Name | Where {$_.Name -eq $vmname2.value}

if($check1.Name -eq $vmname2.value) {

 write-host $("##<$date><ERROR>VM with name [",$vmname2.value,"]already exist inside environment !") -ForegroundColor Red
 write-host $("##<$date><ERROR>Deployment aborted for VM [",$vmname2.value,"]") -ForegroundColor Red

 } else {

write-host $("##<$date><DEPLOYMENT STARTED> Deploying VM [",$vmname2.value,"inside cluster",$cluster.value,"on datastore",$dstore.value ,"]") -ForegroundColor Yellow

$deploy = Import-VApp -Source $ova.value -OvfConfiguration $ovfcon1 -VMHost $vmhost -Name $($vmname2.value) -DiskStorageFormat $disk -Datastore $($dstore.value) -Location $($cluster.value)


if($deploy) {

write-host $("##<$date><INFO> VM name..........[",$vmname2.value,"] with success") -ForegroundColor White
write-host $("##<$date><INFO> Powering ON VM..........[",$vmname2.value,"] on cluster",$cluster.value,".") -ForegroundColor White

$start = Start-VM -VM $vmname2.value

if ($start) { write-host $("##<$date><OK> Powered ON VM..........[",$vmname2.value,"] with success") -ForegroundColor Yellow

$movevm = Move-VM -VM $vmname2.value -Destination $folder.value }

else  {

write-host $("##<$date><ERROR> Unable to power ON VM name..........[",$vmname2.value,"]") -ForegroundColor Red

} 

if ($movevm) { write-host $("##<$date><OK> Moved VM into folder..........[",$folder.value,"] with success") -ForegroundColor Yellow } else {

write-host $("##<$date><ERROR> Unable to move VM..........[",$vmname2.value," into folder",$folder,"]") -ForegroundColor Red

} 



While (!$Go) {
   
      $Go = $True
   
      $Tools = Get-VM -Name $vmname2.value

     write-host $("##<$date><INFO> Waiting for VMTools initialization on..........[",$vmname2.value,"] ") -ForegroundColor White

        if ($Tools.ExtensionData.Guest.ToolsStatus -ne "toolsOk") { $Go = $false}
        if ($Tools.ExtensionData.Guest.ToolsStatus -eq "toolsOk") { $Go = $True}
 
      sleep 5
    } 

write-host $("##<$date><OK> VMTools initialized with success on..........[",$vmname2.value,"]") -ForegroundColor Yellow

write-host $("##<$date><INFO> Creating record A for VM..........[",$vmname2.value,"] on DNS server $ntp1") -ForegroundColor White

Add-DnsServerResourceRecordA -Name $vmname2.value -IPv4Address $vip.value -ZoneName $vdomain.value -ComputerName $ntp1 -CreatePtr

sleep 2

$dnsrecord = Get-DnsServerResourceRecord -Name $vmname2.value -ZoneName $vdomain.value -ComputerName $ntp1

write-host $dnsrecord.Hostname
write-host $dnsrecord


if($dnsrecord) { 

write-host $("##<$date><UPDATE> DNS record A for",$dnsrecord.Hostname,"created with successs o DNS server: $ntp1 ") -ForegroundColor Green

} else { write-host $("##<$date><ERROR> Unable to create record A for VM [",$vmname2.value,"inside DNS server",$ntp1,"]") -ForegroundColor Red }


write-host $("##<$date><INFO> Checking vco-configurator service status...") -ForegroundColor White

sleep 25

Invoke-VMScript -VM $($vmname2.value) -ScriptText "service vco-configurator status" -GuestUser root -GuestPassword $vpass.value

write-host $("##<$date><UPDATE> Updating NTP settings to use servers:[ $ntp1 $ntp2 ]") -ForegroundColor Green

Invoke-VMScript -VM $($vmname2.value) -ScriptText "/opt/vmware/share/vami/custom-services/bin/vami ntp use-ntp $ntp1 $ntp2" -GuestUser root -GuestPassword $vpass.value

write-host $("##<$date><OK> Deployment of appliance",$vmname2.value," completed with success]") -ForegroundColor Yellow

} else { 

write-host $("##<$date><ERROR> VM name..........[",$vmname2.value,"] deployment failure") -ForegroundColor Red

}
}
}


function gen_ssl {

$date = Date 4

$json = Get-Content $json_file | Out-String | ConvertFrom-Json
$vmname2 = $json.PropertyMapping | Where{$_.Key -eq 'vami.hostname'}
$vdomain = $json.PropertyMapping | Where{$_.Key -eq 'vami.domain.VMware_vRealize_Orchestrator_Appliance'}
$on = $json.SSL
$vcenter = $json.Base | Where{$_.Key -eq 'Vcenter'}

if($on -eq "True") {

write-host $("##<$date><INFO> SSL generation initiated for VM ..........[",$vmname2.value,"]") -ForegroundColor White

$vm_modules = Get-Module -ListAvailable VMware* | Import-Module | Out-Null
$ls_modules =  Get-Module -ListAvailable VMware*

$vcenter1 = $vcenter.Value

$vm_prefix = $vcenter1.substring(0,$vcenter1.Length-11)

$loc = $vcenter1.substring($vcenter1.Length-10,4)

$vc = Connect-VIServer -Server $vcenter1

$RICA = $($vm_prefix)+"W"+$($loc)

$ICA = $RICA+"ICA001"

write-host $ICA

write-host $("## <UPDATE> Provide domain ",$vdomain.value,"account credentials to establish connection with ICA: $ICA>") -ForegroundColor Yellow

$suser = Read-Host -Prompt "## <UPDATE> Domain account user name:"
$spass = Read-Host -Prompt "## <UPDATE> Domain account user password:" -AsSecureString

$decryptp = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($spass)
$dpass = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($decryptp)


$VMICA = Get-VM -Name $($ICA)

$dom = $($vdomain.value)+"\"+$($suser)

write-host $dom

$CAcert = 'certutil.exe -CA.cert test2'

Invoke-VMScript -VM $($ICA) -ScriptText "$CAcert" -GuestUser $dom -GuestPassword $dpass -ScriptType Bat
Invoke-VMScript -VM $($ICA) -ScriptText "who" -GuestUser $dom -GuestPassword $dpass


} else { 

write-host $("##<$date><INFO> SSL generation set to False ..........[",$vmname2.value,"step skipped]") -ForegroundColor Yellow

}

}




function menu {

Write-Host "**************************************************" -ForegroundColor Yellow
Write-Host " Auto deploy of vRO7 appliance - choose steps" -ForegroundColor Yellow
Write-Host "**************************************************" -ForegroundColor Yellow
Write-Host "					                               "

Write-Host "[1]  Update json file for vRO7 appliance"
Write-Host "[2]  Validate deployment of vRO7 appliance"
Write-Host "[3]  Deploy vRO7 appliance"
#Write-Host "[6]  Generate SSL for vRO"
#Write-Host "[7]  Convert json file $json_file to xml"
Write-host "[0]  Exit"
Write-Host " "
$a = Read-Host "Select 1-3: "
 
Write-Host " "
 
switch ($a) 
    { 

 	0 {
           Write-Host "** Goodbye **";
           exit
           } 

                      
        1 {
           Write-Host "#####################################################" -ForegroundColor Yellow;
           Write-Host "####     Update json file for vRO7 appliance       ##" -ForegroundColor Yellow;
           Write-Host "#####################################################" -ForegroundColor Yellow;

           update_json;


			menu;
 
          } 
		  
		 2 {
            
           Write-Host "#####################################################" -ForegroundColor Yellow;
           Write-Host "####   Validated deployment of vRO7 appliance      ##" -ForegroundColor Yellow;
           Write-Host "#####################################################" -ForegroundColor Yellow;
          
          
           
         vcs_connect
       

          menu;

           }
           
         3 {
           Write-Host "#####################################################" -ForegroundColor Yellow;
           Write-Host "####     Deploy vRO7 appliance using json file     ##" -ForegroundColor Yellow;
           Write-Host "#####################################################" -ForegroundColor Yellow;
          
          
           
         vcs_connect
         deploy

        menu;

           }

                            
          default {
          "** Wrong selection **";
	 menu;	         
          }

     }
 }

cls

menu;
           
