#DPC Hyperconverged config script (Adapted from DDC Config Script v0.9)
#v0.3 03-05-2017
#Author(s): Original - Krzysztof Hermanowski. - Modified Alec Dunn/Piotr Lewandowski

# 2017-05-03 � Added additional VM folders to be created on install.  Added additional / aligned with LLD Resource pools. (Alec Dunn)
#2017-11-20 - Adopted for initoal DPC 4.0 (Jarek Gajewski)
#Features:
#Creates datacenter object
#Creates two clusters and configures them
#Creates 4 distributed switches and configures them
#Creates 4 port groups for MGMT VMK, 3 for CMP MGMT and 1 portgroup for each NSX switch
#Creates VM and Templates folder structure
#Creates resource pools
#Sets EVC on Ivy Bridge generation

#<VARIABLES GO IN THIS SECTION---
#please ensure names match naming convention

#Change podType, CCode, Location and vCenter address
#POD Type
# DDC - HyperConverged
# EPC - Converged
# BXP - Bull Extreme Perfromance

$podType="DDC"

#Customer Code (i.e. DEV for Development environment)
$CCode = "DEV"

#Location Code (i.e. GRE for Grenoble)
$LCode = "GRU"
########
$vcenter="10.128.0.74"

#End of changes

$datacenter= "$CCode" +"$LCode"+"001"
$clustermgt="$CCode" + "C" + "$LCode"+"MGT001"
$clustercmp="$CCode" +"C" + "$LCode" +"CMP001"

#Compute cluster vDS and Port Groups
$vdsvmkcmp="$CCode"+"N"+"$LCode" + "0VSCMPVMK01"

$pgcmpmgt="$CCode" + "N" + "$LCode" + "0PGCMPMGT0020"
$vlancmpmgt=20
$pgcmpsto="$CCode" + "N" + "$LCode" + "0PGCMPSTO0023"
$vlancmpsto=23
$pgcmpvmo="$CCode" + "N" + "$LCode" + "0PGCMPvMO0022"
$vlancmpvmo=22
$pgcmpbck="$CCode" + "N" + "$LCode" + "0PGCMPBCK0026"
$vlancmpbck=26
$pgcmprep="$CCode" + "N" + "$LCode" + "0PGCMPREP0024"
$vlancmprep=24
$pgcmpint="$CCode" + "N" + "$LCode" + "0PGCMPINT0031"
$vlancmpint=31



#MGT cluster vDS and PG
$vdsvmkmgt="$CCode" + "N" + "$LCode" + "0VSMGTVMK01"

#MGT ESXi Management
$pgmgtmgt="$CCode" + "N" + "$LCode" + "0PGMGTMGT0020"
$vlanmgtmgt=20
#MGT Storage
$pgmgtsto="$CCode" + "N" + "$LCode" +"0PGMGTSTO0023"
$vlanmgtsto=23
#MGT POD Management
$pgmgttol="$CCode" + "N" + "$LCode" +"0PGMGTPOD0030"
$vlanmgttol=30
#MGT Interconnect
$pgmgtint="$CCode" + "N" + "$LCode" +"0PGMGTINT0031"
$vlanmgtint=31

#MGT vmotion
$pgmgtvmo="$CCode" + "N" + "$LCode" +"0PGMGTvMO0022"
$vlanmgtvmo=22
#MGT backup
$pgmgtbck="$CCode" + "N" + "$LCode" +"0PGMGTBCK0026"
$vlanmgtbck=26
#MGT Replication
$pgmgtrep="$CCode" + "N" + "$LCode" +"0PGMGTREP0024"
$vlanmgtrep=24


#Customer WAN ISO
$pgmgtwan = "$CCode" + "N" + "$LCode" + "0PGMGTWAN0033"
$vlanmgtwan=33 


$vdsnsxcmp="$CCode" + "N" + "$LCode" +"0VSCMPNSX01"
$vdsnsxmgt="$CCode" + "N" + "$LCode" +"0VSMGTNSX01"
#CHANGE THIS SECTION--->


#add-pssnapin vmware.vimautomation.core

if ( (Get-Module -Name VMware.VimAutomation.Core -ErrorAction SilentlyContinue) -eq $null )
{
Add-PSsnapin VMware.VimAutomation.Core
}

#### Load modules
# Add VMWare module path to PSModulePath env variable
#Save the current value in the $p variable.
$p = [Environment]::GetEnvironmentVariable("PSModulePath")
#Add the new path to the $p variable. Begin with a semi-colon separator.
$p += ";" + $powerCLIModulesPath
#Add the paths in $p to the PSModulePath value.
[Environment]::SetEnvironmentVariable("PSModulePath",$p)
if ( (Get-Module -Name VMware.VimAutomation.Vds -ErrorAction SilentlyContinue) -eq $null ) {
    Import-Module VMware.VimAutomation.Vds
}


Echo "Please enter vCenter server root password in the displayed window"

#connect to the vCenter server
connect-viserver $vcenter

pause

If ($podType -eq "EPC") {

#create datacenter 
$folder=get-folder -norecursion
new-datacenter -Name $datacenter -Location $folder

#create clusters
New-Cluster -Location $datacenter -Name $clustermgt -HAEnabled -HAIsolationResponse DoNothing -VMSwapfilePolicy WithVM -DRSenabled -DrsAutomationLevel FullyAutomated -EVCMode intel-ivybridge
New-Cluster -Location $datacenter -Name $clustercmp -HAEnabled -HAIsolationResponse DoNothing -VMSwapfilePolicy WithVM -DRSenabled -DrsAutomationLevel FullyAutomated -EVCMode intel-ivybridge
} else {
Get-Cluster -Name $clustermgt | Set-Cluster -HAIsolationResponse DoNothing -VMSwapfilePolicy WithVM -DRSAutomationLevel FullyAutomated -EVCMode intel-ivybridge
New-Cluster -Location $datacenter -Name $clustercmp -HAEnabled -HAIsolationResponse DoNothing -VMSwapfilePolicy WithVM -DRSenabled -DrsAutomationLevel FullyAutomated -EVCMode intel-ivybridge
}

#create vDS's
#port allocation will be set to ELASTIC by default on newly created PortGroups

#VMK COMPUTE
New-VDSwitch -Name $vdsvmkcmp -Location $datacenter -LinkDiscoveryProtocol "LLDP" -LinkDiscoveryProtocolOperation "Both" -MaxPorts 2147483647 -Version "6.5.0" -MTU 9000 -NumUplinkPorts 2
$VDSwitch = Get-VDSwitch -Name $vdsvmkcmp
$VDSwitch.ExtensionData.EnableNetworkResourceManagement($true)
New-VDPortgroup -VDSwitch $vdsvmkcmp -Name $pgcmpmgt  -NumPorts 256 -VlanId $vlancmpmgt -PortBinding Ephemeral
Get-VDPortgroup $pgcmpmgt | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink1 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink2 

New-VDPortgroup -VDSwitch $vdsvmkcmp -Name $pgcmpsto  -NumPorts 8 -VlanId $vlancmpsto -PortBinding Static
Get-VDPortgroup $pgcmpsto | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink2 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink1 

New-VDPortgroup -VDSwitch $vdsvmkcmp -Name $pgcmpvmo  -NumPorts 8 -VlanId $vlancmpvmo -PortBinding Static
Get-VDPortgroup $pgcmpvmo | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink1 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink2 

New-VDPortgroup -VDSwitch $vdsvmkcmp -Name $pgcmpbck  -NumPorts 8 -VlanId $vlancmpbck -PortBinding Static
Get-VDPortgroup $pgcmpbck | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink2 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink1 

New-VDPortgroup -VDSwitch $vdsvmkcmp -Name $pgcmprep  -NumPorts 8 -VlanId $vlancmprep -PortBinding Static
Get-VDPortgroup $pgcmprep | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink2 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink1 

New-VDPortgroup -VDSwitch $vdsvmkcmp -Name $pgcmpint  -NumPorts 8 -VlanId $vlancmpint -PortBinding Static
Get-VDPortgroup $pgcmpint | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink2 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink1 


#VMK Management
New-VDSwitch -Name $vdsvmkmgt -Location $datacenter -LinkDiscoveryProtocol "LLDP" -LinkDiscoveryProtocolOperation "Both" -MaxPorts 2147483647 -Version "6.5.0" -MTU 9000 -NumUplinkPorts 2 
$VDSwitch = Get-VDSwitch -Name $vdsvmkmgt
$VDSwitch.ExtensionData.EnableNetworkResourceManagement($true)

New-VDPortgroup -VDSwitch $vdsvmkmgt -Name $pgmgtmgt  -NumPorts 256 -VlanId $vlanmgtmgt -PortBinding Ephemeral
Get-VDPortgroup $pgmgtmgt | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink1 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink2 

New-VDPortgroup -VDSwitch $vdsvmkmgt -Name $pgmgtsto  -NumPorts 8 -VlanId $vlanmgtsto -PortBinding Static
Get-VDPortgroup $pgmgtsto | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink2 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink1 

New-VDPortgroup -VDSwitch $vdsvmkmgt -Name $pgmgttol  -NumPorts 265 -VlanId $vlanmgttol -PortBinding Ephemeral
Get-VDPortgroup $pgmgttol | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink1 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink2 

New-VDPortgroup -VDSwitch $vdsvmkmgt -Name $pgmgtvmo  -NumPorts 8 -VlanId $vlanmgtvmo -PortBinding Static
Get-VDPortgroup $pgmgtvmo | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink1 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink2 

New-VDPortgroup -VDSwitch $vdsvmkmgt -Name $pgmgtint  -NumPorts 8 -VlanId $vlanmgtint -PortBinding Static
Get-VDPortgroup $pgmgtint | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink1 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink2 

New-VDPortgroup -VDSwitch $vdsvmkmgt -Name $pgmgtbck  -NumPorts 8 -VlanId $vlanmgtbck -PortBinding Static
Get-VDPortgroup $pgmgtbck | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink2 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink1 

New-VDPortgroup -VDSwitch $vdsvmkmgt -Name $pgmgtrep  -NumPorts 8 -VlanId $vlanmgtrep -PortBinding Static
Get-VDPortgroup $pgmgtrep | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink2 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink1 

New-VDPortgroup -VDSwitch $vdsvmkmgt -Name $pgmgtwan  -NumPorts 8 -VlanId $vlanmgtwan -PortBinding Static
Get-VDPortgroup $pgmgtwan | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink1 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true  -StandbyUplinkPort dvUplink2 
 
 

#NSX Compute
New-VDSwitch -Name $vdsnsxcmp -Location $datacenter -LinkDiscoveryProtocol "LLDP" -LinkDiscoveryProtocolOperation "Both" -MaxPorts 2147483647 -Version "6.5.0" -MTU 1600 -NumUplinkPorts 2  

New-VDPortgroup -VDSwitch $vdsnsxcmp -Name DPortGroup1  -NumPorts 8 -VlanId $vlanmgtmgt -PortBinding Static
Get-VDPortgroup DPortGroup1 | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink1 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true -StandbyUplinkPort dvUplink2 

#NSX Management
New-VDSwitch -Name $vdsnsxmgt -Location $datacenter -LinkDiscoveryProtocol "LLDP" -LinkDiscoveryProtocolOperation "Both" -MaxPorts 2147483647 -Version "6.5.0" -MTU 1600 -NumUplinkPorts 2  

New-VDPortgroup -VDSwitch $vdsnsxmgt -Name DPortGroup2  -NumPorts 8 -VlanId $vlanmgtmgt -PortBinding Static
Get-VDPortgroup DPortGroup2 | Get-VDUplinkTeamingPolicy | Set-VDUplinkTeamingPolicy -ActiveUplinkPort dvUplink1 -FailBack $true  -FailoverDetectionPolicy LinkStatus  -LoadBalancingPolicy ExplicitFailover  -NotifySwitches $true -StandbyUplinkPort dvUplink2 

#VMs and templates folder structure
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("AD")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("Dell OMI")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("SMTP")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("SQL")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("TS")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("vRA")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("vRO")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("vCSA")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("CEB")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("vROps")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("vRLI")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("Util")
(Get-View (Get-View -viewtype datacenter -filter @{"name" = $datacenter}).vmfolder).CreateFolder("vSphere Replication")

#disable ALL alarms on the VCSA level, Alarms for SRM, VDP, OMI will be added and enabled manually
#get-alarmdefinition | set-alarmdefinition -Enabled:$false

#create resource pools
new-resourcepool -Location $clustermgt -Name "RP-Priority" -CpuExpandableReservation $true -CpuSharesLevel Custom -NumCpuShares 1500  -MemExpandableReservation $true -MemSharesLevel Custom -NumMemShares 1500
new-resourcepool -Location $clustermgt -Name "RP-Normal" -CpuExpandableReservation $true -CpuSharesLevel Custom -NumCpuShares 3000  -MemExpandableReservation $true -MemSharesLevel Custom -NumMemShares 3000
new-resourcepool -Location $clustermgt -Name "RP-Low" -CpuExpandableReservation $true -CpuSharesLevel Custom -NumCpuShares 375  -MemExpandableReservation $true -MemSharesLevel Custom -NumMemShares 375

#disconnect vCenter
disconnect-viserver $vcenter -confirm:$false

