#SAP on Cloud config script. Specific Settings to be applied to ESXi
# --Sets PSP and SATP Policy--
# --Sets Lun Queue Depth to 128--
# --Sets IOPS to 1--
#v0.1 19/04/2018 based on requirements from DPC-9049
#v1.0 11/05/2018 based on creation of SAP Resource Pool
#Author: Brian Gerrard


#----Set vCenter and Cluster. Change before Running Script----
#Declare ESX Host here
$vcenter = ""
$cluster = ""
$mgtcluster = ""

#Connect to vCenter Server
Echo ">>> Connecting to vCenter Server...Please enter domain credentials in the displayed window"
$vcenter = Connect-VIServer -Server $vcenter
if (! $vcenter) {
        Echo "connect-viserver -Server $vcenter"
        Echo $error[1].Exception.Message
        Read-Host -Prompt "Press Enter to exit"
        Exit
}

#Get ESX Hosts from Cluster
Echo ">>> Get Hosts from CMP Cluster ..."
$esxHosts = Get-Cluster $cluster | Get-VMHost
Echo ">>> Hosts in Cluster are $esxHosts..."

# Loop through all hosts in cluster
foreach ($esxHost in $esxHosts)
{
#Set Default PSP
Echo ">>> Set Default SATP and PSP for $esxHost..."
$defaultpsp = "VMW_PSP_RR"
$satp = "VMW_SATP_ALUA_CX"
$esxcli = Get-EsxCli -VMHost $esxHost
$esxcli.storage.nmp.satp.set($null,$defaultpsp,$satp)

Echo ">>> Set Lun Queue Depth for $esxHost..."
#Set Lun queue depth
$esxcliv2 = Get-VMHost -Name $esxHost | Get-EsxCli -V2
$parameters = $esxcliv2.system.module.parameters.set.CreateArgs()
$parameters['module']='lpfc'
$parameters['parameterstring']='lpfc_lun_queue_depth=128'
$esxcliv2.system.module.parameters.set.Invoke($parameters)

Echo ">>> Set IOPS Size to 1 for $esxHost..."
#Set IOPS Size
Get-VMHost $esxHost | Get-ScsiLun -LunType disk | Where-Object {$_.Multipathpolicy -like "RoundRobin"} | Set-ScsiLun -CommandsToSwitchPath 1 | Select-Object CanonicalName, MultipathPolicy, CommandsToSwitchPath
}

Echo ">>> Create Resource Pool..."
#Create Resource Pool
new-resourcepool -Location $mgtcluster -Name "RP-SAP" -CpuExpandableReservation $true -CpuSharesLevel Custom -NumCpuShares 125  -MemExpandableReservation $true -MemSharesLevel Custom -NumMemShares 125

#disconnect vCenter
disconnect-viserver $vcenter -confirm:$false