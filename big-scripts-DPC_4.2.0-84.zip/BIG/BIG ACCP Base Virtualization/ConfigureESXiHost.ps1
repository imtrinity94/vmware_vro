#ESXi v6 config script
#v0.1 09-03-2016
#Authors: Original: Krzysztof Hermanowski, Michel Vittel, Damien Faure Modified for ACCP by Alec Dunn
#Features:
#Joins ESXi host to the AD domain
#Configures NTP server, starts the NTP service, enables NTP through firewall
#Configures coredump network, server and port
#Sets the CPU power policy to high performance
#adds the A record to DNS

#Prereq's: Working AD/NTP server

#---CHANGE THIS SECTION BEGIN ---
#Declare here the target ESXi host
$esxHosts = @{
    "192.168.111.20" = "deventdpmc001";
}

$esxuser="root"
$esxpwd='-enter-ESX-password-here-'
$DDCdomain="<FQDN of Domain HERE>"
$adserver1="<AD Server 1 IPV4 Address>"
$adserver2="<AD Server 2 IPV4 Address>"
$vcenter="<vCenter Server IP Address"
$powerCLIModulesPath="C:\Program Files (x86)\VMware\Infrastructure\vSphere PowerCLI\"
$ADUser="s-LDAPsvc001"
$ADPassword='-enter-AD-password-here-'

#Juniper gateway IP addres as NTP server address
$ntpservers=�10.216.248.1�

#---CHANGE THIS SECTION END---

$dnsServer = $adserver1

#### Add snapins
if ( (Get-PSSnapin -Name VMware.VimAutomation.Core -ErrorAction SilentlyContinue) -eq $null ) {
    Add-PSsnapin VMware.VimAutomation.Core
}

#### Load modules
# Add VMWare module path to PSModulePath env variable
#Save the current value in the $p variable.
$p = [Environment]::GetEnvironmentVariable("PSModulePath")
#Add the new path to the $p variable. Begin with a semi-colon separator.
$p += ";" + $powerCLIModulesPath
#Add the paths in $p to the PSModulePath value.
[Environment]::SetEnvironmentVariable("PSModulePath",$p)
if ( (Get-Module -Name VMware.VimAutomation.Vds -ErrorAction SilentlyContinue) -eq $null ) {
    Import-Module VMware.VimAutomation.Vds
}

#Trace commands for debug purpose
#Set-PSDebug -Trace 2;

#### Connect to the ESXi and configure it
foreach ($esxHostentry in $esxHosts.GetEnumerator())
{
    $esxhostIP=$esxHostentry.Name
    $esxhostname=$esxHostentry.value

    Echo ">>> Connecting to ESXi $esxhostIP ..."
    $esxHostConnection = Connect-VIServer -Server $esxhostIP -User $esxuser -Password $esxpwd
    if (! $esxHostConnection) {
        Echo "connect-viserver -Server $esxhostIP"
        Echo $error[1].Exception.Message
        Read-Host -Prompt "Press Enter to exit"
        Exit
    }
    try {
        # Get esxHost instance
        $esxHost = Get-VMHost -Server $esxHostConnection
           
        #add A record to dns
        Echo ">>> Register the ESXi in the DNS ..."
        Add-DnsServerResourceRecordA -Name $esxhostname -ZoneName $DDCdomain -AllowUpdateAny -IPv4Address $esxhostIP -TimeToLive 01:00:00 -ComputerName $dnsServer -CreatePtr

        # Join the VMHost to a domain
        Echo ">>> Join AD from ESXi ..."
        Get-VMHostAuthentication -VMHost $esxHost | Set-VMHostAuthentication -JoinDomain -Domain $DDCDomain -User $ADUser -Password $ADPassword -Confirm:$false
        # Workaround upon failure - run on ESXi :  /usr/lib/vmware/likewise/bin/domainjoin-cli join ddcdev.l

        #set coredump
        Echo ">>> Set ESXi coredump to $vCenter ..."
        $esxcli=get-esxcli -VMHost $esxHost
        $esxcli.system.coredump.network.set($null,"vmk0",$null,[STRING]$vCenter,6500)
        $esxcli.system.coredump.network.set(1)
        $esxcli.system.coredump.network.get()

        #Configure NTP servers
        Echo ">>> Check ESXi NTP configuration ..."
        $current_NTP = Get-VmHostNtpServer -VMHost $esxHost
        ForEach ($ntpserver in $ntpservers) {
            if ($current_NTP -notcontains $ntpserver) {
                Add-VmHostNtpServer -VMHost $esxHost -NtpServer $ntpserver
            }
        }
        
        #Allow NTP queries outbound through the firewall
        Echo ">>> Open NTP in firewall ..."
        Get-VMHostFirewallException -VMHost $esxHost | where {$_.Name -eq "NTP client"} | Set-VMHostFirewallException -Enabled:$true
        
        #Start NTP client service and set to automatic
        Echo ">>> Start NTP service automatically ..."
        Get-VmHostService -VMHost $esxHost | Where-Object {$_.key -eq "ntpd"} | Start-VMHostService
        Get-VmHostService -VMHost $esxHost | Where-Object {$_.key -eq "ntpd"} | Set-VMHostService -policy "on"

        #set power policy
        # static means "High Performance", on some R7x0 servers might output "unsupported"
        Echo ">>> Set power policy ..."
        $esxcli.system.settings.advanced.set($null,$null,"/Power/CpuPolicy","static")
    } catch {
        Write-Error ("The following error has occurred for VMHost '$esxHostIP': 'r'n"+$_)
    } finally {
        Echo ">>> Disconnecting to ESXi $esxhostIP ..."
        Disconnect-VIServer $esxHostConnection -Confirm:$false
    }
}

